# English-to-Hindi Video Dubbing Studio: Implementation & Deployment Plan

Comprehensive breakdown of user responsibilities (external manual steps) versus automated engineering tasks (handled by the assistant), followed by the step-by-step implementation roadmap for completing Stages 2 through 9 and delivering a release APK.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Division of Responsibilities**:
> - **User's External Tasks**:
>   1. Provide a Google Gemini API Key in the server `.env` file (`GEMINI_API_KEY`).
>   2. Run the Node.js/TypeScript backend (either locally via Wi-Fi/ngrok or on free cloud hosting like Render/Railway) with `ffmpeg` installed.
>   3. Download and test the generated release APK on an Android device.
> - **Assistant's Automated Tasks**:
>   1. Implement the real video upload & `jobId` workflow in the Flutter app (resolving the Stage 2 upload gap).
>   2. Implement true Android MediaStore video saving in `gallery_service.dart` (replacing mock saving).
>   3. Configure Dockerfile and deployment settings for frictionless cloud or local backend execution.
>   4. Ensure the GitHub Actions release APK workflow compiles cleanly.

---

## 1. Overview & Core Architecture

The application is an end-to-end English-to-Hindi video dubbing pipeline consisting of:
- **Mobile Client (Flutter / Dart)**: Video selection, playback preview, dubbing parameter configuration, step-by-step progress tracking, and saving to Android MediaStore.
- **Backend Service (TypeScript / Node.js + Express + FFmpeg)**: Audio extraction, Gemini transcription, Hindi translation, Hindi TTS generation, speed synchronization (`atempo`), audio ducking & mixing, and final MP4 video multiplexing.

### System Architecture & Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    Flutter Android App                      │
│                                                             │
│  [Video Picker] ──► [Upload Video] ──► [Job Tracker]       │
│                           │                  ▲              │
│                           │ Multipart POST   │ Status &     │
│                           ▼                  │ Results      │
│  [Gallery Saver] ◄── [Download Video] ◄──────┘              │
└───────────────────────────┬─────────────────────────────────┘
                            │ REST API
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                 TypeScript / Express Server                 │
│                                                             │
│  /api/video/upload        ──► Store video & create jobId    │
│  /api/video/:jobId/audio  ──► FFmpeg extract WAV            │
│  /api/video/:jobId/transcribe ──► Gemini Flash Speech-to-Text│
│  /api/video/:jobId/translate  ──► Gemini Hindi Translation  │
│  /api/tts                 ──► Hindi Speech synthesis        │
│  /api/sync                ──► FFmpeg atempo speed alignment │
│  /api/mix-audio           ──► FFmpeg volume ducking & mix   │
│  /api/render-video        ──► FFmpeg MP4 remux with Hindi   │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Detailed Task Breakdown

### A. User's Responsibilities (Aapke Liye Bahari Kaam)

1. **Gemini API Key Setup**:
   - Obtain a free API key from [Google AI Studio](https://aistudio.google.com).
   - Place it into the server `.env` file as `GEMINI_API_KEY=your_key_here`.
   - *Why*: Security best practices require private API keys to remain on your server and never be embedded inside the client APK.
2. **Backend Server Execution**:
   - **Option A (Local Testing)**: Run `npm run dev` on your computer. If testing on a physical phone, ensure phone and PC are on the same Wi-Fi, and set `AppConfig.apiBaseUrl` in Flutter to `http://<your-pc-ip>:3000`.
   - **Option B (Cloud Hosting - Recommended)**: Deploy the repository to Render, Railway, or Fly.io (Dockerfile provided) and set `AppConfig.apiBaseUrl` to the deployed HTTPS URL.
3. **APK Testing on Phone**:
   - Download `app-release.apk` from GitHub Actions artifacts and install it on an Android phone.

### B. Assistant's Engineering Plan (Humara Kaam)

#### Step 1: Real Video Upload in Flutter (Fixing Stage 2 Gap)
- Update `flutter_dubbing_app/lib/screens/dubbing_studio_screen.dart` and `flutter_dubbing_app/lib/services/dubbing_service.dart`.
- When the user selects a video file, immediately send a multipart HTTP POST request to `/api/video/upload`.
- Capture the returned `jobId` and store it in state (`_currentJobId`).
- Use this `_currentJobId` across all subsequent pipeline calls (`/api/video/:jobId/extract-audio`, `/api/translate`, `/api/mix-audio`, `/api/render-video`).
- Display upload progress in the UI.

#### Step 2: Real Android Gallery MediaStore Saving (Stage 9)
- Enhance `flutter_dubbing_app/lib/services/gallery_service.dart`.
- Download the rendered MP4 file from the backend (`/api/media/rendered_video/...`) to the device's temporary directory.
- Use `gal` or Android MethodChannel with `MediaStore.Video.Media` to write the video directly to the device's public `Movies/DubbedVideos` or `DCIM` folder.
- Return the actual content URI or filesystem path on success.

#### Step 3: Production Server Deployment Config & Health
- Ensure `Dockerfile` exists for containerized backend deployment with `ffmpeg` pre-installed.
- Verify production start script (`npm run build && npm start`) and graceful error handling.

#### Step 4: Verification & Release APK Workflow Validation
- Run TypeScript lint and compile checks.
- Verify `.github/workflows/build_apk.yml` configuration.
- Provide step-by-step instructions for pushing changes and downloading the built APK.

---

## 3. Execution Verification Plan

| Phase | Verification Method | Success Criteria |
|---|---|---|
| Video Upload | Simulated multipart POST | Returns `jobId` and valid file on server |
| Full Pipeline | cURL end-to-end test | Generates real `Hindi_Dubbed_<jobId>.mp4` |
| Flutter Code | Dart/Flutter syntax check | Zero missing imports or broken signatures |
| TypeScript Server | `npm run build` | Compiles with 0 errors |
| APK Build | GitHub Actions test | Successful `flutter build apk --release` |
