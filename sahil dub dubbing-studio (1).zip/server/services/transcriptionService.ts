import fs from 'fs';
import { config } from '../config';
import { getSpeechToTextProvider, RawTranscriptSegment } from './speechToText';
import { videoProcessingService } from './videoService';

export interface ValidatedSegment {
  id: string;
  numericId: number;
  englishText: string;
  text: string;
  startTime: number;
  endTime: number;
}

export interface Phase2TranscriptResponse {
  success: boolean;
  jobId: string;
  language: string;
  duration: number;
  segments: ValidatedSegment[];
}

export interface TranscriptionInput {
  audioBase64?: string;
  mimeType?: string;
  durationSeconds: number;
  videoName?: string;
  jobId?: string;
}

export class TranscriptionService {
  /**
   * Validates and sanitizes timestamped speech segments according to Phase 2 rules:
   * 1. startTime >= 0
   * 2. endTime > startTime
   * 3. endTime <= totalDuration (with slight tolerance)
   * 4. Chronological order
   * 5. No unexpected overlap (preserves natural gaps)
   * 6. Non-empty text
   */
  public validateAndFormatSegments(
    rawSegments: RawTranscriptSegment[],
    totalDuration: number
  ): ValidatedSegment[] {
    const validDuration = totalDuration > 0 ? totalDuration : 600;

    // Filter out invalid/empty text
    const cleanList = rawSegments.filter(
      (s) => s && typeof s.text === 'string' && s.text.trim().length > 0
    );

    if (cleanList.length === 0) {
      return [];
    }

    // Sort strictly by startTime
    cleanList.sort((a, b) => (Number(a.startTime) || 0) - (Number(b.startTime) || 0));

    const result: ValidatedSegment[] = [];
    let lastEndTime = 0.0;

    for (let i = 0; i < cleanList.length; i++) {
      const raw = cleanList[i];
      let start = Math.max(0.0, Math.round((Number(raw.startTime) || 0) * 100) / 100);
      let end = Math.round((Number(raw.endTime) || (start + 1.0)) * 100) / 100;

      // Ensure start doesn't overlap backwards past previous end time
      if (start < lastEndTime) {
        start = lastEndTime;
      }

      // Ensure endTime > startTime (minimum segment length 0.3s)
      if (end <= start) {
        end = Math.round((start + 0.5) * 100) / 100;
      }

      // Bound within audio duration
      if (end > validDuration + 0.5) {
        end = Math.round(validDuration * 100) / 100;
        if (start >= end) {
          start = Math.max(0, Math.round((end - 0.5) * 100) / 100);
        }
      }

      lastEndTime = end;

      const seqNum = i + 1;
      const formattedId = `seg_${seqNum.toString().padLeft(3, '0')}`;
      const text = raw.text.trim();

      result.push({
        id: formattedId,
        numericId: seqNum,
        englishText: text,
        text: text,
        startTime: start,
        endTime: end,
      });
    }

    return result;
  }

  /**
   * Processes audio from either a jobId's extracted WAV file or direct base64 audio.
   */
  async processAudioTranscription(input: TranscriptionInput): Promise<Phase2TranscriptResponse> {
    const { durationSeconds, videoName, jobId } = input;
    let audioBase64 = input.audioBase64;
    let mimeType = input.mimeType || 'audio/wav';
    let duration = durationSeconds;

    // If jobId is provided, check if extracted WAV file exists on disk
    if (jobId) {
      const wavPath = videoProcessingService.getExtractedWavPath(jobId);
      if (wavPath && fs.existsSync(wavPath)) {
        const fileBuf = fs.readFileSync(wavPath);
        audioBase64 = fileBuf.toString('base64');
        mimeType = 'audio/wav';

        // Check if job duration was recorded
        const job = videoProcessingService.getJob(jobId);
        if (job?.duration && job.duration > 0) {
          duration = job.duration;
        }
      }
    }

    if (!audioBase64 || audioBase64.trim().length === 0) {
      throw new Error('ऑडियो डेटा प्राप्त नहीं हुआ। कृपया वीडियो अपलोड व ऑडियो एक्सट्रैक्शन की पुष्टि करें।');
    }

    if (duration > config.maxAudioDurationSeconds) {
      throw new Error('वीडियो की अधिकतम अवधि 10 मिनट (600 सेकंड) है।');
    }

    // Update job status if jobId exists
    if (jobId) {
      const currentJob = videoProcessingService.getJob(jobId);
      if (currentJob) {
        videoProcessingService.saveJob({
          ...currentJob,
          status: 'transcribing',
        });
      }
    }

    const sttProvider = getSpeechToTextProvider();
    let rawSegments: RawTranscriptSegment[];

    try {
      rawSegments = await sttProvider.transcribe({
        audioBase64,
        mimeType,
        durationSeconds: duration,
      });
    } catch (err: any) {
      if (jobId) {
        const currentJob = videoProcessingService.getJob(jobId);
        if (currentJob) {
          videoProcessingService.saveJob({
            ...currentJob,
            status: 'failed',
            error: err.message,
          });
        }
      }
      throw err;
    }

    // Validate and format segments
    const validatedSegments = this.validateAndFormatSegments(rawSegments, duration);

    if (validatedSegments.length === 0) {
      const emptyError = 'इस वीडियो में कोई स्पष्ट अंग्रेजी भाषण नहीं पहचाना जा सका। कृपया स्पष्ट आवाज वाली वीडियो चुनें।';
      if (jobId) {
        const currentJob = videoProcessingService.getJob(jobId);
        if (currentJob) {
          videoProcessingService.saveJob({
            ...currentJob,
            status: 'failed',
            error: emptyError,
          });
        }
      }
      throw new Error(emptyError);
    }

    const calculatedDuration = Math.round(duration * 100) / 100;
    const finalJobId = jobId || `job_${Date.now()}`;

    const transcriptResponse: Phase2TranscriptResponse = {
      success: true,
      jobId: finalJobId,
      language: 'en',
      duration: calculatedDuration,
      segments: validatedSegments,
    };

    // Save transcript against jobId
    if (jobId) {
      videoProcessingService.saveTranscript(jobId, transcriptResponse);
      const currentJob = videoProcessingService.getJob(jobId);
      if (currentJob) {
        videoProcessingService.saveJob({
          ...currentJob,
          status: 'transcript_ready',
          segmentCount: validatedSegments.length,
          duration: calculatedDuration,
        });
      }
    }

    return transcriptResponse;
  }
}

// Helper to pad segment ids
declare global {
  interface String {
    padLeft(targetLength: number, padString?: string): string;
  }
}

if (!String.prototype.padLeft) {
  String.prototype.padLeft = function (targetLength: number, padString: string = ' '): string {
    return this.padStart(targetLength, padString);
  };
}

export const transcriptionService = new TranscriptionService();
