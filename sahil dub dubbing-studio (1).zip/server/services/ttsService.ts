import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import googleTTS from 'google-tts-api';
import getMp3Duration from 'get-mp3-duration';

export interface VoiceSettings {
  language: string; // 'hi'
  voiceName: string; // 'hi-IN-Neural-1'
  speed: number; // 0.8 - 1.2 (default 1.0)
  pitch: number; // 0.8 - 1.2 (default 1.0)
  volume: number; // 0.0 - 1.0 (default 1.0)
}

export interface InputDubSegment {
  id: number;
  startTime: number;
  endTime: number;
  englishText: string;
  hindiText: string;
}

export interface HindiAudioSegment {
  id: number;
  startTime: number;
  endTime: number;
  englishText: string;
  hindiText: string;
  audioPath: string; // Local URL path e.g. /api/audio/segment_1_abc.mp3
  audioBase64?: string; // Optional base64 payload for client playback
  generatedDuration: number; // Measured duration in seconds
  originalDuration: number; // Original segment duration (endTime - startTime) in seconds
  durationDifference: number; // generatedDuration - originalDuration in seconds
}

export interface HindiTtsResult {
  segments: HindiAudioSegment[];
  totalOriginalDuration: number;
  totalGeneratedDuration: number;
  voiceSettings: VoiceSettings;
  createdAt: string;
}

export interface ITtsProvider {
  name: string;
  generateSpeech(text: string, settings: VoiceSettings): Promise<{ buffer: Buffer; mimeType: string }>;
}

/**
 * Google Natural Hindi TTS Provider
 * Produces crisp, clear, natural spoken Hindi voice audio.
 */
class GoogleHindiTtsProvider implements ITtsProvider {
  name = 'google-hindi';

  async generateSpeech(text: string, settings: VoiceSettings): Promise<{ buffer: Buffer; mimeType: string }> {
    const isSlow = settings.speed < 0.9;
    const base64 = await googleTTS.getAudioBase64(text, {
      lang: 'hi',
      slow: isSlow,
      host: 'https://translate.google.com',
      timeout: 15000,
    });

    const buffer = Buffer.from(base64, 'base64');
    return {
      buffer,
      mimeType: 'audio/mpeg',
    };
  }
}

export class TtsService {
  private cacheDir: string;
  private providers: Map<string, ITtsProvider> = new Map();

  constructor() {
    this.cacheDir = path.resolve(process.cwd(), 'server', 'temp', 'tts_cache');
    this.ensureCacheDirectory();
    this.cleanOldCacheFiles();

    // Register providers
    this.registerProvider(new GoogleHindiTtsProvider());
  }

  registerProvider(provider: ITtsProvider) {
    this.providers.set(provider.name, provider);
  }

  private ensureCacheDirectory() {
    if (!fs.existsSync(this.cacheDir)) {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    }
  }

  /**
   * Cleans cache files older than 24 hours to avoid disk accumulation
   */
  private cleanOldCacheFiles() {
    try {
      if (!fs.existsSync(this.cacheDir)) return;
      const files = fs.readdirSync(this.cacheDir);
      const now = Date.now();
      const maxAgeMs = 24 * 60 * 60 * 1000;

      for (const file of files) {
        const filePath = path.join(this.cacheDir, file);
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > maxAgeMs) {
          fs.unlinkSync(filePath);
        }
      }
    } catch (e) {
      console.warn('[TtsService] Cache cleanup notice:', e);
    }
  }

  /**
   * Retrieves an audio file from cache directory
   */
  getAudioFilePath(filename: string): string | null {
    // Sanitize filename to prevent directory traversal
    const safeFilename = path.basename(filename);
    const fullPath = path.join(this.cacheDir, safeFilename);
    if (fs.existsSync(fullPath)) {
      return fullPath;
    }
    return null;
  }

  /**
   * Generates timestamped Hindi audio segments from Hindi transcript
   */
  async generateHindiAudioSegments(
    segments: InputDubSegment[],
    customSettings?: Partial<VoiceSettings>,
    providerName: string = 'google-hindi'
  ): Promise<HindiTtsResult> {
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      throw new Error('हिंदी ट्रांसक्रिप्ट में कोई संवाद उपलब्ध नहीं है।');
    }

    const settings: VoiceSettings = {
      language: 'hi',
      voiceName: customSettings?.voiceName || 'hi-IN-Neural-1',
      speed: customSettings?.speed || 1.0,
      pitch: customSettings?.pitch || 1.0,
      volume: customSettings?.volume || 1.0,
    };

    const provider = this.providers.get(providerName) || this.providers.get('google-hindi');
    if (!provider) {
      throw new Error('चयनित TTS प्रदाता उपलब्ध नहीं है।');
    }

    this.ensureCacheDirectory();

    const outputSegments: HindiAudioSegment[] = [];
    let totalOriginalDuration = 0;
    let totalGeneratedDuration = 0;

    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      const hindiText = (seg.hindiText || '').trim();

      if (!hindiText) {
        throw new Error(`संवाद खंड #${seg.id} में हिंदी पाठ अनुपलब्ध है।`);
      }

      const origDuration = Math.max(0.1, Number((seg.endTime - seg.startTime).toFixed(2)));
      totalOriginalDuration += origDuration;

      // Unique hash for caching & safe naming
      const hash = crypto
        .createHash('md5')
        .update(`${seg.id}_${hindiText}_${settings.speed}_${settings.voiceName}`)
        .digest('hex')
        .slice(0, 10);
      const filename = `hindi_seg_${seg.id}_${hash}.mp3`;
      const filePath = path.join(this.cacheDir, filename);

      let audioBuffer: Buffer;

      if (fs.existsSync(filePath)) {
        // Read from cache
        audioBuffer = fs.readFileSync(filePath);
      } else {
        try {
          const result = await provider.generateSpeech(hindiText, settings);
          audioBuffer = result.buffer;
          fs.writeFileSync(filePath, audioBuffer);
        } catch (err: any) {
          console.error(`[TtsService] Error synthesizing segment #${seg.id}:`, err);
          throw new Error(`हिंदी आवाज़ बनाने में समस्या हुई (खंड #${seg.id}): ${err.message || 'त्रुटि'}`);
        }
      }

      // Calculate exact duration of generated MP3 audio
      let generatedDurationSec = 0;
      try {
        const durationMs = getMp3Duration(audioBuffer);
        generatedDurationSec = Number((durationMs / 1000).toFixed(2));
      } catch (durErr) {
        // Fallback duration estimation if metadata parsing fails
        generatedDurationSec = Math.max(0.5, Number((hindiText.length * 0.12).toFixed(2)));
      }

      totalGeneratedDuration += generatedDurationSec;

      const durationDiff = Number((generatedDurationSec - origDuration).toFixed(2));

      outputSegments.push({
        id: seg.id,
        startTime: seg.startTime,
        endTime: seg.endTime,
        englishText: seg.englishText,
        hindiText,
        audioPath: `/api/audio/${filename}`,
        audioBase64: audioBuffer.toString('base64'),
        generatedDuration: generatedDurationSec,
        originalDuration: origDuration,
        durationDifference: durationDiff,
      });
    }

    return {
      segments: outputSegments,
      totalOriginalDuration: Number(totalOriginalDuration.toFixed(2)),
      totalGeneratedDuration: Number(totalGeneratedDuration.toFixed(2)),
      voiceSettings: settings,
      createdAt: new Date().toISOString(),
    };
  }
}

export const ttsService = new TtsService();
