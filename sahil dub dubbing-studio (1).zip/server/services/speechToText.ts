import { GoogleGenAI, Type } from '@google/genai';
import { config } from '../config';

export interface RawTranscriptSegment {
  id: number;
  startTime: number;
  endTime: number;
  text: string;
}

export interface SpeechToTextProvider {
  name: string;
  transcribe(options: {
    audioBase64: string;
    mimeType: string;
    durationSeconds: number;
  }): Promise<RawTranscriptSegment[]>;
}

/**
 * Gemini Speech-to-Text Implementation
 * Uses Google Gen AI SDK (@google/genai) to transcribe English audio with timestamped segments.
 */
export class GeminiSpeechToTextProvider implements SpeechToTextProvider {
  name = 'Gemini-3.8-Flash-STT';
  private ai: GoogleGenAI;

  constructor(apiKey?: string) {
    const key = apiKey || config.geminiApiKey;
    if (!key) {
      console.warn('[GeminiSpeechToTextProvider] Warning: GEMINI_API_KEY is not defined in environment.');
    }

    this.ai = new GoogleGenAI({
      apiKey: key || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  async transcribe(options: {
    audioBase64: string;
    mimeType: string;
    durationSeconds: number;
  }): Promise<RawTranscriptSegment[]> {
    if (!config.geminiApiKey) {
      throw new Error('GEMINI_API_KEY कॉन्फ़िगर नहीं है। कृपया पर्यावरण चर (Environment Variable) में API Key सेट करें।');
    }

    const { audioBase64, mimeType = 'audio/wav', durationSeconds } = options;

    const audioPart = {
      inlineData: {
        mimeType: mimeType,
        data: audioBase64,
      },
    };

    const promptText = `You are a high-precision Speech-to-Text transcription engine for video dubbing.
Task:
1. Listen carefully to the English audio and generate an accurate, word-for-word transcript.
2. Divide the speech into natural spoken sentences or conversational phrases (typically 2 to 7 seconds each).
3. Preserve the exact order of speech.
4. For each segment, output:
   - "id": an integer starting at 1
   - "startTime": start time in seconds (float or int) relative to the audio start (>= 0)
   - "endTime": end time in seconds (float or int) (strictly greater than startTime and <= ${Math.ceil(durationSeconds || 600)})
   - "text": the exact spoken English text with proper capitalization and punctuation
5. If the audio is silence, background music only, or contains no audible human speech, return an empty array [].
6. Do NOT add commentary, notes, or hallucinations.`;

    const candidateModels = [
      config.geminiModel,
      'gemini-flash-latest',
      'gemini-3.5-transcribe',
    ];

    let lastError: any = null;

    for (const modelName of candidateModels) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          if (attempt > 0) {
            await new Promise((r) => setTimeout(r, 1000));
          }

          const response = await this.ai.models.generateContent({
            model: modelName,
            contents: [
              audioPart,
              { text: promptText },
            ],
            config: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.ARRAY,
                description: 'List of timestamped English speech segments',
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.INTEGER, description: 'Segment sequence number starting at 1' },
                    startTime: { type: Type.NUMBER, description: 'Start time in seconds' },
                    endTime: { type: Type.NUMBER, description: 'End time in seconds' },
                    text: { type: Type.STRING, description: 'Spoken English sentence or phrase' },
                  },
                  required: ['id', 'startTime', 'endTime', 'text'],
                },
              },
            },
          });

          const responseText = response.text?.trim() || '[]';
          let parsed: RawTranscriptSegment[];

          try {
            parsed = JSON.parse(responseText);
          } catch (jsonErr) {
            console.error(`[GeminiSpeechToTextProvider] (${modelName}) Failed to parse JSON:`, responseText);
            continue;
          }

          if (Array.isArray(parsed)) {
            return parsed;
          }
        } catch (err: any) {
          lastError = err;
          const errMsg = err?.message || String(err);
          console.warn(`[GeminiSpeechToTextProvider] Attempt failed with ${modelName} (attempt ${attempt + 1}):`, errMsg);

          // If it's not a rate limit / 503, no need to retry same model
          if (!errMsg.includes('503') && !errMsg.includes('429') && !errMsg.includes('demand')) {
            break;
          }
        }
      }
    }

    console.error('[GeminiSpeechToTextProvider] All STT candidate models exhausted. Last error:', lastError);
    if (lastError?.message && lastError.message.includes('API_KEY')) {
      throw new Error('अमान्य अथवा अनुपलब्ध API Key। कृपया GEMINI_API_KEY की जांच करें।');
    }
    throw new Error('English आवाज़ को पहचानने में समस्या हुई। कृपया दोबारा प्रयास करें।');

  }
}

/**
 * Provider factory enabling seamless swapping or addition of alternative STT engines (e.g. Whisper, Cloud STT)
 */
export function getSpeechToTextProvider(providerName: string = config.sttProvider): SpeechToTextProvider {
  switch (providerName) {
    case 'gemini':
    default:
      return new GeminiSpeechToTextProvider();
  }
}
