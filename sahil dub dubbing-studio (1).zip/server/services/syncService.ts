import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { exec } from 'child_process';
import util from 'util';
import getMp3Duration from 'get-mp3-duration';
import googleTTS from 'google-tts-api';

const execAsync = util.promisify(exec);

export type TimingClassification =
  | 'fits_naturally'
  | 'slightly_longer'
  | 'slightly_shorter'
  | 'significantly_longer'
  | 'significantly_shorter';

export type SyncStatus =
  | 'synchronized'
  | 'fits_naturally'
  | 'adjusted_speed'
  | 'clamped_speed'
  | 'processing'
  | 'error';

export interface InputAudioSegment {
  id: number;
  startTime: number;
  endTime: number;
  englishText: string;
  hindiText: string;
  audioPath?: string;
  audioBase64?: string;
  generatedDuration?: number;
  hindiAudioDuration?: number;
  originalDuration?: number;
}

export interface SyncedAudioSegment {
  id: number;
  startTime: number;
  endTime: number;
  targetDuration: number;
  originalAudioDuration: number;
  hindiAudioDuration: number;
  adjustedDuration: number;
  audioPath: string;
  audioBase64?: string;
  speedAdjustment: number;
  status: SyncStatus;
  timingClassification: TimingClassification;
  timingClassificationHindi: string;
  remainingDifference: number;
  englishText: string;
  hindiText: string;
}

export interface SyncResult {
  segments: SyncedAudioSegment[];
  totalTargetDuration: number;
  totalAdjustedDuration: number;
  averageSpeedAdjustment: number;
  naturallyFitCount: number;
  speedAdjustedCount: number;
  clampedCount: number;
  createdAt: string;
}

export class AudioSyncService {
  private cacheDir: string;

  constructor() {
    this.cacheDir = path.resolve(process.cwd(), 'server', 'temp', 'tts_cache');
    if (!fs.existsSync(this.cacheDir)) {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    }
  }

  /**
   * Analyzes timing and synchronizes Hindi audio segments to match original speech timing.
   */
  async synchronizeSegments(segments: InputAudioSegment[]): Promise<SyncResult> {
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      throw new Error('सिंक्रोनाइज़ेशन के लिए कोई ऑडियो सेगमेंट उपलब्ध नहीं है।');
    }

    const syncedSegments: SyncedAudioSegment[] = [];
    let totalTargetDuration = 0;
    let totalAdjustedDuration = 0;
    let sumSpeed = 0;
    let naturallyFitCount = 0;
    let speedAdjustedCount = 0;
    let clampedCount = 0;

    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];

      // 1. Calculate Target Duration
      const targetDuration = Number((seg.endTime - seg.startTime).toFixed(2));
      if (targetDuration <= 0) {
        throw new Error(`सेगमेंट #${seg.id} के टाइमस्टैम्प अमान्य हैं (startTime: ${seg.startTime}, endTime: ${seg.endTime})`);
      }

      // 2. Determine actual Hindi Audio Duration
      let hindiAudioDuration = Number((seg.generatedDuration || seg.hindiAudioDuration || seg.originalDuration || targetDuration).toFixed(2));

      // Resolve audio file on disk
      let sourceAudioPath = (seg.audioPath || '').trim();
      let absoluteSourceFile = '';

      if (sourceAudioPath.startsWith('/api/audio/')) {
        const filename = path.basename(sourceAudioPath);
        absoluteSourceFile = path.join(this.cacheDir, filename);
      } else if (sourceAudioPath && path.isAbsolute(sourceAudioPath)) {
        absoluteSourceFile = sourceAudioPath;
      } else if (sourceAudioPath) {
        absoluteSourceFile = path.join(this.cacheDir, path.basename(sourceAudioPath));
      }

      // If audio file doesn't exist on disk, check if base64 is provided
      if ((!absoluteSourceFile || !fs.existsSync(absoluteSourceFile)) && seg.audioBase64) {
        const tempName = `hindi_seg_${seg.id}_recovered.mp3`;
        absoluteSourceFile = path.join(this.cacheDir, tempName);
        fs.writeFileSync(absoluteSourceFile, Buffer.from(seg.audioBase64, 'base64'));
        sourceAudioPath = `/api/audio/${tempName}`;
      }

      // Auto-synthesize if missing and hindiText is available
      if ((!absoluteSourceFile || !fs.existsSync(absoluteSourceFile)) && seg.hindiText) {
        try {
          const base64 = await googleTTS.getAudioBase64(seg.hindiText, {
            lang: 'hi',
            slow: false,
            host: 'https://translate.google.com',
            timeout: 10000,
          });
          const tempName = `hindi_seg_${seg.id}_auto_${Date.now()}.mp3`;
          absoluteSourceFile = path.join(this.cacheDir, tempName);
          fs.writeFileSync(absoluteSourceFile, Buffer.from(base64, 'base64'));
          sourceAudioPath = `/api/audio/${tempName}`;
        } catch (ttsErr) {
          console.warn(`[SyncService] Could not auto-synthesize seg #${seg.id}:`, ttsErr);
        }
      }

      // If still missing, create a brief silence audio
      if (!absoluteSourceFile || !fs.existsSync(absoluteSourceFile)) {
        const tempName = `hindi_seg_${seg.id}_silent.mp3`;
        absoluteSourceFile = path.join(this.cacheDir, tempName);
        const safeDuration = Math.max(0.5, targetDuration);
        await execAsync(`ffmpeg -y -f lavfi -i anullsrc=r=24000:cl=mono -t ${safeDuration} -q:a 9 "${absoluteSourceFile}"`);
        sourceAudioPath = `/api/audio/${tempName}`;
      }

      // Verify exact duration from audio file
      try {
        const fileBuf = fs.readFileSync(absoluteSourceFile);
        const ms = getMp3Duration(fileBuf);
        if (ms && ms > 0) {
          hindiAudioDuration = Number((ms / 1000).toFixed(2));
        }
      } catch (err) {
        console.warn(`[SyncService] Could not parse exact duration for seg #${seg.id}, using provided:`, hindiAudioDuration);
      }

      // 3. Timing Analysis & Classification
      const ratio = Number((hindiAudioDuration / targetDuration).toFixed(2));
      let classification: TimingClassification;
      let classificationHindi: string;

      if (ratio >= 0.95 && ratio <= 1.05) {
        classification = 'fits_naturally';
        classificationHindi = 'स्वाभाविक रूप से सही (±5%)';
      } else if (ratio > 1.05 && ratio <= 1.20) {
        classification = 'slightly_longer';
        classificationHindi = 'थोड़ा लंबा (+5% से +20%)';
      } else if (ratio >= 0.80 && ratio < 0.95) {
        classification = 'slightly_shorter';
        classificationHindi = 'थोड़ा छोटा (-5% से -20%)';
      } else if (ratio > 1.20) {
        classification = 'significantly_longer';
        classificationHindi = 'काफी लंबा (> +20%)';
      } else {
        classification = 'significantly_shorter';
        classificationHindi = 'काफी छोटा (< -20%)';
      }

      // 4. Natural Synchronization Strategy (Levels 1, 2, 3)
      let speedAdjustment = 1.0;
      let status: SyncStatus = 'synchronized';

      // LEVEL 1: Close to target duration -> keep original audio
      if (classification === 'fits_naturally') {
        speedAdjustment = 1.0;
        status = 'fits_naturally';
        naturallyFitCount++;
      } else {
        // LEVEL 2 & 3: Calculate required speed to fit targetDuration
        // rawSpeed = hindiAudioDuration / targetDuration
        // e.g. 4.8s / 4.0s = 1.20x speedup
        const rawSpeed = Number((hindiAudioDuration / targetDuration).toFixed(2));

        // Strict natural voice bounds: 0.75x to 1.35x
        if (rawSpeed > 1.35) {
          speedAdjustment = 1.35;
          status = 'clamped_speed';
          clampedCount++;
        } else if (rawSpeed < 0.75) {
          speedAdjustment = 0.75;
          status = 'clamped_speed';
          clampedCount++;
        } else {
          speedAdjustment = rawSpeed;
          status = 'adjusted_speed';
          speedAdjustedCount++;
        }
      }

      sumSpeed += speedAdjustment;

      // 5. Apply time-stretching with pitch preservation via ffmpeg atempo
      let adjustedDuration = hindiAudioDuration;
      let finalAudioPath = seg.audioPath || sourceAudioPath;
      let finalAudioBase64 = seg.audioBase64;

      if (speedAdjustment !== 1.0) {
        const hash = crypto
          .createHash('md5')
          .update(`${seg.id}_${speedAdjustment}_${path.basename(absoluteSourceFile)}`)
          .digest('hex')
          .slice(0, 8);
        const syncedFilename = `synced_seg_${seg.id}_spd${Math.round(speedAdjustment * 100)}_${hash}.mp3`;
        const syncedFilePath = path.join(this.cacheDir, syncedFilename);

        if (!fs.existsSync(syncedFilePath)) {
          // Format ffmpeg filter string. atempo supports 0.5 to 2.0 per filter instance.
          const atempoFilter = `atempo=${speedAdjustment}`;
          const ffmpegCmd = `ffmpeg -y -i "${absoluteSourceFile}" -filter:a "${atempoFilter}" -vn "${syncedFilePath}"`;

          try {
            await execAsync(ffmpegCmd);
          } catch (ffmpegErr: any) {
            console.error(`[SyncService] FFmpeg time-stretching failed for segment #${seg.id}:`, ffmpegErr);
            throw new Error(`ऑडियो टाइम-स्ट्रेचिंग विफल रही (सेगमेंट #${seg.id}): ${ffmpegErr.message || 'त्रुटि'}`);
          }
        }

        if (fs.existsSync(syncedFilePath)) {
          const syncedBuf = fs.readFileSync(syncedFilePath);
          finalAudioBase64 = syncedBuf.toString('base64');
          finalAudioPath = `/api/audio/${syncedFilename}`;

          try {
            const ms = getMp3Duration(syncedBuf);
            adjustedDuration = Number((ms / 1000).toFixed(2));
          } catch (e) {
            adjustedDuration = Number((hindiAudioDuration / speedAdjustment).toFixed(2));
          }
        }
      } else {
        adjustedDuration = hindiAudioDuration;
      }

      const remainingDifference = Number((adjustedDuration - targetDuration).toFixed(2));

      totalTargetDuration += targetDuration;
      totalAdjustedDuration += adjustedDuration;

      syncedSegments.push({
        id: seg.id,
        startTime: seg.startTime,
        endTime: seg.endTime,
        targetDuration,
        originalAudioDuration: Number((seg.originalDuration || targetDuration).toFixed(2)),
        hindiAudioDuration,
        adjustedDuration,
        audioPath: finalAudioPath,
        audioBase64: finalAudioBase64,
        speedAdjustment,
        status,
        timingClassification: classification,
        timingClassificationHindi: classificationHindi,
        remainingDifference,
        englishText: seg.englishText,
        hindiText: seg.hindiText,
      });
    }

    const averageSpeedAdjustment = Number((sumSpeed / segments.length).toFixed(2));

    return {
      segments: syncedSegments,
      totalTargetDuration: Number(totalTargetDuration.toFixed(2)),
      totalAdjustedDuration: Number(totalAdjustedDuration.toFixed(2)),
      averageSpeedAdjustment,
      naturallyFitCount,
      speedAdjustedCount,
      clampedCount,
      createdAt: new Date().toISOString(),
    };
  }
}

export const audioSyncService = new AudioSyncService();
