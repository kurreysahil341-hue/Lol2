import { GoogleGenAI, Type } from '@google/genai';
import { config } from '../config';
import { videoProcessingService } from './videoService';

export interface DubSegment {
  id: string | number;
  numericId?: number;
  startTime: number;
  endTime: number;
  englishText: string;
  hindiText: string;
  text?: string;
}

export interface DubbedTranscript {
  success: boolean;
  jobId?: string;
  sourceLanguage: string;
  targetLanguage: string;
  duration: number;
  videoName?: string;
  segments: DubSegment[];
  createdAt: string;
}

export interface TranslateInputSegment {
  id?: string | number;
  numericId?: number;
  startTime: number;
  endTime: number;
  text?: string;
  englishText?: string;
}

export interface TranslateRequestPayload {
  jobId?: string;
  segments?: TranslateInputSegment[];
  duration?: number;
  videoName?: string;
  sourceLanguage?: string;
  targetLanguage?: string;
}

export class TranslationService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({
      apiKey: config.geminiApiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  /**
   * Translates timestamped English speech segments into natural spoken Hindi
   * specifically crafted for video dubbing (conversational tone, matching duration pacing).
   */
  async translateToHindi(payload: TranslateRequestPayload): Promise<DubbedTranscript> {
    const { jobId, videoName = 'video.mp4' } = payload;
    let inputSegments = payload.segments || [];
    let duration = payload.duration || 0;

    // If jobId is provided, retrieve transcript from storage if segments are not explicitly provided
    if (jobId) {
      const savedTranscript = videoProcessingService.getTranscript(jobId);
      if (savedTranscript && Array.isArray(savedTranscript.segments) && savedTranscript.segments.length > 0) {
        if (inputSegments.length === 0) {
          inputSegments = savedTranscript.segments;
        }
        if (!duration && savedTranscript.duration) {
          duration = savedTranscript.duration;
        }
      }

      // Update job status to translating
      const currentJob = videoProcessingService.getJob(jobId);
      if (currentJob) {
        videoProcessingService.saveJob({
          ...currentJob,
          status: 'translating',
        });
      }
    }

    // 1. Validate transcript segments presence
    if (!inputSegments || !Array.isArray(inputSegments) || inputSegments.length === 0) {
      const err = 'अनुवाद के लिए कोई ट्रांसक्रिप्ट उपलब्ध नहीं है। कृपया पहले वीडियो से स्पीच ट्रांसक्राइब करें।';
      if (jobId) {
        const cur = videoProcessingService.getJob(jobId);
        if (cur) videoProcessingService.saveJob({ ...cur, status: 'failed', error: err });
      }
      throw new Error(err);
    }

    // Standardize input segments
    const normalizedInput = inputSegments.map((s, idx) => {
      const segId = s.id !== undefined && s.id !== null ? String(s.id) : `seg_${(idx + 1).toString().padStart(3, '0')}`;
      return {
        id: segId,
        numericId: s.numericId || idx + 1,
        startTime: Number(s.startTime) || 0,
        endTime: Number(s.endTime) || (Number(s.startTime) || 0) + 2.0,
        englishText: (s.englishText || s.text || '').trim(),
      };
    }).filter((s) => s.englishText.length > 0);

    if (normalizedInput.length === 0) {
      const err = 'ट्रांसक्रिप्ट में कोई अंग्रेजी संवाद नहीं मिला। अनुवाद संभव नहीं है।';
      if (jobId) {
        const cur = videoProcessingService.getJob(jobId);
        if (cur) videoProcessingService.saveJob({ ...cur, status: 'failed', error: err });
      }
      throw new Error(err);
    }

    if (!config.geminiApiKey) {
      throw new Error('GEMINI_API_KEY कॉन्फ़िगर नहीं है। कृपया पर्यावरण चर (Environment Variable) में API Key सेट करें।');
    }

    const candidateModels = [
      config.geminiModel,
      'gemini-flash-latest',
      'gemini-3.8-flash',
    ];

    const promptInstructions = `You are a professional dialogue translator and script adapter for Hindi video dubbing.
Your task is to translate an English spoken video transcript into natural, spoken, conversational Hindi (आम बोलचाल की स्वाभाविक हिंदी).

CRITICAL DUBBING RULES:
1. Natural Spoken Hindi: The translated text will be spoken out loud by Hindi voice actors/TTS. Use natural spoken phrasing, not mechanical word-for-word dictionary translations.
2. Tone & Emotion: Preserve the speaker's original intent, conversational tone, enthusiasm, and context.
3. No Added Information: Do NOT invent facts, details, or dialogue not present in the original English speech.
4. Dubbing Pace & Timing: The dialogue must comfortably fit into the duration between "startTime" and "endTime". Avoid overly verbose Hindi phrasing that cannot be spoken within the segment duration.
5. Strict Segment Preservation:
   - Keep the EXACT same "id"
   - Keep the EXACT same "startTime" (DO NOT CHANGE)
   - Keep the EXACT same "endTime" (DO NOT CHANGE)
   - Keep the EXACT same "englishText"
   - Add the natural "hindiText" (written in clear Devanagari Hindi script)
6. Return ALL ${normalizedInput.length} segments in the exact same chronological order.`;

    const inputDataStr = JSON.stringify(normalizedInput, null, 2);

    let lastError: any = null;

    for (const modelName of candidateModels) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          if (attempt > 0) {
            await new Promise((r) => setTimeout(r, 1000));
          }

          const response = await this.ai.models.generateContent({
            model: modelName,
            contents: [
              {
                text: `${promptInstructions}\n\nInput English Segments:\n${inputDataStr}`,
              },
            ],
            config: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.ARRAY,
                description: 'List of English speech segments with natural spoken Hindi dubbing translation',
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING, description: 'Segment id matching original id' },
                    startTime: { type: Type.NUMBER, description: 'Original start time in seconds' },
                    endTime: { type: Type.NUMBER, description: 'Original end time in seconds' },
                    englishText: { type: Type.STRING, description: 'Original spoken English sentence' },
                    hindiText: { type: Type.STRING, description: 'Natural spoken Hindi dubbing translation in Devanagari' },
                  },
                  required: ['id', 'startTime', 'endTime', 'englishText', 'hindiText'],
                },
              },
            },
          });

          const responseText = response.text?.trim() || '[]';
          let parsed: any[];

          try {
            parsed = JSON.parse(responseText);
          } catch (jsonErr) {
            console.error(`[TranslationService] (${modelName}) Failed to parse JSON response:`, responseText);
            continue;
          }

          if (Array.isArray(parsed) && parsed.length > 0) {
            // Reconstruct segments strictly preserving original timestamps and IDs
            const finalizedSegments: DubSegment[] = normalizedInput.map((orig, idx) => {
              const matched = parsed.find((p) => String(p.id) === String(orig.id)) || parsed[idx];
              const hText = (matched?.hindiText || '').trim();
              return {
                id: orig.id,
                numericId: orig.numericId,
                startTime: orig.startTime,
                endTime: orig.endTime,
                englishText: orig.englishText,
                hindiText: hText || orig.englishText,
                text: hText || orig.englishText,
              };
            });

            const result: DubbedTranscript = {
              success: true,
              jobId: jobId || `job_${Date.now()}`,
              sourceLanguage: 'en',
              targetLanguage: 'hi',
              duration: duration || finalizedSegments[finalizedSegments.length - 1]?.endTime || 0,
              videoName,
              segments: finalizedSegments,
              createdAt: new Date().toISOString(),
            };

            // Save translation against jobId if jobId exists
            if (jobId) {
              videoProcessingService.saveTranslation(jobId, result);
              const cur = videoProcessingService.getJob(jobId);
              if (cur) {
                videoProcessingService.saveJob({
                  ...cur,
                  status: 'translation_ready',
                  segmentCount: finalizedSegments.length,
                });
              }
            }

            return result;
          }
        } catch (err: any) {
          lastError = err;
          const errMsg = err?.message || String(err);
          console.warn(`[TranslationService] Translation attempt failed with ${modelName} (attempt ${attempt + 1}):`, errMsg);

          if (!errMsg.includes('503') && !errMsg.includes('429') && !errMsg.includes('demand')) {
            break;
          }
        }
      }
    }

    console.error('[TranslationService] All translation candidate models failed:', lastError);
    if (jobId) {
      const cur = videoProcessingService.getJob(jobId);
      if (cur) videoProcessingService.saveJob({ ...cur, status: 'failed', error: lastError?.message });
    }

    if (lastError?.message && lastError.message.includes('API_KEY')) {
      throw new Error('अमान्य अथवा अनुपलब्ध API Key। कृपया GEMINI_API_KEY की जांच करें।');
    }
    throw new Error('हिंदी अनुवाद करने में समस्या हुई। कृपया दोबारा प्रयास करें।');
  }
}

export const translationService = new TranslationService();
