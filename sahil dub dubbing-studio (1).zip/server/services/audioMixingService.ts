import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { exec } from 'child_process';
import util from 'util';
import getMp3Duration from 'get-mp3-duration';
import googleTTS from 'google-tts-api';
import { videoProcessingService } from './videoService';

const execAsync = util.promisify(exec);

export interface MixSegmentInput {
  id?: number | string;
  startTime: number;
  endTime: number;
  hindiAudioPath?: string;
  audioPath?: string;
  audioBase64?: string;
  originalAudioLevel?: number; // e.g. 0.25 (ducking volume)
  hindiVoiceLevel?: number; // e.g. 1.00
  duckingApplied?: boolean;
  fadeInDuration?: number; // e.g. 0.2s
  fadeOutDuration?: number; // e.g. 0.3s
  status?: string;
  englishText?: string;
  hindiText?: string;
}

export interface MixAudioRequest {
  jobId?: string;
  originalAudioPath?: string;
  totalVideoDuration?: number;
  originalDuckingLevel?: number;
  hindiVoiceLevel?: number;
  fadeInDuration?: number;
  fadeOutDuration?: number;
  segments: MixSegmentInput[];
}

export interface MixedAudioResultData {
  mixedAudioPath: string;
  segments: any[];
  totalDuration: number;
  originalDuckingLevel: number;
  hindiVoiceLevel: number;
  backgroundMusicPreserved: boolean;
  status: string;
  createdAt: string;
}

export class AudioMixingService {
  private ttsCacheDir: string;

  constructor() {
    this.ttsCacheDir = path.resolve(process.cwd(), 'server', 'temp', 'tts_cache');
  }

  /**
   * Resolves the absolute path for an audio segment file on disk
   */
  private resolveSegmentAudioPath(audioPath: string): string | null {
    if (!audioPath) return null;

    // Check if it is a URL or relative path like /api/audio/filename.mp3
    if (audioPath.startsWith('/api/audio/')) {
      const filename = path.basename(audioPath);
      const inCache = path.join(this.ttsCacheDir, filename);
      if (fs.existsSync(inCache)) return inCache;
    }

    // Direct absolute path
    if (path.isAbsolute(audioPath) && fs.existsSync(audioPath)) {
      return audioPath;
    }

    // Check in ttsCacheDir by basename
    const inCache = path.join(this.ttsCacheDir, path.basename(audioPath));
    if (fs.existsSync(inCache)) return inCache;

    // Check in temp audio directory
    const inAudio = path.join(videoProcessingService.getAudioDir(), path.basename(audioPath));
    if (fs.existsSync(inAudio)) return inAudio;

    return null;
  }

  /**
   * Mixes original audio with Hindi TTS audio segments using FFmpeg audio ducking
   */
  async mixAudioWithDucking(payload: MixAudioRequest): Promise<MixedAudioResultData> {
    const {
      jobId,
      originalAudioPath,
      segments,
      originalDuckingLevel = 0.25,
      hindiVoiceLevel = 1.00,
      fadeInDuration = 0.2,
      fadeOutDuration = 0.3,
    } = payload;

    // 1. Validate segments
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      throw new Error('ऑडियो मिक्सिंग के लिए कोई संवाद उपलब्ध नहीं है। (Missing segments)');
    }

    const safeJobId = jobId ? jobId.replace(/[^a-zA-Z0-9_]/g, '') : '';

    // Update job status if jobId exists
    if (safeJobId) {
      const currentJob = videoProcessingService.getJob(safeJobId);
      if (currentJob) {
        videoProcessingService.saveJob({
          ...currentJob,
          status: 'mixing_audio',
        });
      }
    }

    // 2. Resolve original audio file on disk
    let resolvedOriginalAudio: string | null = null;

    if (originalAudioPath && fs.existsSync(originalAudioPath)) {
      resolvedOriginalAudio = originalAudioPath;
    } else if (safeJobId) {
      const extractedWav = videoProcessingService.getExtractedWavPath(safeJobId);
      if (extractedWav && fs.existsSync(extractedWav)) {
        resolvedOriginalAudio = extractedWav;
      } else {
        // Try auto-extracting from uploaded video if available
        const videoFile = videoProcessingService.findVideoByJobId(safeJobId);
        if (videoFile && fs.existsSync(videoFile)) {
          await videoProcessingService.extractAudio(safeJobId, videoFile);
          resolvedOriginalAudio = videoProcessingService.getExtractedWavPath(safeJobId);
        }
      }
    }

    // Fallback: check most recently extracted audio in temp folder
    if (!resolvedOriginalAudio) {
      resolvedOriginalAudio = videoProcessingService.getLatestAudioWav();
    }

    // 3. Resolve Hindi audio files for each segment and validate
    const resolvedSegments: Array<{
      input: MixSegmentInput;
      filePath: string;
      startTime: number;
      endTime: number;
      duration: number;
    }> = [];

    for (let i = 0; i < segments.length; i++) {
      const s = segments[i];
      const audioRef = s.hindiAudioPath || s.audioPath || '';
      let resolvedPath = this.resolveSegmentAudioPath(audioRef);

      const sTime = Math.max(0, Number(s.startTime) || 0);
      const eTime = Math.max(sTime + 0.1, Number(s.endTime) || sTime + 1.0);
      const segDuration = Number((eTime - sTime).toFixed(2));

      // 1. Recover from audioBase64 if present
      if ((!resolvedPath || !fs.existsSync(resolvedPath)) && s.audioBase64) {
        const tempName = `mix_seg_${s.id || i + 1}_recovered.mp3`;
        resolvedPath = path.join(this.ttsCacheDir, tempName);
        fs.writeFileSync(resolvedPath, Buffer.from(s.audioBase64, 'base64'));
      }

      // 2. Recover from hindiText auto-synthesis if present
      if ((!resolvedPath || !fs.existsSync(resolvedPath)) && s.hindiText) {
        try {
          const base64 = await googleTTS.getAudioBase64(s.hindiText, {
            lang: 'hi',
            slow: false,
            host: 'https://translate.google.com',
            timeout: 10000,
          });
          const tempName = `mix_seg_${s.id || i + 1}_auto_${Date.now()}.mp3`;
          resolvedPath = path.join(this.ttsCacheDir, tempName);
          fs.writeFileSync(resolvedPath, Buffer.from(base64, 'base64'));
        } catch (ttsErr) {
          console.warn(`[AudioMixingService] Could not auto-synthesize seg #${s.id}:`, ttsErr);
        }
      }

      // 3. Recover by generating silence if still missing
      if (!resolvedPath || !fs.existsSync(resolvedPath)) {
        const tempName = `mix_seg_${s.id || i + 1}_silent.mp3`;
        resolvedPath = path.join(this.ttsCacheDir, tempName);
        const safeDuration = Math.max(0.5, segDuration);
        await execAsync(`ffmpeg -y -f lavfi -i anullsrc=r=24000:cl=mono -t ${safeDuration} -q:a 9 "${resolvedPath}"`);
      }

      resolvedSegments.push({
        input: s,
        filePath: resolvedPath,
        startTime: sTime,
        endTime: eTime,
        duration: segDuration,
      });
    }

    // 4. Calculate total duration
    let totalDuration = Number(payload.totalVideoDuration) || 0;
    if (totalDuration <= 0) {
      if (resolvedOriginalAudio && fs.existsSync(resolvedOriginalAudio)) {
        try {
          const probe = await execAsync(
            `ffprobe -v quiet -print_format json -show_format "${resolvedOriginalAudio}"`
          );
          const meta = JSON.parse(probe.stdout);
          totalDuration = parseFloat(meta.format?.duration || '0');
        } catch (_) {
          totalDuration = 0;
        }
      }
      if (totalDuration <= 0) {
        const maxEnd = Math.max(...resolvedSegments.map((s) => s.endTime));
        totalDuration = Number((maxEnd + 1.0).toFixed(2));
      }
    }

    // If still no original audio file exists, create a silent baseline audio track
    let createdTempSilentAudio = false;
    let tempSilentFile = '';
    if (!resolvedOriginalAudio || !fs.existsSync(resolvedOriginalAudio)) {
      createdTempSilentAudio = true;
      tempSilentFile = path.join(
        videoProcessingService.getAudioDir(),
        `silent_base_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.wav`
      );
      await execAsync(
        `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=stereo -t ${totalDuration} "${tempSilentFile}"`
      );
      resolvedOriginalAudio = tempSilentFile;
    }

    // 5. Build FFmpeg command with filter_complex
    // Input 0: original audio
    // Inputs 1..N: Hindi speech segments
    const ffmpegInputs: string[] = [`-i "${resolvedOriginalAudio}"`];
    for (const r of resolvedSegments) {
      ffmpegInputs.push(`-i "${r.filePath}"`);
    }

    // Build ducking condition for original audio
    const duckIntervals: string[] = [];
    for (const r of resolvedSegments) {
      if (r.input.duckingApplied !== false) {
        // Between startTime and endTime
        duckIntervals.push(`between(t,${r.startTime.toFixed(3)},${r.endTime.toFixed(3)})`);
      }
    }

    const filterParts: string[] = [];

    // Step A: Original audio volume ducking
    if (duckIntervals.length > 0) {
      const duckCondition = duckIntervals.join('+');
      filterParts.push(
        `[0:a]volume=eval=frame:volume='if(${duckCondition},${originalDuckingLevel},1.0)'[orig_ducked]`
      );
    } else {
      filterParts.push(`[0:a]volume=1.0[orig_ducked]`);
    }

    // Step B: Delay each Hindi segment to its exact startTime
    const hindiLabels: string[] = [];
    for (let i = 0; i < resolvedSegments.length; i++) {
      const r = resolvedSegments[i];
      const delayMs = Math.max(0, Math.round(r.startTime * 1000));
      const label = `h${i}`;
      filterParts.push(`[${i + 1}:a]adelay=${delayMs}|${delayMs}[${label}]`);
      hindiLabels.push(`[${label}]`);
    }

    // Step C: Mix all Hindi speech segments together into a single track
    if (resolvedSegments.length === 1) {
      filterParts.push(`${hindiLabels[0]}volume=${hindiVoiceLevel}[hindi_mix]`);
    } else {
      filterParts.push(
        `${hindiLabels.join('')}amix=inputs=${resolvedSegments.length}:duration=longest:dropout_transition=0,volume=${hindiVoiceLevel}[hindi_mix]`
      );
    }

    // Step D: Mix ducked original audio + Hindi mix
    filterParts.push(`[orig_ducked][hindi_mix]amix=inputs=2:duration=first:dropout_transition=0[out]`);

    const filterComplex = filterParts.join(';');

    // Output destination
    const outJobId = safeJobId || `job_${crypto.randomBytes(8).toString('hex')}`;
    const outputFilename = `${outJobId}.mp3`;
    const outputPath = path.join(videoProcessingService.getMixedAudioDir(), outputFilename);

    const ffmpegCommand = `ffmpeg -y ${ffmpegInputs.join(' ')} -filter_complex "${filterComplex}" -map "[out]" -c:a libmp3lame -q:a 2 "${outputPath}"`;

    try {
      const { stderr } = await execAsync(ffmpegCommand);

      // Verify that output file was actually generated
      if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0) {
        throw new Error('FFmpeg ने मिक्स ऑडियो फ़ाइल नहीं बनाई या फ़ाइल शून्य आकार की है।');
      }

      // Calculate measured duration of the mixed audio
      let finalDuration = totalDuration;
      try {
        const outBuf = fs.readFileSync(outputPath);
        const ms = getMp3Duration(outBuf);
        if (ms && ms > 0) {
          finalDuration = Number((ms / 1000).toFixed(2));
        }
      } catch (_) {
        // Fallback to totalDuration
      }

      // Format output segments for the client response
      const outputSegments = resolvedSegments.map((r, idx) => ({
        id: r.input.id || idx + 1,
        startTime: r.startTime,
        endTime: r.endTime,
        hindiAudioPath: r.input.hindiAudioPath || r.input.audioPath,
        originalAudioLevel: originalDuckingLevel,
        hindiVoiceLevel: hindiVoiceLevel,
        duckingApplied: r.input.duckingApplied !== false,
        fadeInDuration,
        fadeOutDuration,
        status: 'mixed',
        englishText: r.input.englishText || '',
        hindiText: r.input.hindiText || '',
      }));

      const result: MixedAudioResultData = {
        mixedAudioPath: `/api/media/mixed_audio/${outputFilename}`,
        segments: outputSegments,
        totalDuration: finalDuration,
        originalDuckingLevel,
        hindiVoiceLevel,
        backgroundMusicPreserved: true,
        status: 'completed',
        createdAt: new Date().toISOString(),
      };

      // Save mixed audio result in VideoProcessingService
      if (safeJobId) {
        videoProcessingService.saveMixedAudioResult(safeJobId, result);
        const curJob = videoProcessingService.getJob(safeJobId);
        if (curJob) {
          videoProcessingService.saveJob({
            ...curJob,
            status: 'audio_mixed',
            mixedAudioPath: outputPath,
          });
        }
      }

      return result;
    } catch (ffmpegErr: any) {
      console.error('[AudioMixingService] FFmpeg execution error:', ffmpegErr);
      if (safeJobId) {
        const curJob = videoProcessingService.getJob(safeJobId);
        if (curJob) {
          videoProcessingService.saveJob({
            ...curJob,
            status: 'failed',
            error: ffmpegErr.message,
          });
        }
      }
      throw new Error(`FFmpeg ऑडियो मिक्सिंग निष्पादन विफल: ${ffmpegErr.message || 'अज्ञात त्रुटि'}`);
    } finally {
      // Clean up temporary silent baseline audio if created
      if (createdTempSilentAudio && tempSilentFile && fs.existsSync(tempSilentFile)) {
        try {
          fs.unlinkSync(tempSilentFile);
        } catch (_) {}
      }
    }
  }
}

export const audioMixingService = new AudioMixingService();
