import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { exec } from 'child_process';
import util from 'util';
import { videoProcessingService } from './videoService';

const execAsync = util.promisify(exec);

export interface RenderVideoRequest {
  jobId?: string;
  videoName?: string;
  videoPath?: string;
  originalVideoPath?: string;
  mixedAudioPath?: string;
  duration?: number;
}

export interface RenderedVideoResultData {
  id: string;
  jobId: string;
  videoName: string;
  originalVideoPath: string;
  mixedAudioPath: string;
  outputVideoPath: string;
  filename: string;
  duration: number;
  durationFormatted: string;
  fileSizeBytes: number;
  fileSizeFormatted: string;
  isSavedToGallery: boolean;
  status: string;
  createdAt: string;
}

export class VideoRenderingService {
  /**
   * Helper to format duration in MM:SS
   */
  private formatDuration(seconds: number): string {
    const mins = Math.floor(seconds / 60)
      .toString()
      .padStart(2, '0');
    const secs = Math.floor(seconds % 60)
      .toString()
      .padStart(2, '0');
    return `${mins}:${secs}`;
  }

  /**
   * Helper to format file size in KB or MB
   */
  private formatFileSize(bytes: number): string {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  /**
   * Resolves the original uploaded video path on disk
   */
  private resolveVideoPath(payload: RenderVideoRequest, safeJobId: string): string | null {
    if (payload.videoPath) {
      if (fs.existsSync(payload.videoPath)) return payload.videoPath;
      return null;
    }
    if (payload.originalVideoPath) {
      if (fs.existsSync(payload.originalVideoPath)) return payload.originalVideoPath;
      return null;
    }

    if (safeJobId) {
      const job = videoProcessingService.getJob(safeJobId);
      if (job?.videoPath && fs.existsSync(job.videoPath)) {
        return job.videoPath;
      }
      const match = videoProcessingService.findVideoByJobId(safeJobId);
      if (match && fs.existsSync(match)) {
        return match;
      }
      return null;
    }

    // Fallback: check most recently uploaded video if no jobId or path specified
    const latest = videoProcessingService.getLatestVideoUploaded();
    if (latest && fs.existsSync(latest)) {
      return latest;
    }

    return null;
  }

  /**
   * Resolves the mixed Hindi audio path on disk
   */
  private resolveMixedAudioPath(payload: RenderVideoRequest, safeJobId: string): string | null {
    if (payload.mixedAudioPath) {
      const p = payload.mixedAudioPath;
      if (fs.existsSync(p)) return p;

      // Handle web URL paths e.g. /api/media/mixed_audio/job_123.mp3
      const filename = path.basename(p);
      const inMixed = path.join(videoProcessingService.getMixedAudioDir(), filename);
      if (fs.existsSync(inMixed)) return inMixed;

      // Also check temp audio dir
      const inAudio = path.join(videoProcessingService.getAudioDir(), filename);
      if (fs.existsSync(inAudio)) return inAudio;

      return null;
    }

    if (safeJobId) {
      const job = videoProcessingService.getJob(safeJobId);
      if (job?.mixedAudioPath && fs.existsSync(job.mixedAudioPath)) {
        return job.mixedAudioPath;
      }
      const byJob = videoProcessingService.findMixedAudioByJobId(safeJobId);
      if (byJob && fs.existsSync(byJob)) {
        return byJob;
      }
      const mixResult = videoProcessingService.getMixedAudioResult(safeJobId);
      if (mixResult?.mixedAudioPath) {
        const inMixed = path.join(
          videoProcessingService.getMixedAudioDir(),
          path.basename(mixResult.mixedAudioPath)
        );
        if (fs.existsSync(inMixed)) return inMixed;
      }
      return null;
    }

    return null;
  }

  /**
   * Combines original video visuals with the mixed Hindi audio using FFmpeg
   */
  async renderFinalVideo(payload: RenderVideoRequest): Promise<RenderedVideoResultData> {
    const safeJobId = payload.jobId ? payload.jobId.replace(/[^a-zA-Z0-9_]/g, '') : '';

    // 1. Validate and resolve original video
    const resolvedVideo = this.resolveVideoPath(payload, safeJobId);
    if (!resolvedVideo || !fs.existsSync(resolvedVideo)) {
      throw new Error(
        'मूल वीडियो फ़ाइल नहीं मिली। कृपया पहले वीडियो अपलोड करें (Missing original video file).'
      );
    }

    // 2. Validate and resolve mixed audio
    const resolvedAudio = this.resolveMixedAudioPath(payload, safeJobId);
    if (!resolvedAudio || !fs.existsSync(resolvedAudio)) {
      throw new Error(
        'मिक्स ऑडियो फ़ाइल नहीं मिली। कृपया पहले स्टेज 7 (ऑडियो मिक्सिंग) पूरा करें (Missing mixed audio file).'
      );
    }

    // Update job status if jobId exists
    if (safeJobId) {
      const curJob = videoProcessingService.getJob(safeJobId);
      if (curJob) {
        videoProcessingService.saveJob({
          ...curJob,
          status: 'rendering_video',
        });
      }
    }

    const outJobId = safeJobId || `job_${crypto.randomBytes(8).toString('hex')}`;
    const outputFilename = `Hindi_Dubbed_${outJobId}.mp4`;
    const outputPath = path.join(videoProcessingService.getRenderedVideosDir(), outputFilename);

    // Attempt Fast Stream Copy first (lossless visual copy, AAC audio muxing, +faststart)
    const copyCmd = `ffmpeg -y -i "${resolvedVideo}" -i "${resolvedAudio}" -c:v copy -c:a aac -b:a 192k -map 0:v:0 -map 1:a:0 -shortest -movflags +faststart "${outputPath}"`;

    let renderSuccess = false;
    let renderError: any = null;

    try {
      await execAsync(copyCmd);
      if (fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
        renderSuccess = true;
      }
    } catch (err: any) {
      console.warn('[VideoRenderingService] Direct stream copy failed, falling back to H.264 re-encoding:', err?.message);
      renderError = err;
    }

    // Fallback: Re-encode video stream with fast H.264 if direct stream copy fails
    if (!renderSuccess) {
      const reencodeCmd = `ffmpeg -y -i "${resolvedVideo}" -i "${resolvedAudio}" -c:v libx264 -preset fast -crf 22 -pix_fmt yuv420p -c:a aac -b:a 192k -map 0:v:0 -map 1:a:0 -shortest -movflags +faststart "${outputPath}"`;
      try {
        await execAsync(reencodeCmd);
        if (fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
          renderSuccess = true;
        }
      } catch (err2: any) {
        console.error('[VideoRenderingService] Re-encoding also failed:', err2);
        renderError = err2;
      }
    }

    if (!renderSuccess || !fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0) {
      if (safeJobId) {
        const curJob = videoProcessingService.getJob(safeJobId);
        if (curJob) {
          videoProcessingService.saveJob({
            ...curJob,
            status: 'failed',
            error: renderError?.message || 'वीडियो रेंडरिंग विफल रही',
          });
        }
      }
      throw new Error(`FFmpeg वीडियो रेंडरिंग निष्पादन विफल: ${renderError?.message || 'शून्य बाइट आउटपुट'}`);
    }

    // 3. Probe rendered output video to verify container, streams, and duration
    let probedDuration = Number(payload.duration) || 0;
    try {
      const probeRes = await execAsync(
        `ffprobe -v quiet -print_format json -show_format -show_streams "${outputPath}"`
      );
      const meta = JSON.parse(probeRes.stdout);
      const hasVideo = meta.streams?.some((s: any) => s.codec_type === 'video');
      const hasAudio = meta.streams?.some((s: any) => s.codec_type === 'audio');

      if (!hasVideo || !hasAudio) {
        throw new Error('रेंडर किए गए वीडियो में वीडियो या ऑडियो स्ट्रीम अनुपलब्ध है।');
      }

      const dur = parseFloat(meta.format?.duration || '0');
      if (dur > 0) {
        probedDuration = Number(dur.toFixed(2));
      }
    } catch (probeErr: any) {
      console.warn('[VideoRenderingService] Probing warning:', probeErr?.message);
    }

    const stat = fs.statSync(outputPath);
    const originalVideoName = payload.videoName || path.basename(resolvedVideo);

    const result: RenderedVideoResultData = {
      id: `vid_${outJobId}`,
      jobId: outJobId,
      videoName: originalVideoName,
      originalVideoPath: resolvedVideo,
      mixedAudioPath: resolvedAudio,
      outputVideoPath: `/api/media/rendered_video/${outputFilename}`,
      filename: outputFilename,
      duration: probedDuration,
      durationFormatted: this.formatDuration(probedDuration),
      fileSizeBytes: stat.size,
      fileSizeFormatted: this.formatFileSize(stat.size),
      isSavedToGallery: false,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };

    // Save result against jobId
    if (safeJobId) {
      videoProcessingService.saveRenderedVideoResult(safeJobId, result);
      const curJob = videoProcessingService.getJob(safeJobId);
      if (curJob) {
        videoProcessingService.saveJob({
          ...curJob,
          status: 'video_rendered',
          renderedVideoPath: outputPath,
        });
      }
    }

    return result;
  }
}

export const videoRenderingService = new VideoRenderingService();
