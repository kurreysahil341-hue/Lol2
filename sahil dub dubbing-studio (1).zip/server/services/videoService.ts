import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);

export interface VideoMetadata {
  duration: number;
  width?: number;
  height?: number;
  fileSize: number;
  hasAudio: boolean;
  videoCodec?: string;
  audioCodec?: string;
  frameRate?: string;
  formatName?: string;
}

export type JobStatus = 
  | 'uploaded' 
  | 'audio_extracted' 
  | 'transcribing' 
  | 'transcript_ready' 
  | 'translating' 
  | 'translation_ready' 
  | 'mixing_audio'
  | 'audio_mixed'
  | 'rendering_video'
  | 'video_rendered'
  | 'failed';

export interface JobState {
  jobId: string;
  status: JobStatus;
  createdAt: string;
  updatedAt: string;
  videoPath?: string;
  audioPath?: string;
  mixedAudioPath?: string;
  renderedVideoPath?: string;
  duration?: number;
  error?: string;
  segmentCount?: number;
}

export class VideoProcessingService {
  private tempUploadDir: string;
  private tempAudioDir: string;
  private tempJobsDir: string;
  private tempTranscriptsDir: string;
  private tempTranslationsDir: string;
  private tempMixedAudioDir: string;
  private tempRenderedVideosDir: string;

  constructor() {
    this.tempUploadDir = path.resolve(process.cwd(), 'server', 'temp', 'uploads');
    this.tempAudioDir = path.resolve(process.cwd(), 'server', 'temp', 'audio');
    this.tempJobsDir = path.resolve(process.cwd(), 'server', 'temp', 'jobs');
    this.tempTranscriptsDir = path.resolve(process.cwd(), 'server', 'temp', 'transcripts');
    this.tempTranslationsDir = path.resolve(process.cwd(), 'server', 'temp', 'translations');
    this.tempMixedAudioDir = path.resolve(process.cwd(), 'server', 'temp', 'mixed_audio');
    this.tempRenderedVideosDir = path.resolve(process.cwd(), 'server', 'temp', 'rendered_videos');

    for (const dir of [
      this.tempUploadDir,
      this.tempAudioDir,
      this.tempJobsDir,
      this.tempTranscriptsDir,
      this.tempTranslationsDir,
      this.tempMixedAudioDir,
      this.tempRenderedVideosDir,
    ]) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }

  public generateJobId(): string {
    return `job_${crypto.randomBytes(8).toString('hex')}`;
  }

  public getUploadDir(): string {
    return this.tempUploadDir;
  }

  public getAudioDir(): string {
    return this.tempAudioDir;
  }

  public saveJob(job: JobState): void {
    const safeJobId = job.jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const jobPath = path.join(this.tempJobsDir, `${safeJobId}.json`);
    job.updatedAt = new Date().toISOString();
    fs.writeFileSync(jobPath, JSON.stringify(job, null, 2), 'utf-8');
  }

  public getJob(jobId: string): JobState | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const jobPath = path.join(this.tempJobsDir, `${safeJobId}.json`);
    if (fs.existsSync(jobPath)) {
      try {
        return JSON.parse(fs.readFileSync(jobPath, 'utf-8')) as JobState;
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  public saveTranscript(jobId: string, transcript: any): void {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const transcriptPath = path.join(this.tempTranscriptsDir, `${safeJobId}.json`);
    fs.writeFileSync(transcriptPath, JSON.stringify(transcript, null, 2), 'utf-8');
  }

  public getTranscript(jobId: string): any | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const transcriptPath = path.join(this.tempTranscriptsDir, `${safeJobId}.json`);
    if (fs.existsSync(transcriptPath)) {
      try {
        return JSON.parse(fs.readFileSync(transcriptPath, 'utf-8'));
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  public saveTranslation(jobId: string, translation: any): void {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const translationPath = path.join(this.tempTranslationsDir, `${safeJobId}.json`);
    fs.writeFileSync(translationPath, JSON.stringify(translation, null, 2), 'utf-8');
  }

  public getTranslation(jobId: string): any | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const translationPath = path.join(this.tempTranslationsDir, `${safeJobId}.json`);
    if (fs.existsSync(translationPath)) {
      try {
        return JSON.parse(fs.readFileSync(translationPath, 'utf-8'));
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  public saveMixedAudioResult(jobId: string, result: any): void {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const mixPath = path.join(this.tempMixedAudioDir, `${safeJobId}.json`);
    fs.writeFileSync(mixPath, JSON.stringify(result, null, 2), 'utf-8');
  }

  public getMixedAudioResult(jobId: string): any | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const mixPath = path.join(this.tempMixedAudioDir, `${safeJobId}.json`);
    if (fs.existsSync(mixPath)) {
      try {
        return JSON.parse(fs.readFileSync(mixPath, 'utf-8'));
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  public getMixedAudioDir(): string {
    return this.tempMixedAudioDir;
  }

  public saveRenderedVideoResult(jobId: string, result: any): void {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const renderPath = path.join(this.tempRenderedVideosDir, `${safeJobId}.json`);
    fs.writeFileSync(renderPath, JSON.stringify(result, null, 2), 'utf-8');
  }

  public getRenderedVideoResult(jobId: string): any | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const renderPath = path.join(this.tempRenderedVideosDir, `${safeJobId}.json`);
    if (fs.existsSync(renderPath)) {
      try {
        return JSON.parse(fs.readFileSync(renderPath, 'utf-8'));
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  public getRenderedVideosDir(): string {
    return this.tempRenderedVideosDir;
  }

  /**
   * Safely inspects video file using ffprobe with direct argument array
   */
  public async inspectVideo(filePath: string): Promise<VideoMetadata> {
    const args = [
      '-v', 'quiet',
      '-print_format', 'json',
      '-show_format',
      '-show_streams',
      filePath,
    ];

    try {
      const { stdout } = await execFileAsync('ffprobe', args, { timeout: 15000 });
      const data = JSON.parse(stdout);

      const fmt = data.format || {};
      const streams = data.streams || [];

      let duration = parseFloat(fmt.duration || '0');
      let videoStream: any = null;
      let audioStream: any = null;

      for (const s of streams) {
        if (s.codec_type === 'video' && !videoStream) videoStream = s;
        if (s.codec_type === 'audio' && !audioStream) audioStream = s;
      }

      if (duration <= 0) {
        if (videoStream?.duration) duration = parseFloat(videoStream.duration);
        else if (audioStream?.duration) duration = parseFloat(audioStream.duration);
      }

      const stats = fs.statSync(filePath);

      return {
        duration: Math.round(duration * 100) / 100,
        width: videoStream?.width,
        height: videoStream?.height,
        fileSize: stats.size,
        hasAudio: Boolean(audioStream),
        videoCodec: videoStream?.codec_name,
        audioCodec: audioStream?.codec_name,
        frameRate: videoStream?.r_frame_rate,
        formatName: fmt.format_name,
      };
    } catch (err: any) {
      throw new Error(`ffprobe मीडिया विश्लेषण में विफल: ${err.message}`);
    }
  }

  /**
   * Extracts audio from video to 16kHz mono 16-bit PCM WAV suitable for STT
   */
  public async extractAudio(jobId: string, inputVideoPath: string): Promise<{ audioPath: string; duration: number }> {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const outputAudioPath = path.join(this.tempAudioDir, `${safeJobId}.wav`);

    const args = [
      '-y',
      '-i', inputVideoPath,
      '-vn',
      '-acodec', 'pcm_s16le',
      '-ar', '16000',
      '-ac', '1',
      outputAudioPath,
    ];

    try {
      await execFileAsync('ffmpeg', args, { timeout: 60000 });
      const meta = await this.inspectVideo(outputAudioPath);

      this.saveJob({
        jobId: safeJobId,
        status: 'audio_extracted',
        createdAt: this.getJob(safeJobId)?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        videoPath: inputVideoPath,
        audioPath: outputAudioPath,
        duration: meta.duration,
      });

      return {
        audioPath: `/api/media/audio/${safeJobId}.wav`,
        duration: meta.duration,
      };
    } catch (err: any) {
      throw new Error(`ffmpeg ऑडियो निष्कर्षण में विफल: ${err.message}`);
    }
  }

  public findVideoByJobId(jobId: string): string | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const files = fs.readdirSync(this.tempUploadDir);
    const match = files.find((f) => f.startsWith(safeJobId));
    if (match) {
      return path.join(this.tempUploadDir, match);
    }
    return null;
  }

  public getAudioFilePath(filename: string): string | null {
    const safeFilename = path.basename(filename);
    const fullPath = path.join(this.tempAudioDir, safeFilename);
    if (fs.existsSync(fullPath)) {
      return fullPath;
    }
    return null;
  }

  public getExtractedWavPath(jobId: string): string | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const audioPath = path.join(this.tempAudioDir, `${safeJobId}.wav`);
    if (fs.existsSync(audioPath)) {
      return audioPath;
    }
    return null;
  }

  public getMixedAudioFilePath(filename: string): string | null {
    const safeFilename = path.basename(filename);
    const fullPath = path.join(this.tempMixedAudioDir, safeFilename);
    if (fs.existsSync(fullPath)) {
      return fullPath;
    }
    return null;
  }

  public getLatestAudioWav(): string | null {
    if (!fs.existsSync(this.tempAudioDir)) return null;
    const files = fs.readdirSync(this.tempAudioDir).filter((f) => f.endsWith('.wav'));
    if (files.length === 0) return null;
    files.sort((a, b) => {
      const aStat = fs.statSync(path.join(this.tempAudioDir, a));
      const bStat = fs.statSync(path.join(this.tempAudioDir, b));
      return bStat.mtimeMs - aStat.mtimeMs;
    });
    return path.join(this.tempAudioDir, files[0]);
  }

  public getRenderedVideoFilePath(filename: string): string | null {
    const safeFilename = path.basename(filename);
    const fullPath = path.join(this.tempRenderedVideosDir, safeFilename);
    if (fs.existsSync(fullPath)) {
      return fullPath;
    }
    return null;
  }

  public findMixedAudioByJobId(jobId: string): string | null {
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const mp3Path = path.join(this.tempMixedAudioDir, `${safeJobId}.mp3`);
    if (fs.existsSync(mp3Path)) {
      return mp3Path;
    }
    return null;
  }

  public getLatestVideoUploaded(): string | null {
    if (!fs.existsSync(this.tempUploadDir)) return null;
    const files = fs.readdirSync(this.tempUploadDir).filter((f) => !f.startsWith('.'));
    if (files.length === 0) return null;
    files.sort((a, b) => {
      const aStat = fs.statSync(path.join(this.tempUploadDir, a));
      const bStat = fs.statSync(path.join(this.tempUploadDir, b));
      return bStat.mtimeMs - aStat.mtimeMs;
    });
    return path.join(this.tempUploadDir, files[0]);
  }
}

export const videoProcessingService = new VideoProcessingService();
