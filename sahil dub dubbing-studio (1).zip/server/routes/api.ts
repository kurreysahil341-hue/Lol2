import express, { Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { transcriptionService } from '../services/transcriptionService';
import { translationService } from '../services/translationService';
import { ttsService } from '../services/ttsService';
import { audioSyncService } from '../services/syncService';
import { videoProcessingService } from '../services/videoService';
import { audioMixingService } from '../services/audioMixingService';
import { videoRenderingService } from '../services/videoRenderingService';
import { config } from '../config';

export const apiRouter = express.Router();

// Configure safe multer storage for video uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, videoProcessingService.getUploadDir());
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^a-z0-9.]/g, '');
    const jobId = videoProcessingService.generateJobId();
    // Attach jobId to request so it can be used in handler
    (req as any).jobId = jobId;
    cb(null, `${jobId}_input${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500 MB max file size limit
  },
  fileFilter: (req, file, cb) => {
    const allowed = ['.mp4', '.mov', '.webm'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowed.includes(ext)) {
      cb(new Error(`असमर्थित वीडियो प्रारूप '${ext}'। केवल MP4, MOV या WebM प्रारूप समर्थित हैं।`));
      return;
    }
    cb(null, true);
  },
});

/**
 * Health check endpoint (Phase 1)
 */
apiRouter.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'AI Video Dubbing Backend',
    phase: 1,
  });
});

/**
 * Video Upload & Validation Endpoint (Phase 1)
 * Accepts multipart/form-data with field 'video'.
 * Inspects media via ffprobe and enforces strict duration <= 600s (10 minutes).
 */
apiRouter.post('/video/upload', (req: Request, res: Response, next) => {
  upload.single('video')(req, res, async (err: any) => {
    if (err) {
      res.status(400).json({
        success: false,
        error: err.message || 'वीडियो अपलोड करने में त्रुटि।',
      });
      return;
    }

    try {
      if (!req.file) {
        res.status(400).json({
          success: false,
          error: 'कोई वीडियो फ़ाइल नहीं मिली। कृपया फ़ील्ड "video" में फ़ाइल भेजें।',
        });
        return;
      }

      const filePath = req.file.path;
      const jobId = (req as any).jobId || path.basename(filePath).split('_')[0];

      // Inspect media with ffprobe
      const info = await videoProcessingService.inspectVideo(filePath);

      // Validate 10-minute maximum duration constraint (600s)
      if (info.duration > 600) {
        // Remove invalid oversized file safely
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
        res.status(400).json({
          success: false,
          error: 'Video duration cannot exceed 10 minutes.',
        });
        return;
      }

      res.json({
        success: true,
        jobId,
        video: {
          duration: info.duration,
          width: info.width,
          height: info.height,
          fileSize: info.fileSize,
          hasAudio: info.hasAudio,
          videoCodec: info.videoCodec,
          audioCodec: info.audioCodec,
          frameRate: info.frameRate,
        },
      });
    } catch (error: any) {
      console.error('[API /video/upload] Error:', error);
      if (req.file && fs.existsSync(req.file.path)) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (_) {}
      }
      res.status(400).json({
        success: false,
        error: error.message || 'वीडियो सत्यापन में त्रुटि हुई।',
      });
    }
  });
});

/**
 * Audio Extraction Endpoint (Phase 1)
 * Safely extracts audio into 16kHz mono WAV suitable for STT.
 */
apiRouter.post('/video/:jobId/extract-audio', async (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const videoPath = videoProcessingService.findVideoByJobId(jobId);

    if (!videoPath) {
      res.status(404).json({
        success: false,
        error: 'इस Job ID के लिए कोई वीडियो फ़ाइल नहीं मिली।',
      });
      return;
    }

    const result = await videoProcessingService.extractAudio(jobId, videoPath);

    res.json({
      success: true,
      jobId,
      audioPath: result.audioPath,
      duration: result.duration,
    });
  } catch (error: any) {
    console.error('[API /video/extract-audio] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'ऑडियो निष्कर्षण में त्रुटि हुई।',
    });
  }
});

/**
 * Stream Extracted WAV Audio (Phase 1)
 */
apiRouter.get('/media/audio/:filename', (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    const filePath = videoProcessingService.getAudioFilePath(filename);

    if (!filePath) {
      res.status(404).json({
        success: false,
        error: 'ऑडियो फ़ाइल नहीं मिली।',
      });
      return;
    }

    res.setHeader('Content-Type', 'audio/wav');
    res.setHeader('Accept-Ranges', 'bytes');
    res.sendFile(filePath);
  } catch (err: any) {
    res.status(500).send('Audio playback error');
  }
});

/**
 * Phase 2 — Transcribe Extracted Audio by jobId
 * Reads extracted 16kHz mono WAV, applies real Gemini English Speech-to-Text,
 * validates timestamps, and saves transcript against jobId.
 */
apiRouter.post('/video/:jobId/transcribe', async (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');

    let audioPath = videoProcessingService.getExtractedWavPath(safeJobId);
    let job = videoProcessingService.getJob(safeJobId);

    // If audio is not yet extracted, check if uploaded video exists and auto-extract
    if (!audioPath || !fs.existsSync(audioPath)) {
      const videoPath = videoProcessingService.findVideoByJobId(safeJobId);
      if (!videoPath) {
        res.status(404).json({
          success: false,
          error: 'इस Job ID के लिए कोई वीडियो या ऑडियो फ़ाइल नहीं मिली।',
        });
        return;
      }
      await videoProcessingService.extractAudio(safeJobId, videoPath);
      audioPath = videoProcessingService.getExtractedWavPath(safeJobId);
      job = videoProcessingService.getJob(safeJobId);
    }

    const duration = job?.duration || 0;

    const result = await transcriptionService.processAudioTranscription({
      jobId: safeJobId,
      durationSeconds: duration,
      videoName: job?.videoPath ? path.basename(job.videoPath) : `${safeJobId}.mp4`,
    });

    res.json({
      success: true,
      jobId: safeJobId,
      language: result.language,
      duration: result.duration,
      segments: result.segments,
    });
  } catch (error: any) {
    console.error('[API /video/:jobId/transcribe] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'English आवाज़ को पहचानने में समस्या हुई। कृपया दोबारा प्रयास करें।',
    });
  }
});

/**
 * Phase 2 — Retrieve Saved Transcript by jobId
 */
apiRouter.get('/video/:jobId/transcript', (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const transcript = videoProcessingService.getTranscript(safeJobId);

    if (!transcript) {
      res.status(404).json({
        success: false,
        error: 'इस Job ID के लिए कोई ट्रांसक्रिप्ट उपलब्ध नहीं है।',
      });
      return;
    }

    res.json(transcript);
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: 'ट्रांसक्रिप्ट लोड करने में त्रुटि।',
    });
  }
});

/**
 * Phase 2 — Retrieve Job Status by jobId
 */
apiRouter.get('/video/:jobId/status', (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const job = videoProcessingService.getJob(safeJobId);

    if (!job) {
      res.status(404).json({
        success: false,
        error: 'Job ID नहीं मिली।',
      });
      return;
    }

    res.json({
      success: true,
      job,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: 'Job स्टेटस प्राप्त करने में त्रुटि।',
    });
  }
});

/**
 * Transcribe Audio Endpoint (Existing Pipeline Component)
 */
apiRouter.post('/transcribe', async (req: Request, res: Response) => {
  try {
    const { audioBase64, mimeType, durationSeconds, videoName } = req.body;

    if (!audioBase64) {
      res.status(400).json({
        success: false,
        error: 'ऑडियो डेटा अनिवार्य है।',
        errorCode: 'MISSING_AUDIO',
      });
      return;
    }

    if (durationSeconds && durationSeconds > config.maxAudioDurationSeconds) {
      res.status(400).json({
        success: false,
        error: 'अभी अधिकतम 10 मिनट की वीडियो ही समर्थित है।',
        errorCode: 'DURATION_EXCEEDED',
      });
      return;
    }

    const transcript = await transcriptionService.processAudioTranscription({
      audioBase64,
      mimeType: mimeType || 'audio/wav',
      durationSeconds: Number(durationSeconds) || 0,
      videoName: videoName || 'video.mp4',
    });

    res.json({
      success: true,
      transcript,
    });
  } catch (error: any) {
    console.error('[API /transcribe] Processing error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'English आवाज़ को पहचानने में समस्या हुई। कृपया दोबारा प्रयास करें।',
      errorCode: error.code || 'TRANSCRIPTION_FAILED',
    });
  }
});

/**
 * Phase 3 — Translate Timestamped English Transcript to Hindi by jobId
 * Reads Phase 2 transcript, uses Gemini with dubbing rules, preserves timestamps,
 * and saves translation against jobId.
 */
apiRouter.post('/video/:jobId/translate', async (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');

    const transcript = videoProcessingService.getTranscript(safeJobId);
    if (!transcript || !transcript.segments || transcript.segments.length === 0) {
      res.status(404).json({
        success: false,
        error: 'इस Job ID के लिए कोई ट्रांसक्रिप्ट उपलब्ध नहीं है। कृपया पहले ट्रांसक्राइब करें।',
      });
      return;
    }

    const job = videoProcessingService.getJob(safeJobId);
    const videoName = job?.videoPath ? path.basename(job.videoPath) : `${safeJobId}.mp4`;

    const result = await translationService.translateToHindi({
      jobId: safeJobId,
      segments: transcript.segments,
      duration: transcript.duration || job?.duration || 0,
      videoName,
    });

    res.json({
      success: true,
      jobId: safeJobId,
      sourceLanguage: 'en',
      targetLanguage: 'hi',
      duration: result.duration,
      segments: result.segments,
      translation: result,
    });
  } catch (error: any) {
    console.error('[API /video/:jobId/translate] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'हिंदी अनुवाद करने में समस्या हुई। कृपया दोबारा प्रयास करें।',
    });
  }
});

/**
 * Phase 3 — Retrieve Saved Translation by jobId
 */
apiRouter.get('/video/:jobId/translation', (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const translation = videoProcessingService.getTranslation(safeJobId);

    if (!translation) {
      res.status(404).json({
        success: false,
        error: 'इस Job ID के लिए कोई अनुवाद उपलब्ध नहीं है।',
      });
      return;
    }

    res.json(translation);
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: 'अनुवाद लोड करने में त्रुटि।',
    });
  }
});

/**
 * Translate Transcript Endpoint (Existing Pipeline Component)
 */
apiRouter.post('/translate', async (req: Request, res: Response) => {
  try {
    const { segments, transcript, duration, videoName } = req.body;
    const inputSegments = segments || transcript?.segments;

    if (!inputSegments || !Array.isArray(inputSegments) || inputSegments.length === 0) {
      res.status(400).json({
        success: false,
        error: 'अनुवाद के लिए कोई ट्रांसक्रिप्ट उपलब्ध नहीं है।',
        errorCode: 'EMPTY_TRANSCRIPT',
      });
      return;
    }

    const inputDuration = Number(duration || transcript?.duration || 0);
    const inputVideoName = videoName || transcript?.videoName || 'video.mp4';

    const dubbedTranscript = await translationService.translateToHindi({
      segments: inputSegments,
      duration: inputDuration,
      videoName: inputVideoName,
    });

    res.json({
      success: true,
      translation: dubbedTranscript,
    });
  } catch (error: any) {
    console.error('[API /translate] Translation error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'हिंदी अनुवाद करने में समस्या हुई। कृपया दोबारा प्रयास करें।',
      errorCode: error.code || 'TRANSLATION_FAILED',
    });
  }
});

/**
 * Text-to-Speech Endpoint (Existing Pipeline Component)
 */
apiRouter.post('/tts', async (req: Request, res: Response) => {
  try {
    const { segments, voiceSettings, provider } = req.body;

    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      res.status(400).json({
        success: false,
        error: 'हिंदी आवाज़ बनाने के लिए कोई संवाद उपलब्ध नहीं है।',
        errorCode: 'EMPTY_SEGMENTS',
      });
      return;
    }

    const result = await ttsService.generateHindiAudioSegments(
      segments,
      voiceSettings,
      provider || 'google-hindi'
    );

    res.json({
      success: true,
      result,
    });
  } catch (error: any) {
    console.error('[API /tts] TTS generation error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'हिंदी आवाज़ बनाने में समस्या हुई। कृपया दोबारा प्रयास करें।',
      errorCode: error.code || 'TTS_FAILED',
    });
  }
});

/**
 * Static Audio Server Endpoint
 */
apiRouter.get('/audio/:filename', (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    const filePath = ttsService.getAudioFilePath(filename);

    if (!filePath) {
      res.status(404).json({
        success: false,
        error: 'ऑडियो फाइल नहीं मिली।',
      });
      return;
    }

    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.sendFile(filePath);
  } catch (err: any) {
    console.error('[API /audio] Audio streaming error:', err);
    res.status(500).send('Audio playback error');
  }
});

/**
 * Hindi Voice Synchronization Endpoint (Existing Pipeline Component)
 */
apiRouter.post('/sync', async (req: Request, res: Response) => {
  try {
    const { segments } = req.body;

    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      res.status(400).json({
        success: false,
        error: 'सिंक्रोनाइज़ेशन के लिए कोई ऑडियो सेगमेंट उपलब्ध नहीं है।',
        errorCode: 'EMPTY_SEGMENTS',
      });
      return;
    }

    const result = await audioSyncService.synchronizeSegments(segments);

    res.json({
      success: true,
      result,
    });
  } catch (error: any) {
    console.error('[API /sync] Synchronization error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'हिंदी आवाज़ सिंक्रोनाइज़ करने में समस्या हुई। कृपया दोबारा प्रयास करें।',
      errorCode: error.code || 'SYNC_FAILED',
    });
  }
});

/**
 * Stage 7 — Audio Mixing & Ducking Endpoint
 * Mixes original audio (at ducked volume) with timestamped Hindi speech segments using FFmpeg.
 * Called directly by Flutter app (BackendAudioMixingService).
 */
apiRouter.post('/mix-audio', async (req: Request, res: Response) => {
  try {
    const {
      jobId,
      originalAudioPath,
      totalVideoDuration,
      originalDuckingLevel,
      hindiVoiceLevel,
      fadeInDuration,
      fadeOutDuration,
      segments,
    } = req.body;

    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      res.status(400).json({
        success: false,
        error: 'ऑडियो मिक्सिंग के लिए कोई संवाद उपलब्ध नहीं है।',
        errorCode: 'EMPTY_SEGMENTS',
      });
      return;
    }

    const result = await audioMixingService.mixAudioWithDucking({
      jobId,
      originalAudioPath,
      totalVideoDuration: Number(totalVideoDuration) || 0,
      originalDuckingLevel: originalDuckingLevel !== undefined ? Number(originalDuckingLevel) : 0.25,
      hindiVoiceLevel: hindiVoiceLevel !== undefined ? Number(hindiVoiceLevel) : 1.00,
      fadeInDuration: fadeInDuration !== undefined ? Number(fadeInDuration) : 0.2,
      fadeOutDuration: fadeOutDuration !== undefined ? Number(fadeOutDuration) : 0.3,
      segments,
    });

    res.json({
      success: true,
      result,
      mixedAudioPath: result.mixedAudioPath,
    });
  } catch (error: any) {
    console.error('[API /mix-audio] Audio mixing error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'ऑडियो मिक्सिंग करने में समस्या हुई। कृपया दोबारा प्रयास करें।',
      errorCode: 'MIXING_FAILED',
    });
  }
});

/**
 * Stage 7 — Job-specific Audio Mixing Endpoint
 */
apiRouter.post('/video/:jobId/mix-audio', async (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');

    const {
      originalAudioPath,
      totalVideoDuration,
      originalDuckingLevel,
      hindiVoiceLevel,
      fadeInDuration,
      fadeOutDuration,
      segments,
    } = req.body;

    let inputSegments = segments;

    // If segments are not provided in body, check if there is synced audio or tts result stored
    if (!inputSegments || !Array.isArray(inputSegments) || inputSegments.length === 0) {
      res.status(400).json({
        success: false,
        error: 'मिक्सिंग के लिए ऑडियो सेगमेंट आवश्यक हैं।',
        errorCode: 'EMPTY_SEGMENTS',
      });
      return;
    }

    const result = await audioMixingService.mixAudioWithDucking({
      jobId: safeJobId,
      originalAudioPath,
      totalVideoDuration: Number(totalVideoDuration) || 0,
      originalDuckingLevel: originalDuckingLevel !== undefined ? Number(originalDuckingLevel) : 0.25,
      hindiVoiceLevel: hindiVoiceLevel !== undefined ? Number(hindiVoiceLevel) : 1.00,
      fadeInDuration: fadeInDuration !== undefined ? Number(fadeInDuration) : 0.2,
      fadeOutDuration: fadeOutDuration !== undefined ? Number(fadeOutDuration) : 0.3,
      segments: inputSegments,
    });

    res.json({
      success: true,
      jobId: safeJobId,
      result,
      mixedAudioPath: result.mixedAudioPath,
    });
  } catch (error: any) {
    console.error('[API /video/:jobId/mix-audio] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'ऑडियो मिक्सिंग में त्रुटि हुई।',
      errorCode: 'MIXING_FAILED',
    });
  }
});

/**
 * Retrieve Saved Mixed Audio Result by jobId
 */
apiRouter.get('/video/:jobId/mixed-audio', (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const result = videoProcessingService.getMixedAudioResult(safeJobId);

    if (!result) {
      res.status(404).json({
        success: false,
        error: 'इस Job ID के लिए मिक्स ऑडियो उपलब्ध नहीं है।',
      });
      return;
    }

    res.json({
      success: true,
      jobId: safeJobId,
      result,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: 'मिक्स ऑडियो डेटा लोड करने में त्रुटि।',
    });
  }
});

/**
 * Stream Mixed Audio File (MP3)
 */
apiRouter.get('/media/mixed_audio/:filename', (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    const filePath = videoProcessingService.getMixedAudioFilePath(filename);

    if (!filePath) {
      res.status(404).json({
        success: false,
        error: 'मिक्स ऑडियो फ़ाइल नहीं मिली।',
      });
      return;
    }

    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.sendFile(filePath);
  } catch (err: any) {
    console.error('[API /media/mixed_audio] Streaming error:', err);
    res.status(500).send('Mixed audio playback error');
  }
});

/**
 * Stage 8 — Final Video Rendering Endpoint
 * Combines original video visual stream with mixed Hindi audio using FFmpeg.
 * Called directly by Flutter app (BackendVideoRenderingService).
 */
apiRouter.post('/render-video', async (req: Request, res: Response) => {
  try {
    const { jobId, videoName, videoPath, originalVideoPath, mixedAudioPath, duration } = req.body;

    const result = await videoRenderingService.renderFinalVideo({
      jobId,
      videoName,
      videoPath,
      originalVideoPath,
      mixedAudioPath,
      duration: Number(duration) || 0,
    });

    res.json({
      success: true,
      jobId: result.jobId,
      outputPath: result.outputVideoPath,
      filename: result.filename,
      duration: result.duration,
      result,
    });
  } catch (error: any) {
    console.error('[API /render-video] Video rendering error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'वीडियो रेंडरिंग करने में समस्या हुई। कृपया दोबारा प्रयास करें।',
      errorCode: 'RENDER_FAILED',
    });
  }
});

/**
 * Stage 8 — Job-specific Video Rendering Endpoint
 */
apiRouter.post('/video/:jobId/render', async (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const { videoName, videoPath, originalVideoPath, mixedAudioPath, duration } = req.body;

    const result = await videoRenderingService.renderFinalVideo({
      jobId: safeJobId,
      videoName,
      videoPath,
      originalVideoPath,
      mixedAudioPath,
      duration: Number(duration) || 0,
    });

    res.json({
      success: true,
      jobId: safeJobId,
      outputPath: result.outputVideoPath,
      filename: result.filename,
      duration: result.duration,
      result,
    });
  } catch (error: any) {
    console.error('[API /video/:jobId/render] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'वीडियो रेंडरिंग में त्रुटि हुई।',
      errorCode: 'RENDER_FAILED',
    });
  }
});

/**
 * Retrieve Saved Rendered Video Metadata by jobId
 */
apiRouter.get('/video/:jobId/rendered-video', (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const safeJobId = jobId.replace(/[^a-zA-Z0-9_]/g, '');
    const result = videoProcessingService.getRenderedVideoResult(safeJobId);

    if (!result) {
      res.status(404).json({
        success: false,
        error: 'इस Job ID के लिए रेंडर किया गया वीडियो उपलब्ध नहीं है।',
      });
      return;
    }

    res.json({
      success: true,
      jobId: safeJobId,
      result,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: 'रेंडर वीडियो डेटा लोड करने में त्रुटि।',
    });
  }
});

/**
 * Stream Rendered MP4 Video File
 */
apiRouter.get('/media/rendered_video/:filename', (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    const filePath = videoProcessingService.getRenderedVideoFilePath(filename);

    if (!filePath) {
      res.status(404).json({
        success: false,
        error: 'रेंडर की गई वीडियो फ़ाइल नहीं मिली।',
      });
      return;
    }

    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.sendFile(filePath);
  } catch (err: any) {
    console.error('[API /media/rendered_video] Streaming error:', err);
    res.status(500).send('Rendered video playback error');
  }
});
