import dotenv from 'dotenv';
dotenv.config();

export interface ServerConfig {
  port: number;
  geminiApiKey: string;
  sttProvider: 'gemini' | 'whisper' | 'custom';
  geminiModel: string;
  maxAudioDurationSeconds: number;
}

export const config: ServerConfig = {
  port: parseInt(process.env.PORT || '3000', 10),
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  sttProvider: (process.env.STT_PROVIDER as any) || 'gemini',
  geminiModel: process.env.GEMINI_MODEL || 'gemini-3.8-flash',
  maxAudioDurationSeconds: 600, // 10 minutes maximum
};
