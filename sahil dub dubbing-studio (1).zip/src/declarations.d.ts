declare module 'get-mp3-duration' {
  function getMp3Duration(buffer: Buffer | Uint8Array): number;
  export = getMp3Duration;
}

declare module 'google-tts-api' {
  interface GoogleTtsOptions {
    lang?: string;
    slow?: boolean;
    host?: string;
    timeout?: number;
    splitPunct?: string;
  }

  export function getAudioBase64(text: string, options?: GoogleTtsOptions): Promise<string>;
  export function getAudioUrl(text: string, options?: GoogleTtsOptions): string;
}
