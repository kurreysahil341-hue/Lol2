import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { VideoUploadArea, VideoUploadAreaHandle } from './components/VideoUploadArea';
import { VideoDetailsCard } from './components/VideoDetailsCard';
import { StatusPipeline } from './components/StatusPipeline';
import { ActionButton } from './components/ActionButton';
import { AudioSyncScreen } from './components/AudioSyncScreen';
import { HindiVoiceScreen } from './components/HindiVoiceScreen';
import { TranslationScreen } from './components/TranslationScreen';
import { FlutterCodeModal } from './components/FlutterCodeModal';
import { 
  VideoItem, 
  PipelineStep, 
  StructuredTranscript, 
  DubbedTranscript, 
  HindiTtsResult,
  SyncResult,
  VoiceSettings 
} from './types';
import { validateVideoFile } from './utils/videoValidator';
import { extractAudioFromVideo, AudioExtractionError } from './services/audioExtractor';
import { sendAudioForTranscription } from './services/transcriptionClient';
import { sendTranscriptForTranslation } from './services/translationClient';
import { sendHindiTranscriptForTts } from './services/ttsClient';
import { sendSegmentsForSynchronization } from './services/syncClient';
import { AlertCircle } from 'lucide-react';

const INITIAL_STEPS: PipelineStep[] = [
  {
    id: 'video',
    title: 'Input Video',
    hindiTitle: 'वीडियो',
    subtitle: 'वीडियो लोड और 10 मिनट सत्यापन',
    status: 'waiting',
    progress: 0,
  },
  {
    id: 'audio_extract',
    title: 'Audio Extract',
    hindiTitle: 'ऑडियो निकालना',
    subtitle: 'वीडियो से ऑडियो ट्रैक एक्सट्रैक्शन',
    status: 'waiting',
    progress: 0,
  },
  {
    id: 'speech_recognition',
    title: 'Speech Recognition',
    hindiTitle: 'English Speech पहचानना',
    subtitle: 'अंग्रेजी आवाज का समयबद्ध प्रतिलेखन',
    status: 'waiting',
    progress: 0,
  },
  {
    id: 'translation',
    title: 'Hindi Translation',
    hindiTitle: 'हिंदी अनुवाद',
    subtitle: 'प्राकृतिक बोलचाल हिंदी में संवाद अनुवाद',
    status: 'waiting',
    progress: 0,
  },
  {
    id: 'tts_synthesis',
    title: 'Hindi Voice Synthesis',
    hindiTitle: 'हिंदी आवाज़ तैयार करना',
    subtitle: 'प्राकृतिक हिंदी AI आवाज़ जनरेशन',
    status: 'waiting',
    progress: 0,
  },
  {
    id: 'sync_audio',
    title: 'Voice Synchronization',
    hindiTitle: 'Hindi आवाज़ Sync करना',
    subtitle: 'मूल टाइमलाइन के साथ समयबद्ध मिलान',
    status: 'waiting',
    progress: 0,
  },
  {
    id: 'dub_ready',
    title: 'Dubbing Audio Ready',
    hindiTitle: 'डबिंग स्क्रिप्ट व सिंक आवाज़ तैयार',
    subtitle: 'सटीक सिंक ऑडियो ट्रैक तैयार',
    status: 'waiting',
    progress: 0,
  },
];

export default function App() {
  const [video, setVideo] = useState<VideoItem | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [currentProgressMessage, setCurrentProgressMessage] = useState<string>('');
  const [steps, setSteps] = useState<PipelineStep[]>(INITIAL_STEPS);
  const [englishTranscript, setEnglishTranscript] = useState<StructuredTranscript | null>(null);
  const [dubbedTranscript, setDubbedTranscript] = useState<DubbedTranscript | null>(null);
  const [hindiTtsResult, setHindiTtsResult] = useState<HindiTtsResult | null>(null);
  const [syncResult, setSyncResult] = useState<SyncResult | null>(null);
  const [isFlutterModalOpen, setIsFlutterModalOpen] = useState<boolean>(false);

  const videoPlayerRef = useRef<VideoUploadAreaHandle>(null);

  // Clean up blob URLs when component unmounts or video changes
  useEffect(() => {
    return () => {
      if (video?.previewUrl && video.previewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(video.previewUrl);
      }
    };
  }, [video]);

  // Handle local video selection
  const handleFileSelect = async (file: File) => {
    setErrorMessage(null);
    setEnglishTranscript(null);
    setDubbedTranscript(null);
    setHindiTtsResult(null);
    setSyncResult(null);
    setIsValidating(true);

    try {
      const validation = await validateVideoFile(file);

      if (!validation.isValid) {
        setErrorMessage(validation.errorMessage || 'अमान्य वीडियो फाइल।');
        setVideo(null);
        setSteps(INITIAL_STEPS);
        return;
      }

      const previewUrl = URL.createObjectURL(file);
      setVideo({
        file,
        name: file.name,
        duration: validation.durationFormatted || '00:00',
        durationSeconds: validation.durationSeconds || 0,
        size: validation.fileSizeFormatted || '0 MB',
        previewUrl,
      });

      // Mark step 1 completed, rest waiting
      setSteps([
        { ...INITIAL_STEPS[0], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[1], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[2], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[3], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[4], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[5], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[6], status: 'waiting', progress: 0 },
      ]);
    } catch (err) {
      setErrorMessage('वीडियो लोड करने में समस्या हुई। कृपया पुनः प्रयास करें।');
      setVideo(null);
    } finally {
      setIsValidating(false);
    }
  };

  // Provide high quality short English presentation sample for easy testing
  const handleSelectSample = async () => {
    setErrorMessage(null);
    setEnglishTranscript(null);
    setDubbedTranscript(null);
    setHindiTtsResult(null);
    setSyncResult(null);
    setIsValidating(true);

    try {
      const sampleUrl = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';
      const response = await fetch(sampleUrl);
      const blob = await response.blob();
      const sampleFile = new File([blob], 'english_speech_sample.mp4', { type: 'video/mp4' });

      const previewUrl = URL.createObjectURL(sampleFile);
      setVideo({
        file: sampleFile,
        name: sampleFile.name,
        duration: '00:15',
        durationSeconds: 15,
        size: `${(sampleFile.size / (1024 * 1024)).toFixed(1)} MB`,
        previewUrl,
      });

      setSteps([
        { ...INITIAL_STEPS[0], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[1], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[2], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[3], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[4], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[5], status: 'waiting', progress: 0 },
        { ...INITIAL_STEPS[6], status: 'waiting', progress: 0 },
      ]);
    } catch (e) {
      setErrorMessage('डेमो वीडियो लोड करने में समस्या हुई।');
    } finally {
      setIsValidating(false);
    }
  };

  // Complete End-to-End Processing: Audio Extraction -> STT -> Translation -> TTS -> Audio Sync (Step 5)
  const handleStartProcessing = async () => {
    if (!video || !video.file || isProcessing) return;

    setErrorMessage(null);
    setIsProcessing(true);
    setEnglishTranscript(null);
    setDubbedTranscript(null);
    setHindiTtsResult(null);
    setSyncResult(null);

    try {
      // --------------------------------------------------
      // STEP 2: AUDIO EXTRACTION
      // --------------------------------------------------
      setSteps((prev) => [
        prev[0],
        { ...prev[1], status: 'in_progress', progress: 15 },
        { ...prev[2], status: 'waiting', progress: 0 },
        { ...prev[3], status: 'waiting', progress: 0 },
        { ...prev[4], status: 'waiting', progress: 0 },
        { ...prev[5], status: 'waiting', progress: 0 },
        { ...prev[6], status: 'waiting', progress: 0 },
      ]);
      setCurrentProgressMessage('ऑडियो निकाला जा रहा है... 15%');

      const extractedAudio = await extractAudioFromVideo(video.file, (percent) => {
        setSteps((prev) => [
          prev[0],
          { ...prev[1], status: 'in_progress', progress: percent },
          prev[2],
          prev[3],
          prev[4],
          prev[5],
          prev[6],
        ]);
        setCurrentProgressMessage(`ऑडियो निकाला जा रहा है... ${percent}%`);
      });

      setSteps((prev) => [
        prev[0],
        { ...prev[1], status: 'completed', progress: 100 },
        { ...prev[2], status: 'in_progress', progress: 20 },
        prev[3],
        prev[4],
        prev[5],
        prev[6],
      ]);

      // --------------------------------------------------
      // STEP 3: ENGLISH SPEECH RECOGNITION (STT)
      // --------------------------------------------------
      setCurrentProgressMessage('English Speech पहचाना जा रहा है... 40%');

      const sttTimer = setInterval(() => {
        setSteps((prev) => {
          const currentSTT = prev[2];
          if (currentSTT.status === 'in_progress' && currentSTT.progress < 90) {
            const nextProgress = Math.min(90, currentSTT.progress + 15);
            setCurrentProgressMessage(`English Speech पहचाना जा रहा है... ${nextProgress}%`);
            return [
              prev[0],
              prev[1],
              { ...currentSTT, progress: nextProgress },
              prev[3],
              prev[4],
              prev[5],
              prev[6],
            ];
          }
          return prev;
        });
      }, 700);

      let resultTranscript: StructuredTranscript;
      try {
        resultTranscript = await sendAudioForTranscription({
          audioBase64: extractedAudio.audioBase64,
          durationSeconds: extractedAudio.duration || video.durationSeconds,
          videoName: video.name,
          mimeType: 'audio/wav',
        });
      } finally {
        clearInterval(sttTimer);
      }

      setEnglishTranscript(resultTranscript);

      // --------------------------------------------------
      // STEP 4: NATURAL HINDI TRANSLATION
      // --------------------------------------------------
      setSteps((prev) => [
        prev[0],
        prev[1],
        { ...prev[2], status: 'completed', progress: 100 },
        { ...prev[3], status: 'in_progress', progress: 30 },
        prev[4],
        prev[5],
        prev[6],
      ]);
      setCurrentProgressMessage('हिंदी में अनुवाद किया जा रहा है... 30%');

      const transTimer = setInterval(() => {
        setSteps((prev) => {
          const currentTrans = prev[3];
          if (currentTrans.status === 'in_progress' && currentTrans.progress < 85) {
            const nextProgress = Math.min(85, currentTrans.progress + 20);
            setCurrentProgressMessage(`हिंदी में अनुवाद किया जा रहा है... ${nextProgress}%`);
            return [
              prev[0],
              prev[1],
              prev[2],
              { ...currentTrans, progress: nextProgress },
              prev[4],
              prev[5],
              prev[6],
            ];
          }
          return prev;
        });
      }, 600);

      let resultDubbed: DubbedTranscript;
      try {
        resultDubbed = await sendTranscriptForTranslation({
          segments: resultTranscript.segments,
          duration: resultTranscript.duration,
          videoName: video.name,
        });
      } finally {
        clearInterval(transTimer);
      }

      setDubbedTranscript(resultDubbed);

      // --------------------------------------------------
      // STEP 5: HINDI TTS SPEECH SYNTHESIS
      // --------------------------------------------------
      setSteps((prev) => [
        prev[0],
        prev[1],
        prev[2],
        { ...prev[3], status: 'completed', progress: 100 },
        { ...prev[4], status: 'in_progress', progress: 25 },
        prev[5],
        prev[6],
      ]);
      setCurrentProgressMessage('हिंदी आवाज़ तैयार की जा रही है... 25%');

      const ttsTimer = setInterval(() => {
        setSteps((prev) => {
          const currentTts = prev[4];
          if (currentTts.status === 'in_progress' && currentTts.progress < 85) {
            const nextProgress = Math.min(85, currentTts.progress + 20);
            setCurrentProgressMessage(`हिंदी आवाज़ तैयार की जा रही है... ${nextProgress}%`);
            return [
              prev[0],
              prev[1],
              prev[2],
              prev[3],
              { ...currentTts, progress: nextProgress },
              prev[5],
              prev[6],
            ];
          }
          return prev;
        });
      }, 500);

      let ttsOutput: HindiTtsResult;
      try {
        ttsOutput = await sendHindiTranscriptForTts({
          segments: resultDubbed.segments,
        });
      } finally {
        clearInterval(ttsTimer);
      }

      setHindiTtsResult(ttsOutput);

      // --------------------------------------------------
      // STEP 6: HINDI VOICE TIMING & SYNCHRONIZATION (STEP 5)
      // --------------------------------------------------
      setSteps((prev) => [
        prev[0],
        prev[1],
        prev[2],
        prev[3],
        { ...prev[4], status: 'completed', progress: 100 },
        { ...prev[5], status: 'in_progress', progress: 25 },
        prev[6],
      ]);
      setCurrentProgressMessage('Hindi आवाज़ Sync की जा रही है... 25%');

      const syncTimer = setInterval(() => {
        setSteps((prev) => {
          const currentSync = prev[5];
          if (currentSync.status === 'in_progress' && currentSync.progress < 85) {
            const nextProgress = Math.min(85, currentSync.progress + 20);
            setCurrentProgressMessage(`Hindi आवाज़ Sync की जा रही है... ${nextProgress}%`);
            return [
              prev[0],
              prev[1],
              prev[2],
              prev[3],
              prev[4],
              { ...currentSync, progress: nextProgress },
              prev[6],
            ];
          }
          return prev;
        });
      }, 400);

      let syncOutput: SyncResult;
      try {
        syncOutput = await sendSegmentsForSynchronization(ttsOutput.segments);
      } finally {
        clearInterval(syncTimer);
      }

      // --------------------------------------------------
      // STEP 7: DUBBING AUDIO READY
      // --------------------------------------------------
      setSteps([
        { ...INITIAL_STEPS[0], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[1], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[2], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[3], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[4], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[5], status: 'completed', progress: 100 },
        { ...INITIAL_STEPS[6], status: 'completed', progress: 100 },
      ]);
      setCurrentProgressMessage('Hindi आवाज़ Sync हो गई');
      setSyncResult(syncOutput);

    } catch (err: any) {
      console.error('[Processing Error]:', err);
      let errorText = err.message || 'प्रक्रिया में समस्या हुई। कृपया दोबारा प्रयास करें।';
      if (err instanceof AudioExtractionError && err.code === 'NO_AUDIO_TRACK') {
        errorText = 'इस वीडियो में कोई ऑडियो नहीं मिला।';
      }

      setErrorMessage(errorText);

      setSteps((prev) =>
        prev.map((step) =>
          step.status === 'in_progress'
            ? { ...step, status: 'error', progress: 0 }
            : step
        )
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    if (video?.previewUrl && video.previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(video.previewUrl);
    }
    setVideo(null);
    setErrorMessage(null);
    setEnglishTranscript(null);
    setDubbedTranscript(null);
    setHindiTtsResult(null);
    setSyncResult(null);
    setIsProcessing(false);
    setCurrentProgressMessage('');
    setSteps(INITIAL_STEPS);
  };

  const handleSeekToTime = (seconds: number) => {
    videoPlayerRef.current?.seekToTime(seconds);
  };

  return (
    <div className="min-h-screen bg-[#08090E] text-slate-100 flex flex-col selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* 1. Header */}
      <Header
        onReset={handleReset}
        hasVideo={Boolean(video)}
        onOpenFlutterCode={() => setIsFlutterModalOpen(true)}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 flex flex-col gap-6">
        
        {/* Title */}
        <div className="text-center sm:text-left">
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Hindi Voice Timing & Audio Synchronization (Step 5)
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            मूल अंग्रेजी स्पीच टाइमलाइन के साथ हिंदी आवाज़ का सटीक टाइम-सिंक और पिच-सुरक्षित टाइम-स्ट्रेचिंग।
          </p>
        </div>

        {/* Global Error Alert */}
        {errorMessage && (
          <div className="w-full rounded-2xl bg-rose-950/40 border border-rose-500/40 p-4 flex items-start gap-3 shadow-lg shadow-rose-950/30 animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-sm font-bold text-rose-200">त्रुटि</h4>
              <p className="text-xs sm:text-sm text-rose-300/90 mt-0.5 font-medium leading-relaxed">
                {errorMessage}
              </p>
            </div>
          </div>
        )}

        {/* 2. Video Upload & Player Area */}
        <section aria-label="वीडियो अपलोड क्षेत्र" className="w-full">
          <VideoUploadArea
            ref={videoPlayerRef}
            video={video}
            errorMessage={null}
            isValidating={isValidating}
            onFileSelect={handleFileSelect}
            onSelectSample={handleSelectSample}
            onClearError={() => setErrorMessage(null)}
          />
        </section>

        {/* 3. Video Details Card */}
        {video && (
          <section aria-label="वीडियो विवरण" className="w-full animate-in fade-in duration-300">
            <VideoDetailsCard video={video} />
          </section>
        )}

        {/* 4. Action Button ("आगे बढ़ें") */}
        <section aria-label="एक्शन बटन" className="w-full py-1">
          <ActionButton
            hasVideo={Boolean(video)}
            isProcessing={isProcessing}
            isCompleted={Boolean(syncResult)}
            onProceed={handleStartProcessing}
          />
        </section>

        {/* 5. Processing Status Area */}
        <section aria-label="डबिंग प्रक्रिया स्थिति" className="w-full">
          <StatusPipeline
            steps={steps}
            activeStepId={steps.find((s) => s.status === 'in_progress')?.id || null}
            currentMessage={currentProgressMessage}
            isProcessing={isProcessing}
            hasError={steps.some((s) => s.status === 'error')}
          />
        </section>

        {/* 6. Step 5: Audio Sync Screen (Hindi Voice Timing Synchronization) */}
        {syncResult && (
          <section aria-label="हिंदी आवाज़ टाइमिंग सिंक्रोनाइज़ेशन" className="w-full">
            <AudioSyncScreen
              syncResult={syncResult}
              onSeekVideo={handleSeekToTime}
              onReset={handleReset}
            />
          </section>
        )}

        {/* 7. Step 4: Hindi Voice Screen (Audio Preview fallback) */}
        {hindiTtsResult && !syncResult && (
          <section aria-label="हिंदी आवाज़ पूर्वावलोकन" className="w-full">
            <HindiVoiceScreen
              ttsResult={hindiTtsResult}
              onSeekVideo={handleSeekToTime}
              onReset={handleReset}
            />
          </section>
        )}

        {/* 8. Step 3: English -> Hindi Translation Screen fallback */}
        {dubbedTranscript && !hindiTtsResult && !syncResult && (
          <section aria-label="इंग्लिश से हिंदी अनुवादित स्क्रिप्ट" className="w-full">
            <TranslationScreen
              dubbedTranscript={dubbedTranscript}
              onSeekToTime={handleSeekToTime}
              onReset={handleReset}
            />
          </section>
        )}

      </main>

      {/* Footer */}
      <footer className="w-full border-t border-white/[0.06] bg-[#07080E]/80 backdrop-blur-md py-4 px-4 text-center text-xs text-slate-500">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>अधिकतम वीडियो अवधि: 10 मिनट (600 सेकंड)</span>
          <span>चरण 5: Hindi Voice Timing & Synchronization (Step 5 Complete)</span>
        </div>
      </footer>

      {/* Flutter & Dart Code Viewer Modal */}
      <FlutterCodeModal
        isOpen={isFlutterModalOpen}
        onClose={() => setIsFlutterModalOpen(false)}
      />
    </div>
  );
}
