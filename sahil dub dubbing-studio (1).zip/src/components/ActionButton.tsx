import React from 'react';
import { ArrowRight, Loader2, Sparkles, CheckCircle2 } from 'lucide-react';

interface ActionButtonProps {
  hasVideo: boolean;
  isProcessing: boolean;
  isCompleted: boolean;
  onProceed: () => void;
}

export const ActionButton: React.FC<ActionButtonProps> = ({
  hasVideo,
  isProcessing,
  isCompleted,
  onProceed,
}) => {
  if (isCompleted) {
    return (
      <div className="w-full flex flex-col items-center">
        <div className="w-full max-w-xl rounded-2xl bg-emerald-950/40 border border-emerald-500/30 p-3.5 flex items-center justify-center gap-2.5 text-emerald-300 font-semibold text-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>ऑडियो एक्सट्रैक्शन और अंग्रेजी ट्रांसक्रिप्शन सफलतापूर्वक पूर्ण हो गया है</span>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full flex flex-col items-center gap-3">
      <button
        type="button"
        disabled={!hasVideo || isProcessing}
        onClick={onProceed}
        className={`w-full max-w-xl min-h-[56px] sm:min-h-[60px] px-8 py-3.5 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 transition-all shadow-xl ${
          !hasVideo
            ? 'bg-slate-800/40 text-slate-500 border border-white/[0.04] cursor-not-allowed'
            : isProcessing
            ? 'bg-indigo-900/60 border border-indigo-500/40 text-indigo-200 cursor-wait'
            : 'bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-indigo-600/30 hover:shadow-indigo-600/50 active:scale-[0.98] cursor-pointer'
        }`}
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin text-indigo-300" />
            <span>ऑडियो और अंग्रेजी ट्रांसक्रिप्शन प्रक्रियाधीन है...</span>
          </>
        ) : (
          <>
            <Sparkles className={`w-5 h-5 ${hasVideo ? 'text-purple-300 animate-pulse' : 'text-slate-600'}`} />
            <span>आगे बढ़ें (ऑडियो निकालें और ट्रांसक्राइब करें)</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </>
        )}
      </button>

      {!hasVideo && (
        <p className="text-xs text-slate-500 font-medium text-center">
          आगे बढ़ने के लिए कृपया 10 मिनट तक की कोई वीडियो चुनें
        </p>
      )}
    </div>
  );
};
