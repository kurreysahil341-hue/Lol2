import React from 'react';
import { Volume2, Square, Play, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import { SyncedAudioSegment } from '../types';

interface SyncSegmentCardProps {
  segment: SyncedAudioSegment;
  isPlaying: boolean;
  onPlayToggle: () => void;
  onSeekVideo?: (seconds: number) => void;
}

export const SyncSegmentCard: React.FC<SyncSegmentCardProps> = ({
  segment,
  isPlaying,
  onPlayToggle,
  onSeekVideo,
}) => {
  const formatSeconds = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isClamped = segment.status === 'clamped_speed';
  const isNatural = segment.status === 'fits_naturally';

  return (
    <div
      className={`p-4 rounded-2xl border transition-all text-left flex flex-col gap-3 ${
        isPlaying
          ? 'bg-indigo-950/40 border-indigo-500/60 shadow-lg shadow-indigo-950/40 ring-1 ring-indigo-500/30'
          : 'bg-white/[0.02] hover:bg-white/[0.04] border-white/[0.05] hover:border-white/[0.08]'
      }`}
    >
      {/* Top Header Row: Timecode, Badges, Play Button */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-slate-400">समय:</span>
          <span className="font-mono text-xs font-semibold text-indigo-400 bg-indigo-950/70 px-2 py-0.5 rounded border border-indigo-500/25 tabular-nums">
            {formatSeconds(segment.startTime)} - {formatSeconds(segment.endTime)}
          </span>

          <span className="text-[11px] text-slate-500 font-mono">
            #{segment.id}
          </span>

          {/* Classification Badge */}
          <span
            className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border flex items-center gap-1 ${
              isNatural
                ? 'text-emerald-400 bg-emerald-950/60 border-emerald-500/30'
                : isClamped
                ? 'text-amber-400 bg-amber-950/60 border-amber-500/30'
                : 'text-indigo-300 bg-indigo-950/60 border-indigo-500/30'
            }`}
          >
            {isNatural ? (
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            ) : isClamped ? (
              <AlertTriangle className="w-3 h-3 text-amber-400" />
            ) : null}
            <span>{segment.timingClassificationHindi}</span>
          </span>
        </div>

        {/* Action: "Sync की गई आवाज़ सुनें" */}
        <div className="flex items-center gap-2">
          {onSeekVideo && (
            <button
              type="button"
              onClick={() => onSeekVideo(segment.startTime)}
              className="px-2.5 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-slate-400 hover:text-white text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
              title="वीडियो में उस समय पर जाएं"
            >
              <Play className="w-3 h-3" />
              <span>वीडियो</span>
            </button>
          )}

          <button
            type="button"
            onClick={onPlayToggle}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer ${
              isPlaying
                ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse'
                : 'bg-purple-600 hover:bg-purple-500 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>रोकें</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5" />
                <span>Sync की गई आवाज़ सुनें</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Timing Analysis Metric Row (Requirement 8) */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-black/40 border border-white/[0.04] text-xs">
        <div className="flex flex-wrap items-center gap-3 text-slate-300 font-mono text-[11px]">
          <div>
            <span className="text-slate-500">Original duration:</span>{' '}
            <span className="font-semibold text-white">{segment.targetDuration.toFixed(1)} सेकंड</span>
          </div>
          <div className="text-slate-600">|</div>
          <div>
            <span className="text-slate-500">Hindi voice:</span>{' '}
            <span className="font-semibold text-purple-300">{segment.hindiAudioDuration.toFixed(1)} सेकंड</span>
          </div>
          <div className="text-slate-600">|</div>
          <div>
            <span className="text-slate-500">Adjusted:</span>{' '}
            <span className="font-semibold text-emerald-300">{segment.adjustedDuration.toFixed(1)} सेकंड</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-[11px] text-slate-400">Sync गति:</span>
          <span className="font-mono font-bold text-xs text-purple-400 bg-purple-950/80 px-2 py-0.5 rounded border border-purple-500/30">
            {segment.speedAdjustment.toFixed(2)}x
          </span>
        </div>
      </div>

      {/* English Reference Text */}
      {segment.englishText && (
        <div className="text-xs text-slate-400 border-l-2 border-slate-700 pl-2">
          <span className="font-semibold text-slate-500 mr-1.5">English:</span>
          <span className="italic">{segment.englishText}</span>
        </div>
      )}

      {/* Hindi Spoken Dubbing Text */}
      <div className="border-l-2 border-purple-500/70 pl-2.5 py-1 bg-purple-950/20 rounded-r-xl">
        <span className="text-[11px] font-bold text-purple-300 block mb-0.5">Hindi:</span>
        <p className="text-sm sm:text-base font-semibold text-slate-100 leading-relaxed">
          {segment.hindiText}
        </p>
      </div>
    </div>
  );
};
