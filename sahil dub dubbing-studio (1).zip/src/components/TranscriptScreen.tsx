import React, { useState } from 'react';
import { 
  FileText, 
  Clock, 
  Hash, 
  Globe, 
  Copy, 
  Check, 
  Play, 
  ArrowRight,
  Download,
  RotateCcw
} from 'lucide-react';
import { StructuredTranscript, TranscriptSegment } from '../types';

interface TranscriptScreenProps {
  transcript: StructuredTranscript;
  onSeekToTime?: (seconds: number) => void;
  onReset: () => void;
}

export const TranscriptScreen: React.FC<TranscriptScreenProps> = ({
  transcript,
  onSeekToTime,
  onReset,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeSegmentId, setActiveSegmentId] = useState<number | null>(null);

  const formatSeconds = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopyTranscript = () => {
    const fullText = transcript.segments
      .map(
        (s) =>
          `[${formatSeconds(s.startTime)} - ${formatSeconds(s.endTime)}] ${s.text}`
      )
      .join('\n\n');

    navigator.clipboard.writeText(fullText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleDownloadJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(transcript, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `transcript_${transcript.videoName || 'video'}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="w-full rounded-3xl bg-[#0D101E]/90 backdrop-blur-xl border border-white/[0.08] p-5 sm:p-6 shadow-2xl shadow-black/50 flex flex-col gap-5 animate-in fade-in duration-300">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>English Transcript</span>
              <span className="text-xs font-normal text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                तैयार
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              वीडियो से निकाला गया टाइमस्टैम्प्ड अंग्रेजी भाषण (Speech-to-Text)
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={handleCopyTranscript}
            className="px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            title="ट्रांसक्रिप्ट कॉपी करें"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'कॉपी हो गया' : 'टेक्स्ट कॉपी करें'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadJson}
            className="px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            title="JSON फाइल डाउनलोड करें"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Overview Metadata Stats */}
      <div className="grid grid-cols-3 gap-3">
        {/* Total Video Duration */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 shrink-0">
            <Clock className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">कुल अवधि</span>
            <span className="text-xs sm:text-sm font-bold text-slate-100 font-mono tabular-nums truncate block">
              {formatSeconds(transcript.duration)}
            </span>
          </div>
        </div>

        {/* Number of Speech Segments */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0">
            <Hash className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">भाषण खंड (Segments)</span>
            <span className="text-xs sm:text-sm font-bold text-slate-100 font-mono tabular-nums truncate block">
              {transcript.segments.length} वाक्य
            </span>
          </div>
        </div>

        {/* Recognized Language */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 shrink-0">
            <Globe className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">पहचानी गई भाषा</span>
            <span className="text-xs sm:text-sm font-bold text-emerald-300 truncate block">
              English ({transcript.sourceLanguage.toUpperCase()})
            </span>
          </div>
        </div>
      </div>

      {/* Scrollable Transcript List */}
      <div className="flex flex-col">
        <div className="flex items-center justify-between text-xs text-slate-400 font-medium px-1 mb-2">
          <span>टाइमस्टैम्प्ड संवाद (क्लिक करके वीडियो में उस समय पर जाएं):</span>
          <span>{transcript.segments.length} कुल पंक्तियां</span>
        </div>

        <div className="max-h-[380px] overflow-y-auto pr-2 space-y-2.5 rounded-2xl border border-white/[0.05] p-3 bg-black/30">
          {transcript.segments.map((segment: TranscriptSegment) => {
            const isActive = activeSegmentId === segment.id;
            return (
              <div
                key={segment.id}
                onClick={() => {
                  setActiveSegmentId(segment.id);
                  onSeekToTime?.(segment.startTime);
                }}
                className={`p-3 rounded-xl border transition-all cursor-pointer text-left group ${
                  isActive
                    ? 'bg-indigo-950/40 border-indigo-500/40 shadow-md shadow-indigo-950/40'
                    : 'bg-white/[0.02] hover:bg-white/[0.04] border-white/[0.04] hover:border-white/[0.08]'
                }`}
              >
                {/* Timestamp line */}
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-500/20 tabular-nums">
                      {formatSeconds(segment.startTime)} - {formatSeconds(segment.endTime)}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      #{segment.id}
                    </span>
                  </div>

                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-[11px] text-indigo-300">
                    <Play className="w-3 h-3 fill-current" />
                    <span>सुनें</span>
                  </div>
                </div>

                {/* English Text */}
                <p className="text-sm font-medium text-slate-100 leading-relaxed pl-0.5">
                  {segment.text}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Next Step Readiness Notice */}
      <div className="rounded-2xl bg-indigo-950/30 border border-indigo-500/20 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="text-center sm:text-left">
          <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 justify-center sm:justify-start">
            <span>अगला चरण: Hindi अनुवाद और वॉइस सिंथेसिस</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            यह ट्रांसक्रिप्ट संरचना (JSON) चरण 3 में सीधे अंग्रेजी से हिंदी संवाद अनुवाद के लिए उपयोग होगी।
          </p>
        </div>

        <button
          type="button"
          onClick={onReset}
          className="px-4 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.1] text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>नई वीडियो टेस्ट करें</span>
        </button>
      </div>

    </div>
  );
};
