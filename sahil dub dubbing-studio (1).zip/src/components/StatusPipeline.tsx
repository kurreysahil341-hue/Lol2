import React from 'react';
import { 
  Video, 
  Headphones, 
  FileText, 
  Languages,
  Mic,
  GitMerge,
  CheckCircle2, 
  Clock, 
  Loader2, 
  AlertCircle 
} from 'lucide-react';
import { PipelineStep } from '../types';

interface StatusPipelineProps {
  steps: PipelineStep[];
  activeStepId: string | null;
  currentMessage: string;
  isProcessing: boolean;
  hasError: boolean;
}

export const StatusPipeline: React.FC<StatusPipelineProps> = ({
  steps,
  activeStepId,
  currentMessage,
  isProcessing,
  hasError,
}) => {
  const getStepIcon = (id: string, className: string = 'w-5 h-5') => {
    switch (id) {
      case 'video':
        return <Video className={className} />;
      case 'audio_extract':
        return <Headphones className={className} />;
      case 'speech_recognition':
        return <FileText className={className} />;
      case 'translation':
        return <Languages className={className} />;
      case 'tts_synthesis':
        return <Mic className={className} />;
      case 'sync_audio':
        return <GitMerge className={className} />;
      case 'dub_ready':
        return <CheckCircle2 className={className} />;
      default:
        return <Clock className={className} />;
    }
  };

  const getStatusBadge = (status: PipelineStep['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/20">
            संपन्न
          </span>
        );
      case 'in_progress':
        return (
          <span className="text-[10px] font-semibold text-indigo-300 bg-indigo-950/80 px-2 py-0.5 rounded-full border border-indigo-400/30 flex items-center gap-1 animate-pulse">
            <Loader2 className="w-2.5 h-2.5 animate-spin" />
            प्रक्रियाधीन
          </span>
        );
      case 'error':
        return (
          <span className="text-[10px] font-semibold text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded-full border border-rose-500/20">
            त्रुटि
          </span>
        );
      case 'waiting':
      default:
        return (
          <span className="text-[10px] font-medium text-slate-500 bg-white/[0.03] px-2 py-0.5 rounded-full border border-white/[0.05]">
            प्रतीक्षारत
          </span>
        );
    }
  };

  return (
    <div className="w-full rounded-2xl bg-[#0D101E]/80 backdrop-blur-xl border border-white/[0.08] p-4 sm:p-5 shadow-xl shadow-black/40">
      
      {/* Header with active dynamic message */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-4 border-b border-white/[0.06]">
        <div>
          <h3 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-2">
            <span>डबिंग प्रक्रिया स्थिति (Processing Pipeline)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            अंग्रेजी वीडियो से सटीक टाइम-सिंक हिंदी आवाज़ तैयार करने के 7 चरण
          </p>
        </div>

        {/* Live dynamic progress message */}
        {isProcessing && currentMessage && (
          <div className="text-xs font-semibold text-indigo-300 bg-indigo-950/70 px-3 py-1.5 rounded-xl border border-indigo-500/30 flex items-center gap-2 shadow-sm self-start sm:self-auto animate-pulse">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
            <span>{currentMessage}</span>
          </div>
        )}

        {hasError && (
          <div className="text-xs font-semibold text-rose-300 bg-rose-950/70 px-3 py-1.5 rounded-xl border border-rose-500/30 flex items-center gap-1.5 self-start sm:self-auto">
            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
            <span>प्रक्रिया में व्यवधान</span>
          </div>
        )}
      </div>

      {/* 7 Steps Timeline Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 relative">
        {steps.map((step) => {
          const isCurrent = step.status === 'in_progress';
          const isDone = step.status === 'completed';
          const isError = step.status === 'error';

          return (
            <div
              key={step.id}
              className={`p-2.5 rounded-xl border transition-all flex flex-col justify-between ${
                isCurrent
                  ? 'bg-indigo-950/40 border-indigo-500/50 shadow-lg shadow-indigo-950/50 scale-[1.02]'
                  : isDone
                  ? 'bg-emerald-950/20 border-emerald-500/20'
                  : isError
                  ? 'bg-rose-950/20 border-rose-500/20'
                  : 'bg-white/[0.02] border-white/[0.04]'
              }`}
            >
              {/* Step top line */}
              <div className="flex items-center justify-between gap-1 mb-1.5">
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                    isDone
                      ? 'bg-emerald-950 border border-emerald-400/80 text-emerald-300'
                      : isCurrent
                      ? 'bg-gradient-to-br from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/40 animate-pulse'
                      : isError
                      ? 'bg-rose-950 border border-rose-400 text-rose-300'
                      : 'bg-[#12162A] border border-white/[0.08] text-slate-500'
                  }`}
                >
                  {getStepIcon(step.id, 'w-3.5 h-3.5')}
                </div>

                {getStatusBadge(step.status)}
              </div>

              {/* Title & subtitle */}
              <div>
                <h4
                  className={`text-[11px] font-semibold mb-0.5 leading-snug ${
                    isDone
                      ? 'text-emerald-300'
                      : isCurrent
                      ? 'text-white'
                      : isError
                      ? 'text-rose-300'
                      : 'text-slate-300'
                  }`}
                >
                  {step.hindiTitle}
                </h4>
                <p className="text-[9px] text-slate-400 line-clamp-1 leading-normal">
                  {step.subtitle}
                </p>
              </div>

              {/* Progress bar */}
              <div className="mt-2">
                <div className="flex items-center justify-between text-[9px] text-slate-400 mb-0.5">
                  <span>प्रगति</span>
                  <span className="font-mono font-semibold tabular-nums text-slate-300">
                    {step.progress}%
                  </span>
                </div>
                <div className="w-full h-1 bg-black/40 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isDone
                        ? 'bg-emerald-400'
                        : isError
                        ? 'bg-rose-500'
                        : isCurrent
                        ? 'bg-gradient-to-r from-indigo-500 to-purple-500'
                        : 'bg-white/10'
                    }`}
                    style={{ width: `${step.progress}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
