import React, { useState, useRef, useEffect } from 'react';
import { 
  Volume2, 
  Mic, 
  CheckCircle2, 
  Clock, 
  Sliders, 
  Activity, 
  Sparkles,
  RotateCcw,
  Play,
  Square
} from 'lucide-react';
import { HindiAudioSegment, HindiTtsResult, VoiceSettings } from '../types';
import { AudioSegmentCard } from './AudioSegmentCard';

interface HindiVoiceScreenProps {
  ttsResult: HindiTtsResult;
  onSeekVideo?: (seconds: number) => void;
  onReset?: () => void;
  onRegenerateWithSettings?: (settings: VoiceSettings) => void;
  isRegenerating?: boolean;
}

export const HindiVoiceScreen: React.FC<HindiVoiceScreenProps> = ({
  ttsResult,
  onSeekVideo,
  onReset,
  onRegenerateWithSettings,
  isRegenerating = false,
}) => {
  const [playingSegmentId, setPlayingSegmentId] = useState<number | null>(null);
  const [isPlayingAll, setIsPlayingAll] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(ttsResult.voiceSettings.speed || 1.0);
  const [volume, setVolume] = useState<number>(ttsResult.voiceSettings.volume || 1.0);
  const [showSettings, setShowSettings] = useState<boolean>(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playAllIndexRef = useRef<number>(0);

  // Stop audio on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
    };
  }, []);

  const handlePlayToggle = (segment: HindiAudioSegment) => {
    if (isPlayingAll) {
      stopPlayback();
    }

    if (playingSegmentId === segment.id) {
      stopPlayback();
      return;
    }

    playSegment(segment);
  };

  const playSegment = (segment: HindiAudioSegment) => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;
    audio.pause();

    // Prefer base64 data URI if available or server static endpoint
    const src = segment.audioBase64
      ? `data:audio/mp3;base64,${segment.audioBase64}`
      : segment.audioPath;

    audio.src = src;
    audio.playbackRate = speed;
    audio.volume = volume;

    setPlayingSegmentId(segment.id);

    audio.onended = () => {
      setPlayingSegmentId(null);
    };

    audio.onerror = () => {
      console.error('[Audio playback error]');
      setPlayingSegmentId(null);
    };

    audio.play().catch((err) => {
      console.warn('Playback blocked or failed:', err);
      setPlayingSegmentId(null);
    });
  };

  const stopPlayback = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setPlayingSegmentId(null);
    setIsPlayingAll(false);
  };

  const handlePlayAll = () => {
    if (isPlayingAll) {
      stopPlayback();
      return;
    }

    if (ttsResult.segments.length === 0) return;

    setIsPlayingAll(true);
    playAllIndexRef.current = 0;
    playNextInSequence();
  };

  const playNextInSequence = () => {
    const idx = playAllIndexRef.current;
    if (idx >= ttsResult.segments.length) {
      setIsPlayingAll(false);
      setPlayingSegmentId(null);
      return;
    }

    const seg = ttsResult.segments[idx];
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;
    const src = seg.audioBase64
      ? `data:audio/mp3;base64,${seg.audioBase64}`
      : seg.audioPath;

    audio.src = src;
    audio.playbackRate = speed;
    audio.volume = volume;
    setPlayingSegmentId(seg.id);

    audio.onended = () => {
      playAllIndexRef.current += 1;
      playNextInSequence();
    };

    audio.onerror = () => {
      playAllIndexRef.current += 1;
      playNextInSequence();
    };

    audio.play().catch(() => {
      setIsPlayingAll(false);
      setPlayingSegmentId(null);
    });
  };

  const handleApplySettings = () => {
    if (onRegenerateWithSettings) {
      onRegenerateWithSettings({
        language: 'hi',
        voiceName: 'hi-IN-Neural-1',
        speed,
        pitch: 1.0,
        volume,
      });
    }
  };

  const totalDiff = ttsResult.totalGeneratedDuration - ttsResult.totalOriginalDuration;
  const totalDiffSign = totalDiff > 0 ? `+${totalDiff.toFixed(1)}s` : `${totalDiff.toFixed(1)}s`;

  return (
    <div className="w-full rounded-3xl bg-[#0D101E]/95 backdrop-blur-xl border border-white/[0.08] p-5 sm:p-6 shadow-2xl shadow-black/50 flex flex-col gap-5 animate-in fade-in duration-300">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
            <Mic className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>हिंदी आवाज़ पूर्वावलोकन (Hindi Voice Preview)</span>
              <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/70 px-2.5 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>हिंदी आवाज़ तैयार है</span>
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              प्रत्येक संवाद की प्राकृतिक हिंदी AI आवाज़ और सटीक अवधि तुलना
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={handlePlayAll}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isPlayingAll
                ? 'bg-rose-600 border-rose-500 text-white'
                : 'bg-white/[0.06] hover:bg-white/[0.1] border-white/[0.08] text-white'
            }`}
          >
            {isPlayingAll ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>रोकें</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current text-indigo-400" />
                <span>सभी सुनें (Play All)</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setShowSettings(!showSettings)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
              showSettings
                ? 'bg-indigo-600 text-white border-indigo-500'
                : 'bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 border-white/[0.08]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-slate-300" />
            <span>आवाज़ सेटिंग्स</span>
          </button>
        </div>
      </div>

      {/* Voice Settings Panel (Configurable speed & volume) */}
      {showSettings && (
        <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] flex flex-col gap-3 animate-in fade-in duration-200">
          <div className="flex items-center justify-between text-xs font-bold text-white">
            <span className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span>आवाज़ सेटिंग्स (Voice Settings)</span>
            </span>
            <span className="text-[11px] text-slate-400">भाषा: हिंदी (Natural Hindi Neural)</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Speed slider */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-slate-300">
                <span>बोलने की गति (Speed):</span>
                <span className="font-mono font-bold text-indigo-300">{speed}x</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0.8x (धीमी)</span>
                <span>1.0x (सामान्य)</span>
                <span>1.2x (तेज़)</span>
              </div>
            </div>

            {/* Volume slider */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-slate-300">
                <span>वॉल्यूम (Volume):</span>
                <span className="font-mono font-bold text-indigo-300">{Math.round(volume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="1.0"
                step="0.05"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>20%</span>
                <span>100%</span>
              </div>
            </div>
          </div>

          {onRegenerateWithSettings && (
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={handleApplySettings}
                disabled={isRegenerating}
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                {isRegenerating ? 'पुनः तैयार किया जा रहा है...' : 'सेटिंग्स लागू करें'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Duration & Comparison Stats */}
      <div className="grid grid-cols-3 gap-3">
        {/* Total Original Video Duration */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 shrink-0">
            <Clock className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">मूल संवाद अवधि</span>
            <span className="text-xs sm:text-sm font-bold text-slate-100 font-mono tabular-nums truncate block">
              {ttsResult.totalOriginalDuration.toFixed(1)}s
            </span>
          </div>
        </div>

        {/* Total Generated Audio Duration */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0">
            <Volume2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">उत्पन्न आवाज़ अवधि</span>
            <span className="text-xs sm:text-sm font-bold text-slate-100 font-mono tabular-nums truncate block">
              {ttsResult.totalGeneratedDuration.toFixed(1)}s
            </span>
          </div>
        </div>

        {/* Duration Difference */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 shrink-0">
            <Activity className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">अवधि अंतर (Δt)</span>
            <span className="text-xs sm:text-sm font-bold text-emerald-300 font-mono tabular-nums truncate block">
              {totalDiffSign} (सिंक के लिए सहेजा गया)
            </span>
          </div>
        </div>
      </div>

      {/* Scrollable list of AudioSegmentCard */}
      <div className="flex flex-col">
        <div className="flex items-center justify-between text-xs text-slate-400 font-medium px-1 mb-2">
          <span>समयबद्ध हिंदी संवाद ऑडियो (क्लिक करके आवाज़ सुनें):</span>
          <span>{ttsResult.segments.length} ऑडियो सेगमेंट्स</span>
        </div>

        <div className="max-h-[460px] overflow-y-auto pr-2 space-y-3 rounded-2xl border border-white/[0.05] p-3 bg-black/40">
          {ttsResult.segments.map((segment) => (
            <AudioSegmentCard
              key={segment.id}
              segment={segment}
              isPlaying={playingSegmentId === segment.id}
              onPlayToggle={() => handlePlayToggle(segment)}
              onSeekVideo={onSeekVideo}
            />
          ))}
        </div>
      </div>

      {/* Next Step Notice (Audio-Video Sync Readiness) */}
      <div className="rounded-2xl bg-indigo-950/30 border border-indigo-500/20 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="text-center sm:text-left">
          <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 justify-center sm:justify-start">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>अगला चरण 5: Audio-Video Synchronization & Video Export</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            सभी हिंदी ऑडियो सेगमेंट्स सुरक्षित रूप से तैयार और मापे जा चुके हैं। अगले चरण में इन ऑडियो ट्रैक्स को वीडियो के साथ टाइम-सिंक करके अंतिम डब वीडियो तैयार किया जाएगा।
          </p>
        </div>

        {onReset && (
          <button
            type="button"
            onClick={onReset}
            className="px-4 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.1] text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>नई वीडियो टेस्ट करें</span>
          </button>
        )}
      </div>

    </div>
  );
};
