import React, { useRef, useState, useEffect } from 'react';
import { Volume2, Square, Play, Sparkles } from 'lucide-react';
import { HindiAudioSegment } from '../types';

interface AudioSegmentCardProps {
  segment: HindiAudioSegment;
  isPlaying: boolean;
  onPlayToggle: () => void;
  onSeekVideo?: (seconds: number) => void;
}

export const AudioSegmentCard: React.FC<AudioSegmentCardProps> = ({
  segment,
  isPlaying,
  onPlayToggle,
  onSeekVideo,
}) => {
  const formatSeconds = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const origDur = segment.originalDuration.toFixed(1);
  const genDur = segment.generatedDuration.toFixed(1);
  const diff = segment.durationDifference;
  const diffText = diff > 0 ? `+${diff.toFixed(1)}s` : `${diff.toFixed(1)}s`;

  return (
    <div
      className={`p-4 rounded-2xl border transition-all text-left flex flex-col gap-2.5 ${
        isPlaying
          ? 'bg-indigo-950/40 border-indigo-500/60 shadow-lg shadow-indigo-950/40 ring-1 ring-indigo-500/30'
          : 'bg-white/[0.02] hover:bg-white/[0.04] border-white/[0.05] hover:border-white/[0.08]'
      }`}
    >
      {/* Top Header Row: Timecode, Duration Badge, Play Button */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold text-slate-400">समय:</span>
          <span className="font-mono text-xs font-semibold text-indigo-400 bg-indigo-950/70 px-2 py-0.5 rounded border border-indigo-500/25 tabular-nums">
            {formatSeconds(segment.startTime)} - {formatSeconds(segment.endTime)}
          </span>

          <span className="text-[11px] text-slate-500 font-mono">
            #{segment.id}
          </span>

          {/* Duration Comparison Badge */}
          <span className="text-[11px] font-semibold text-purple-300 bg-purple-950/60 px-2.5 py-0.5 rounded-full border border-purple-500/25 flex items-center gap-1 tabular-nums">
            <span>मूल: {origDur}s</span>
            <span className="text-purple-400/50">|</span>
            <span>आवाज़: {genDur}s</span>
            <span className={`text-[10px] ${diff > 0.5 ? 'text-amber-400' : 'text-slate-400'}`}>
              ({diffText})
            </span>
          </span>
        </div>

        {/* Action: "आवाज़ सुनें" */}
        <div className="flex items-center gap-2">
          {onSeekVideo && (
            <button
              type="button"
              onClick={() => onSeekVideo(segment.startTime)}
              className="px-2.5 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-slate-400 hover:text-white text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
              title="वीडियो में उस समय पर जाएं"
            >
              <Play className="w-3 h-3" />
              <span>वीडियो</span>
            </button>
          )}

          <button
            type="button"
            onClick={onPlayToggle}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer ${
              isPlaying
                ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>रोकें</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5" />
                <span>आवाज़ सुनें</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* English Reference Text */}
      {segment.englishText && (
        <div className="text-xs text-slate-400 border-l-2 border-slate-700 pl-2">
          <span className="font-semibold text-slate-500 mr-1.5">English:</span>
          <span className="italic">{segment.englishText}</span>
        </div>
      )}

      {/* Hindi Spoken Dubbing Text */}
      <div className="border-l-2 border-purple-500/70 pl-2.5 py-1 bg-purple-950/20 rounded-r-xl">
        <span className="text-[11px] font-bold text-purple-300 block mb-0.5">Hindi:</span>
        <p className="text-sm sm:text-base font-semibold text-slate-100 leading-relaxed">
          {segment.hindiText}
        </p>
      </div>
    </div>
  );
};
