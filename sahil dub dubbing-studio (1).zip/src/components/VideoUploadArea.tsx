import React, { useRef, useState, useImperativeHandle, forwardRef } from 'react';
import { UploadCloud, AlertCircle, Play, Pause, RefreshCw, FileVideo, Sparkles } from 'lucide-react';
import { VideoItem } from '../types';

export interface VideoUploadAreaHandle {
  seekToTime: (seconds: number) => void;
}

interface VideoUploadAreaProps {
  video: VideoItem | null;
  errorMessage: string | null;
  isValidating: boolean;
  onFileSelect: (file: File) => void;
  onSelectSample?: () => void;
  onClearError: () => void;
}

export const VideoUploadArea = forwardRef<VideoUploadAreaHandle, VideoUploadAreaProps>(({
  video,
  errorMessage,
  isValidating,
  onFileSelect,
  onSelectSample,
  onClearError,
}, ref) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  useImperativeHandle(ref, () => ({
    seekToTime: (seconds: number) => {
      if (videoRef.current) {
        videoRef.current.currentTime = Math.max(0, seconds);
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    },
  }));


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onClearError();
      onFileSelect(file);
    }
    // reset input value so re-selecting same file triggers change
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      onClearError();
      onFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Hidden native input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/quicktime,video/mkv"
        onChange={handleInputChange}
        className="hidden"
      />

      {/* Error Message banner if validation fails (e.g. > 10 minutes) */}
      {errorMessage && (
        <div className="w-full rounded-2xl bg-rose-950/40 border border-rose-500/40 p-4 flex items-start gap-3 shadow-lg shadow-rose-950/30 animate-in fade-in duration-200">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-bold text-rose-200">
              अपलोड त्रुटि
            </h4>
            <p className="text-xs sm:text-sm text-rose-300/90 mt-0.5 font-medium">
              {errorMessage}
            </p>
          </div>
        </div>
      )}

      {/* Main Video Box / Upload Area */}
      {!video ? (
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={`w-full aspect-video sm:max-h-[460px] rounded-3xl border-2 border-dashed transition-all duration-300 flex flex-col items-center justify-center p-6 text-center relative overflow-hidden group ${
            isDragging
              ? 'border-indigo-400 bg-indigo-950/40 scale-[0.99]'
              : 'border-white/10 hover:border-indigo-500/40 bg-[#0B0D18]'
          }`}
        >
          {/* Subtle Ambient Glow */}
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

          {isValidating ? (
            <div className="flex flex-col items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center animate-spin">
                <RefreshCw className="w-7 h-7 text-indigo-400" />
              </div>
              <p className="text-sm font-semibold text-white">
                वीडियो अवधि और फॉर्मेट की पुष्टि की जा रही है...
              </p>
              <p className="text-xs text-slate-400">
                10 मिनट की सीमा जांची जा रही है
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center max-w-md">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-4 group-hover:scale-105 transition-transform shadow-lg shadow-indigo-950/40">
                <UploadCloud className="w-8 h-8 sm:w-10 sm:h-10" />
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-white mb-2">
                अपनी स्थानीय वीडियो फाइल चुनें
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed">
                फाइल को यहाँ ड्रैग करें या नीचे बटन पर क्लिक करके अपने डिवाइस से वीडियो अपलोड करें (MP4, WebM, MOV)
              </p>

              {/* Requirement 7: "वीडियो चुनें" button */}
              <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-xs">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 hover:shadow-indigo-600/50 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <FileVideo className="w-4 h-4" />
                  <span>वीडियो चुनें</span>
                </button>

                {onSelectSample && (
                  <button
                    type="button"
                    onClick={onSelectSample}
                    className="w-full sm:w-auto min-h-[48px] px-4 py-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-slate-300 hover:text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    <span>डेमो टेस्ट</span>
                  </button>
                )}
              </div>

              <div className="mt-5 text-[11px] text-slate-500 font-medium">
                अधिकतम समर्थित अवधि: 10 मिनट (600 सेकंड)
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Video Preview Area */
        <div className="w-full aspect-video sm:max-h-[460px] rounded-3xl bg-black border border-white/10 overflow-hidden relative group shadow-2xl">
          <video
            ref={videoRef}
            src={video.previewUrl}
            onEnded={() => setIsPlaying(false)}
            onClick={togglePlay}
            playsInline
            controls
            className="w-full h-full object-contain cursor-pointer"
          />

          {/* Top floating overlay with change video button */}
          <div className="absolute top-3 left-3 z-10">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-black/70 hover:bg-black/90 backdrop-blur-md border border-white/15 text-xs font-semibold text-slate-200 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
              <span>दूसरी वीडियो चुनें</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
});

VideoUploadArea.displayName = 'VideoUploadArea';
