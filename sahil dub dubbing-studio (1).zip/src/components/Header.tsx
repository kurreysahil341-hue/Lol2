import React from 'react';
import { Film, Sparkles } from 'lucide-react';

interface HeaderProps {
  onReset?: () => void;
  onOpenFlutterCode?: () => void;
  hasVideo: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onReset, onOpenFlutterCode, hasVideo }) => {
  return (
    <header className="w-full border-b border-white/[0.08] bg-[#0A0C14]/90 backdrop-blur-xl sticky top-0 z-30">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 p-[1px] shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-[#0D101C] rounded-[11px] flex items-center justify-center">
              <Film className="w-5 h-5 text-indigo-400" />
            </div>
          </div>

          <div>
            <h1 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5 tracking-tight">
              <span>एआई वीडियो डबिंग</span>
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            </h1>
            <p className="text-xs text-indigo-300/80 font-medium">
              English से Hindi डबिंग (अधिकतम 10 मिनट)
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {onOpenFlutterCode && (
            <button
              type="button"
              onClick={onOpenFlutterCode}
              className="text-xs font-semibold text-indigo-300 hover:text-white px-3 py-1.5 rounded-lg bg-indigo-950/50 hover:bg-indigo-900/60 border border-indigo-500/30 transition-colors cursor-pointer flex items-center gap-1.5"
              title="Flutter और Dart सोर्स कोड देखें"
            >
              <span>Dart & Flutter कोड</span>
            </button>
          )}

          {hasVideo && onReset && (
            <button
              type="button"
              onClick={onReset}
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] transition-colors cursor-pointer"
            >
              नया वीडियो चुनें
            </button>
          )}
        </div>

      </div>
    </header>
  );
};

