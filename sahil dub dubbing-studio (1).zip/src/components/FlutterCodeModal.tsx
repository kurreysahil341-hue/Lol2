import React, { useState } from 'react';
import { X, Copy, Check, Smartphone, FileCode } from 'lucide-react';

interface FlutterCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FlutterCodeModal: React.FC<FlutterCodeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<string>('dubbing_studio');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const flutterCodes: Record<string, { filename: string; code: string }> = {
    dubbing_studio: {
      filename: 'lib/screens/dubbing_studio_screen.dart',
      code: `// Complete 9-Stage Dubbing Studio Screen (Flutter + Dart)
// Located at: flutter_dubbing_app/lib/screens/dubbing_studio_screen.dart
// Features:
// 1. वीडियो तैयार करना (10-min max constraint validation)
// 2. English Speech निकालना (Audio Extraction)
// 3. English Transcript बनाना (Speech-to-Text Transcription)
// 4. Hindi Translation करना (Natural Spoken Hindi Translation)
// 5. Hindi Voice बनाना (Natural Hindi TTS Generation)
// 6. Hindi Voice Synchronize करना (Voice Timing Synchronization)
// 7. Original Audio/Music/SFX Mix करना (Audio Ducking & Music Preservation)
// 8. Final Video बनाना (Video Rendering to MP4)
// 9. Gallery में Save करना (Android MediaStore Gallery Save)`,
    },
    mixed_audio_segment: {
      filename: 'lib/models/mixed_audio_segment.dart',
      code: `class MixedAudioSegment {
  final int id;
  final double startTime;
  final double endTime;
  final String hindiAudioPath;
  final double originalAudioLevel; // e.g. 0.25 ducked during Hindi speech
  final double hindiVoiceLevel; // e.g. 1.00
  final bool duckingApplied;
  final double fadeInDuration; // 0.2s
  final double fadeOutDuration; // 0.3s
  final String status;
  final String englishText;
  final String hindiText;

  MixedAudioSegment({
    required this.id,
    required this.startTime,
    required this.endTime,
    required this.hindiAudioPath,
    this.originalAudioLevel = 0.25,
    this.hindiVoiceLevel = 1.0,
    this.duckingApplied = true,
    this.fadeInDuration = 0.2,
    this.fadeOutDuration = 0.3,
    this.status = 'mixed',
    this.englishText = '',
    this.hindiText = '',
  });

  factory MixedAudioSegment.fromJson(Map<String, dynamic> json) => MixedAudioSegment(
    id: json['id'] ?? 1,
    startTime: (json['startTime'] as num).toDouble(),
    endTime: (json['endTime'] as num).toDouble(),
    hindiAudioPath: json['hindiAudioPath'] ?? '',
    originalAudioLevel: (json['originalAudioLevel'] as num?)?.toDouble() ?? 0.25,
    hindiVoiceLevel: (json['hindiVoiceLevel'] as num?)?.toDouble() ?? 1.0,
    duckingApplied: json['duckingApplied'] ?? true,
    fadeInDuration: (json['fadeInDuration'] as num?)?.toDouble() ?? 0.2,
    fadeOutDuration: (json['fadeOutDuration'] as num?)?.toDouble() ?? 0.3,
    status: json['status'] ?? 'mixed',
    englishText: json['englishText'] ?? '',
    hindiText: json['hindiText'] ?? '',
  );
}`,
    },
    final_video_result: {
      filename: 'lib/models/final_video_result.dart',
      code: `class FinalVideoResult {
  final String id;
  final String videoName;
  final String originalVideoPath;
  final String mixedAudioPath;
  final String outputVideoPath;
  final String filename;
  final double duration;
  final String durationFormatted;
  final int fileSizeBytes;
  final String fileSizeFormatted;
  final bool isSavedToGallery;
  final String? galleryUri;
  final String status;
  final String createdAt;

  FinalVideoResult({
    required this.id,
    required this.videoName,
    required this.originalVideoPath,
    required this.mixedAudioPath,
    required this.outputVideoPath,
    required this.filename,
    required this.duration,
    required this.durationFormatted,
    required this.fileSizeBytes,
    required this.fileSizeFormatted,
    this.isSavedToGallery = false,
    this.galleryUri,
    this.status = 'completed',
    required this.createdAt,
  });
}`,
    },
    audio_mixing_service: {
      filename: 'lib/services/audio_mixing_service.dart',
      code: `abstract class AudioMixingService {
  Future<MixedAudioResult> mixAudioWithDucking({
    required List<SyncedAudioSegment> segments,
    required double totalVideoDuration,
    double originalDuckingLevel = 0.25,
    double hindiVoiceLevel = 1.00,
    double fadeInDuration = 0.2,
    double fadeOutDuration = 0.3,
    Function(int percent, String message)? onProgress,
  });
}`,
    },
    video_rendering_service: {
      filename: 'lib/services/video_rendering_service.dart',
      code: `abstract class VideoRenderingService {
  Future<FinalVideoResult> renderFinalVideo({
    required VideoFile originalVideo,
    required MixedAudioResult mixedAudio,
    Function(int percent, String message)? onProgress,
  });
}`,
    },
    gallery_service: {
      filename: 'lib/services/gallery_service.dart',
      code: `abstract class GalleryService {
  Future<FinalVideoResult> saveVideoToGallery({
    required FinalVideoResult videoResult,
    Function(int percent, String message)? onProgress,
  });

  Future<bool> openInGallery({required String galleryUri});
}`,
    },
    audio_mixing_screen: {
      filename: 'lib/screens/audio_mixing_screen.dart',
      code: `// Audio Mixing & Ducking Screen (Flutter + Dart)
// Located at: flutter_dubbing_app/lib/screens/audio_mixing_screen.dart`,
    },
    final_video_screen: {
      filename: 'lib/screens/final_video_screen.dart',
      code: `// Final Dubbed Video Screen (Flutter + Dart)
// Located at: flutter_dubbing_app/lib/screens/final_video_screen.dart`,
    },
    pubspec: {
      filename: 'pubspec.yaml',
      code: `name: ai_video_dubbing
description: "AI Video Dubbing Studio - English to Hindi Dubbing Flutter Application"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  file_picker: ^8.1.4
  video_player: ^2.9.2
  http: ^1.2.2
  google_fonts: ^6.2.1
  lucide_icons: ^0.252.0
  intl: ^0.19.0
  flutter_animate: ^4.5.2

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true`,
    },
  };

  const current = flutterCodes[activeTab] || flutterCodes['dubbing_studio'];

  const handleCopy = () => {
    navigator.clipboard.writeText(current.code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const tabs = [
    { id: 'dubbing_studio', label: 'Studio Screen (Main)' },
    { id: 'mixed_audio_segment', label: 'MixedAudioSegment (Model)' },
    { id: 'final_video_result', label: 'FinalVideoResult (Model)' },
    { id: 'audio_mixing_service', label: 'AudioMixingService' },
    { id: 'video_rendering_service', label: 'VideoRenderingService' },
    { id: 'gallery_service', label: 'GalleryService (MediaStore)' },
    { id: 'audio_mixing_screen', label: 'AudioMixingScreen' },
    { id: 'final_video_screen', label: 'FinalVideoScreen' },
    { id: 'pubspec', label: 'pubspec.yaml' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-4xl max-h-[90vh] rounded-3xl bg-[#0E111F] border border-white/10 p-5 sm:p-6 shadow-2xl flex flex-col gap-4 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                <span>Flutter & Dart कोड — संपूर्ण 9-चरण डबिंग आर्किटेक्चर</span>
                <span className="text-[11px] font-normal text-emerald-300 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  Master Architecture Ready
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Flutter और Dart में संपूर्ण मोबाइल आर्किटेक्चर (Models, Services, Screens, MediaStore)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === t.id
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-white/[0.04] text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Code View Header */}
        <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-black/40 border border-white/[0.06] text-xs">
          <span className="font-mono text-slate-300 font-medium">{current.filename}</span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 text-xs text-purple-300 hover:text-white transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'कोड कॉपी हो गया!' : 'Dart कोड कॉपी करें'}</span>
          </button>
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-y-auto max-h-[50vh] p-4 rounded-2xl bg-black/60 border border-white/[0.06] font-mono text-xs text-slate-200 whitespace-pre leading-relaxed selection:bg-purple-500/40">
          {current.code}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-xs text-slate-400">
          <span>प्रोजेक्ट फ़ोल्डर: <code>flutter_dubbing_app/lib/</code></span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/[0.08] hover:bg-white/[0.12] text-white font-medium transition-colors cursor-pointer"
          >
            बंद करें
          </button>
        </div>
      </div>
    </div>
  );
};
