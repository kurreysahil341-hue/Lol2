import React, { useState, useRef, useEffect } from 'react';
import { 
  GitMerge, 
  CheckCircle2, 
  Clock, 
  Gauge, 
  Volume2, 
  Square, 
  Play, 
  Sparkles, 
  RotateCcw,
  VolumeX,
  Layers
} from 'lucide-react';
import { SyncResult, SyncedAudioSegment } from '../types';
import { SyncSegmentCard } from './SyncSegmentCard';

interface AudioSyncScreenProps {
  syncResult: SyncResult;
  onSeekVideo?: (seconds: number) => void;
  onReset?: () => void;
}

export const AudioSyncScreen: React.FC<AudioSyncScreenProps> = ({
  syncResult,
  onSeekVideo,
  onReset,
}) => {
  const [playingSegmentId, setPlayingSegmentId] = useState<number | null>(null);
  const [isPlayingAll, setIsPlayingAll] = useState<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playAllIndexRef = useRef<number>(0);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
    };
  }, []);

  const handlePlayToggle = (segment: SyncedAudioSegment) => {
    if (isPlayingAll) {
      stopPlayback();
    }

    if (playingSegmentId === segment.id) {
      stopPlayback();
      return;
    }

    playSegment(segment);
  };

  const playSegment = (segment: SyncedAudioSegment) => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;
    audio.pause();

    const src = segment.audioBase64
      ? `data:audio/mp3;base64,${segment.audioBase64}`
      : segment.audioPath;

    audio.src = src;
    setPlayingSegmentId(segment.id);

    audio.onended = () => {
      setPlayingSegmentId(null);
    };

    audio.onerror = () => {
      setPlayingSegmentId(null);
    };

    audio.play().catch(() => {
      setPlayingSegmentId(null);
    });
  };

  const stopPlayback = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setPlayingSegmentId(null);
    setIsPlayingAll(false);
  };

  const handlePlayAll = () => {
    if (isPlayingAll) {
      stopPlayback();
      return;
    }

    if (syncResult.segments.length === 0) return;

    setIsPlayingAll(true);
    playAllIndexRef.current = 0;
    playNextInSequence();
  };

  const playNextInSequence = () => {
    const idx = playAllIndexRef.current;
    if (idx >= syncResult.segments.length) {
      setIsPlayingAll(false);
      setPlayingSegmentId(null);
      return;
    }

    const seg = syncResult.segments[idx];
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;
    const src = seg.audioBase64
      ? `data:audio/mp3;base64,${seg.audioBase64}`
      : seg.audioPath;

    audio.src = src;
    setPlayingSegmentId(seg.id);

    audio.onended = () => {
      playAllIndexRef.current += 1;
      playNextInSequence();
    };

    audio.onerror = () => {
      playAllIndexRef.current += 1;
      playNextInSequence();
    };

    audio.play().catch(() => {
      setIsPlayingAll(false);
      setPlayingSegmentId(null);
    });
  };

  return (
    <div className="w-full rounded-3xl bg-[#0D101E]/95 backdrop-blur-xl border border-white/[0.08] p-5 sm:p-6 shadow-2xl shadow-black/50 flex flex-col gap-5 animate-in fade-in duration-300">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
            <GitMerge className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>Hindi आवाज़ Timing & Synchronization</span>
              <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/70 px-2.5 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Hindi आवाज़ Sync हो गई</span>
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              मूल अंग्रेजी टाइमलाइन के साथ पिच-सुरक्षित टाइम-स्ट्रेचिंग सिंक
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={handlePlayAll}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isPlayingAll
                ? 'bg-rose-600 border-rose-500 text-white'
                : 'bg-white/[0.06] hover:bg-white/[0.1] border-white/[0.08] text-white'
            }`}
          >
            {isPlayingAll ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>रोकें</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current text-purple-400" />
                <span>सभी Sync आवाज़ें सुनें</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-3 gap-3">
        {/* Total Target Duration */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 shrink-0">
            <Clock className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">लक्षित स्पीच समय</span>
            <span className="text-xs sm:text-sm font-bold text-slate-100 font-mono tabular-nums truncate block">
              {syncResult.totalTargetDuration.toFixed(1)}s
            </span>
          </div>
        </div>

        {/* Total Adjusted Duration */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0">
            <Volume2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">सिंक ऑडियो समय</span>
            <span className="text-xs sm:text-sm font-bold text-emerald-300 font-mono tabular-nums truncate block">
              {syncResult.totalAdjustedDuration.toFixed(1)}s
            </span>
          </div>
        </div>

        {/* Average Speed Adjustment */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04] flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 shrink-0">
            <Gauge className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] text-slate-400 block font-medium">औसत गति परिवर्तन</span>
            <span className="text-xs sm:text-sm font-bold text-purple-300 font-mono tabular-nums truncate block">
              {syncResult.averageSpeedAdjustment.toFixed(2)}x
            </span>
          </div>
        </div>
      </div>

      {/* Silence & Gap Preservation Banner (Requirement 6) */}
      <div className="p-3.5 rounded-2xl bg-white/[0.025] border border-white/[0.06] flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
          <VolumeX className="w-4 h-4" />
        </div>
        <div className="text-xs">
          <span className="font-bold text-slate-200 block">संवादों के बीच का प्राकृतिक मौन (Silence / Gaps) सुरक्षित रखा गया है</span>
          <span className="text-slate-400 block mt-0.5">
            प्रत्येक संवाद अपने मूल समय (startTime) पर ही शुरू होगा। बीच के अंतराल या ब्रेक को बिना छेड़े सुरक्षित रखा गया है।
          </span>
        </div>
      </div>

      {/* Scrollable list of Synced Segments */}
      <div className="flex flex-col">
        <div className="flex items-center justify-between text-xs text-slate-400 font-medium px-1 mb-2">
          <span>सिंक्रोनाइज़ किए गए हिंदी संवाद (Sync की गई आवाज़ सुनें):</span>
          <span>{syncResult.segments.length} संवाद खंड</span>
        </div>

        <div className="max-h-[460px] overflow-y-auto pr-2 space-y-3 rounded-2xl border border-white/[0.05] p-3 bg-black/40">
          {syncResult.segments.map((segment) => (
            <SyncSegmentCard
              key={segment.id}
              segment={segment}
              isPlaying={playingSegmentId === segment.id}
              onPlayToggle={() => handlePlayToggle(segment)}
              onSeekVideo={onSeekVideo}
            />
          ))}
        </div>
      </div>

      {/* Prompt 6 Notice (Audio Mixing) */}
      <div className="rounded-2xl bg-indigo-950/30 border border-indigo-500/20 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="text-center sm:text-left">
          <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 justify-center sm:justify-start">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>अगला चरण 6: Original Music/SFX + Hindi Voice Mixing</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            मूल वीडियो का background music और sound effects बचाते हुए इस Synchronized Hindi Voice को final audio track में mix करेंगे।
          </p>
        </div>

        {onReset && (
          <button
            type="button"
            onClick={onReset}
            className="px-4 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.1] text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>नई वीडियो टेस्ट करें</span>
          </button>
        )}
      </div>

    </div>
  );
};
