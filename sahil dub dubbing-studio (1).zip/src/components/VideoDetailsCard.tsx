import React from 'react';
import { FileText, Clock, HardDrive, CheckCircle2 } from 'lucide-react';
import { VideoItem } from '../types';

interface VideoDetailsCardProps {
  video: VideoItem;
}

export const VideoDetailsCard: React.FC<VideoDetailsCardProps> = ({ video }) => {
  return (
    <div className="w-full rounded-2xl bg-[#0D101E]/90 backdrop-blur-xl border border-white/[0.08] p-4 sm:p-5 shadow-xl shadow-black/40">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/[0.06]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
            <FileText className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-semibold text-white">
            चयनित वीडियो का विवरण
          </h3>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-500/20">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span className="font-medium text-[11px]">10 मिनट के भीतर मान्य</span>
        </div>
      </div>

      {/* Grid of properties */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* File name */}
        <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">
            फाइल का नाम
          </span>
          <p className="text-xs sm:text-sm font-semibold text-slate-100 truncate" title={video.name}>
            {video.name}
          </p>
        </div>

        {/* Duration */}
        <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-400 mb-1">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span>अवधि</span>
          </div>
          <p className="text-xs sm:text-sm font-semibold text-slate-100 font-mono tabular-nums">
            {video.duration} / 10:00 अधिकतम
          </p>
        </div>

        {/* File size */}
        <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-400 mb-1">
            <HardDrive className="w-3.5 h-3.5 text-purple-400" />
            <span>फाइल साइज</span>
          </div>
          <p className="text-xs sm:text-sm font-semibold text-slate-100 font-mono tabular-nums">
            {video.size}
          </p>
        </div>
      </div>
    </div>
  );
};
