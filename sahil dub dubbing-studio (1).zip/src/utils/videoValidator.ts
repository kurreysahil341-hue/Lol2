export const MAX_VIDEO_DURATION_SECONDS = 600; // 10 minutes

export interface VideoValidationResult {
  isValid: boolean;
  errorMessage?: string;
  durationSeconds?: number;
  durationFormatted?: string;
  fileSizeFormatted?: string;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

export function formatDuration(totalSeconds: number): string {
  if (isNaN(totalSeconds) || totalSeconds < 0) return '00:00';
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

/**
 * Validates a selected video file by loading its metadata in a temporary video element.
 * Checks if duration is <= 10 minutes (600 seconds).
 */
export function validateVideoFile(file: File): Promise<VideoValidationResult> {
  return new Promise((resolve) => {
    // Validate file type
    if (!file.type.startsWith('video/')) {
      resolve({
        isValid: false,
        errorMessage: 'कृपया केवल मान्य वीडियो फाइल (MP4, WebM, MOV) चुनें।',
      });
      return;
    }

    const videoElement = document.createElement('video');
    videoElement.preload = 'metadata';
    const objectUrl = URL.createObjectURL(file);
    videoElement.src = objectUrl;

    videoElement.onloadedmetadata = () => {
      URL.revokeObjectURL(objectUrl);
      const duration = videoElement.duration;

      if (isNaN(duration) || duration === 0) {
        resolve({
          isValid: false,
          errorMessage: 'वीडियो की अवधि लोड करने में असमर्थ। कृपया दूसरी वीडियो फाइल चुनें।',
        });
        return;
      }

      // Check 10-minute constraint (600 seconds)
      if (duration > MAX_VIDEO_DURATION_SECONDS) {
        resolve({
          isValid: false,
          errorMessage: 'अभी अधिकतम 10 मिनट की वीडियो ही समर्थित है।',
          durationSeconds: duration,
          durationFormatted: formatDuration(duration),
          fileSizeFormatted: formatFileSize(file.size),
        });
        return;
      }

      resolve({
        isValid: true,
        durationSeconds: duration,
        durationFormatted: formatDuration(duration),
        fileSizeFormatted: formatFileSize(file.size),
      });
    };

    videoElement.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      resolve({
        isValid: false,
        errorMessage: 'वीडियो लोड करने में त्रुटि हुई। कृपया दूसरी फाइल आज़माएँ।',
      });
    };
  });
}
