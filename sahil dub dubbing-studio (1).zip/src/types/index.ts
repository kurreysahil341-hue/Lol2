export interface VideoItem {
  file: File;
  name: string;
  duration: string;
  durationSeconds: number;
  size: string;
  previewUrl: string;
}

export type PipelineStepId =
  | 'video'
  | 'audio_extract'
  | 'speech_recognition'
  | 'translation'
  | 'tts_synthesis'
  | 'sync_audio'
  | 'dub_ready';

export type StepStatus = 'waiting' | 'in_progress' | 'completed' | 'error';

export interface PipelineStep {
  id: PipelineStepId;
  title: string;
  hindiTitle: string;
  subtitle: string;
  status: StepStatus;
  progress: number;
  statusMessage?: string;
}

export interface TranscriptSegment {
  id: number;
  startTime: number;
  endTime: number;
  text: string;
}

export interface StructuredTranscript {
  sourceLanguage: string;
  targetLanguage: string;
  duration: number;
  segments: TranscriptSegment[];
  createdAt: string;
  videoName?: string;
}

export interface DubSegment {
  id: number;
  startTime: number;
  endTime: number;
  englishText: string;
  hindiText: string;
}

export interface DubbedTranscript {
  sourceLanguage: string;
  targetLanguage: string;
  duration: number;
  videoName?: string;
  segments: DubSegment[];
  createdAt: string;
}

export interface VoiceSettings {
  language: string; // 'hi'
  voiceName: string; // 'hi-IN-Neural-1'
  speed: number; // 0.8 - 1.2
  pitch: number; // 0.8 - 1.2
  volume: number; // 0.0 - 1.0
}

export interface HindiAudioSegment {
  id: number;
  startTime: number;
  endTime: number;
  englishText: string;
  hindiText: string;
  audioPath: string; // URL endpoint e.g. /api/audio/segment_1.mp3
  audioBase64?: string;
  generatedDuration: number;
  originalDuration: number;
  durationDifference: number;
}

export interface HindiTtsResult {
  segments: HindiAudioSegment[];
  totalOriginalDuration: number;
  totalGeneratedDuration: number;
  voiceSettings: VoiceSettings;
  createdAt: string;
}

export type TimingClassification =
  | 'fits_naturally'
  | 'slightly_longer'
  | 'slightly_shorter'
  | 'significantly_longer'
  | 'significantly_shorter';

export type SyncStatus =
  | 'synchronized'
  | 'fits_naturally'
  | 'adjusted_speed'
  | 'clamped_speed'
  | 'processing'
  | 'error';

export interface SyncedAudioSegment {
  id: number;
  startTime: number;
  endTime: number;
  targetDuration: number;
  originalAudioDuration: number;
  hindiAudioDuration: number;
  adjustedDuration: number;
  audioPath: string;
  audioBase64?: string;
  speedAdjustment: number;
  status: SyncStatus;
  timingClassification: TimingClassification;
  timingClassificationHindi: string;
  remainingDifference: number;
  englishText: string;
  hindiText: string;
}

export interface SyncResult {
  segments: SyncedAudioSegment[];
  totalTargetDuration: number;
  totalAdjustedDuration: number;
  averageSpeedAdjustment: number;
  naturallyFitCount: number;
  speedAdjustedCount: number;
  clampedCount: number;
  createdAt: string;
}

export interface TranscribeRequest {
  audioBase64: string;
  mimeType: string;
  durationSeconds: number;
  videoName?: string;
}

export interface TranscribeResponse {
  success: boolean;
  transcript?: StructuredTranscript;
  error?: string;
  errorCode?: string;
}

export interface TranslateRequest {
  segments: TranscriptSegment[] | DubSegment[];
  duration?: number;
  videoName?: string;
}

export interface TranslateResponse {
  success: boolean;
  translation?: DubbedTranscript;
  error?: string;
  errorCode?: string;
}

export interface TtsResponse {
  success: boolean;
  result?: HindiTtsResult;
  error?: string;
  errorCode?: string;
}

export interface SyncResponse {
  success: boolean;
  result?: SyncResult;
  error?: string;
  errorCode?: string;
}
