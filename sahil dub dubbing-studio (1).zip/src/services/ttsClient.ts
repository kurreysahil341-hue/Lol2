import { DubSegment, HindiTtsResult, TtsResponse, VoiceSettings } from '../types';

export class TtsClientError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = 'TtsClientError';
  }
}

/**
 * Calls secure server endpoint to synthesize timestamped Hindi audio segments
 */
export async function sendHindiTranscriptForTts(params: {
  segments: DubSegment[];
  voiceSettings?: Partial<VoiceSettings>;
  provider?: string;
}): Promise<HindiTtsResult> {
  const { segments, voiceSettings, provider = 'google-hindi' } = params;

  if (!segments || segments.length === 0) {
    throw new TtsClientError('EMPTY_SEGMENTS', 'हिंदी आवाज़ बनाने के लिए कोई संवाद उपलब्ध नहीं है।');
  }

  try {
    const response = await fetch('/api/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        segments,
        voiceSettings,
        provider,
      }),
    });

    const data: TtsResponse = await response.json();

    if (!response.ok || !data.success || !data.result) {
      const errorMessage = data.error || 'हिंदी आवाज़ बनाने में समस्या हुई। कृपया दोबारा प्रयास करें।';
      throw new TtsClientError(data.errorCode || 'TTS_ERROR', errorMessage);
    }

    return data.result;
  } catch (err: any) {
    if (err instanceof TtsClientError) {
      throw err;
    }

    throw new TtsClientError(
      'NETWORK_ERROR',
      'सर्वर या नेटवर्क से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।'
    );
  }
}
