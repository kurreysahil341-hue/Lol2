import { DubbedTranscript, TranscriptSegment, TranslateResponse } from '../types';

export class TranslationClientError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = 'TranslationClientError';
  }
}

/**
 * Sends real English speech segments to the protected server API for natural spoken Hindi translation
 */
export async function sendTranscriptForTranslation(params: {
  segments: TranscriptSegment[];
  duration: number;
  videoName: string;
}): Promise<DubbedTranscript> {
  const { segments, duration, videoName } = params;

  if (!segments || segments.length === 0) {
    throw new TranslationClientError('EMPTY_TRANSCRIPT', 'अनुवाद के लिए कोई ट्रांसक्रिप्ट उपलब्ध नहीं है।');
  }

  try {
    const response = await fetch('/api/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        segments,
        duration,
        videoName,
      }),
    });

    const data: TranslateResponse = await response.json();

    if (!response.ok || !data.success || !data.translation) {
      const errorMessage = data.error || 'हिंदी अनुवाद करने में समस्या हुई। कृपया दोबारा प्रयास करें।';
      throw new TranslationClientError(data.errorCode || 'API_ERROR', errorMessage);
    }

    return data.translation;
  } catch (err: any) {
    if (err instanceof TranslationClientError) {
      throw err;
    }

    throw new TranslationClientError(
      'NETWORK_ERROR',
      'सर्वर या नेटवर्क से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।'
    );
  }
}
