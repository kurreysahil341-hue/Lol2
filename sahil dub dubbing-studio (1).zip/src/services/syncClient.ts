import { HindiAudioSegment, SyncResponse, SyncResult } from '../types';

export class SyncClientError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = 'SyncClientError';
  }
}

/**
 * Sends Hindi audio segments to backend synchronization service
 */
export async function sendSegmentsForSynchronization(
  segments: HindiAudioSegment[]
): Promise<SyncResult> {
  if (!segments || segments.length === 0) {
    throw new SyncClientError('EMPTY_SEGMENTS', 'सिंक्रोनाइज़ेशन के लिए कोई ऑडियो सेगमेंट उपलब्ध नहीं है।');
  }

  try {
    const response = await fetch('/api/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        segments,
      }),
    });

    const data: SyncResponse = await response.json();

    if (!response.ok || !data.success || !data.result) {
      const errorMessage = data.error || 'हिंदी आवाज़ सिंक्रोनाइज़ करने में समस्या हुई। कृपया दोबारा प्रयास करें।';
      throw new SyncClientError(data.errorCode || 'SYNC_ERROR', errorMessage);
    }

    return data.result;
  } catch (err: any) {
    if (err instanceof SyncClientError) {
      throw err;
    }

    throw new SyncClientError(
      'NETWORK_ERROR',
      'सर्वर या नेटवर्क से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।'
    );
  }
}
