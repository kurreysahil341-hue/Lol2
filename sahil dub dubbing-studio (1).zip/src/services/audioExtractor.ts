/**
 * Audio Extraction Service
 * Extracts audio track from video files using the Web Audio API,
 * detects presence of audio streams, and encodes to 16kHz mono WAV format.
 */

export class AudioExtractionError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = 'AudioExtractionError';
  }
}

export interface ExtractedAudioResult {
  audioBlob: Blob;
  audioBase64: string;
  duration: number;
  sampleRate: number;
}

export type ExtractionProgressCallback = (percent: number, message: string) => void;

/**
 * Extracts and downsamples audio from a video file to 16kHz 16-bit Mono WAV.
 */
export async function extractAudioFromVideo(
  file: File,
  onProgress?: ExtractionProgressCallback
): Promise<ExtractedAudioResult> {
  onProgress?.(10, 'वीडियो फाइल पढ़ी जा रही है...');

  let arrayBuffer: ArrayBuffer;
  try {
    arrayBuffer = await file.arrayBuffer();
  } catch (err) {
    throw new AudioExtractionError(
      'FILE_READ_ERROR',
      'वीडियो फाइल पढ़ने में असमर्थ। कृपया पुनः प्रयास करें।'
    );
  }

  onProgress?.(30, 'ऑडियो ट्रैक का विश्लेषण किया जा रहा है...');

  // Initialize AudioContext
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextClass) {
    throw new AudioExtractionError(
      'UNSUPPORTED_BROWSER',
      'आपका ब्राउज़र वेब ऑडियो डिकोडिंग का समर्थन नहीं करता है।'
    );
  }

  const audioContext = new AudioContextClass();
  let decodedBuffer: AudioBuffer;

  try {
    // decodeAudioData extracts the audio track embedded in MP4/WebM/MOV container
    decodedBuffer = await audioContext.decodeAudioData(arrayBuffer);
  } catch (decodeError) {
    // If decode fails, it is usually because the video has no audio track or unsupported codec
    throw new AudioExtractionError(
      'NO_AUDIO_TRACK',
      'इस वीडियो में कोई ऑडियो नहीं मिला।'
    );
  } finally {
    try {
      await audioContext.close();
    } catch (_) {}
  }

  // Validate audio presence
  if (!decodedBuffer || decodedBuffer.numberOfChannels === 0 || decodedBuffer.length === 0) {
    throw new AudioExtractionError(
      'NO_AUDIO_TRACK',
      'इस वीडियो में कोई ऑडियो नहीं मिला।'
    );
  }

  // Check if buffer contains only silence
  const hasAudioContent = checkBufferHasSignal(decodedBuffer);
  if (!hasAudioContent) {
    throw new AudioExtractionError(
      'NO_AUDIO_TRACK',
      'इस वीडियो में कोई ऑडियो नहीं मिला।'
    );
  }

  onProgress?.(55, 'ऑडियो को 16kHz मोनो में अनुकूलित किया जा रहा है...');

  // Resample and convert to 16kHz mono for optimal Speech-to-Text accuracy & compact size
  const targetSampleRate = 16000;
  const targetChannels = 1;
  const duration = decodedBuffer.duration;

  const offlineContext = new OfflineAudioContext(
    targetChannels,
    Math.ceil(duration * targetSampleRate),
    targetSampleRate
  );

  const sourceNode = offlineContext.createBufferSource();
  sourceNode.buffer = decodedBuffer;
  sourceNode.connect(offlineContext.destination);
  sourceNode.start(0);

  const renderedBuffer = await offlineContext.startRendering();

  onProgress?.(80, 'WAV ऑडियो एन्कोडिंग पूर्ण हो रही है...');

  // Encode 16-bit PCM WAV
  const wavBlob = audioBufferToWavBlob(renderedBuffer);

  onProgress?.(95, 'ऑडियो स्पीच रिकॉग्निशन के लिए तैयार किया जा रहा है...');

  const audioBase64 = await blobToBase64(wavBlob);

  onProgress?.(100, 'ऑडियो सफलतापूर्वक निकाला गया... 100%');

  return {
    audioBlob: wavBlob,
    audioBase64,
    duration,
    sampleRate: targetSampleRate,
  };
}

/**
 * Checks whether the audio buffer contains detectable sound or is complete silence
 */
function checkBufferHasSignal(buffer: AudioBuffer): boolean {
  const channelData = buffer.getChannelData(0);
  // Sample every 100th frame for efficiency
  const step = Math.max(1, Math.floor(channelData.length / 5000));
  let nonZeroCount = 0;

  for (let i = 0; i < channelData.length; i += step) {
    if (Math.abs(channelData[i]) > 0.0001) {
      nonZeroCount++;
      if (nonZeroCount > 10) return true;
    }
  }

  return nonZeroCount > 10;
}

/**
 * Converts AudioBuffer to standard 16-bit PCM WAV Blob with proper 44-byte RIFF header.
 */
function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const dataLength = buffer.length * blockAlign;
  const bufferLength = 44 + dataLength;

  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  // file length minus RIFF identifier & file length itself
  view.setUint32(4, 36 + dataLength, true);
  // RIFF type
  writeString(view, 8, 'WAVE');
  // format chunk identifier
  writeString(view, 12, 'fmt ');
  // format chunk length
  view.setUint32(16, 16, true);
  // sample format (raw)
  view.setUint16(20, format, true);
  // channel count
  view.setUint16(22, numChannels, true);
  // sample rate
  view.setUint32(24, sampleRate, true);
  // byte rate (sample rate * block align)
  view.setUint32(28, sampleRate * blockAlign, true);
  // block align (channel count * bytes per sample)
  view.setUint16(32, blockAlign, true);
  // bits per sample
  view.setUint16(34, bitDepth, true);
  // data chunk identifier
  writeString(view, 36, 'data');
  // data chunk length
  view.setUint32(40, dataLength, true);

  // Write interleaved PCM samples
  const channelData: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channelData.push(buffer.getChannelData(c));
  }

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      // Clamp between -1 and 1
      const sample = Math.max(-1, Math.min(1, channelData[c][i]));
      // Scale to 16-bit signed integer
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string): void {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      // Strip "data:audio/wav;base64," prefix
      const commaIndex = result.indexOf(',');
      if (commaIndex !== -1) {
        resolve(result.substring(commaIndex + 1));
      } else {
        resolve(result);
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
