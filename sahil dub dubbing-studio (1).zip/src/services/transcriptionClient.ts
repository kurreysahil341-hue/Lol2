import { StructuredTranscript, TranscribeResponse } from '../types';

export class TranscriptionClientError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = 'TranscriptionClientError';
  }
}

/**
 * Sends extracted audio to the server-side STT API for speech recognition.
 */
export async function sendAudioForTranscription(params: {
  audioBase64: string;
  durationSeconds: number;
  videoName: string;
  mimeType?: string;
}): Promise<StructuredTranscript> {
  const { audioBase64, durationSeconds, videoName, mimeType = 'audio/wav' } = params;

  try {
    const response = await fetch('/api/transcribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        audioBase64,
        mimeType,
        durationSeconds,
        videoName,
      }),
    });

    const data: TranscribeResponse = await response.json();

    if (!response.ok || !data.success || !data.transcript) {
      const errorMessage = data.error || 'English आवाज़ को पहचानने में समस्या हुई। कृपया दोबारा प्रयास करें।';
      throw new TranscriptionClientError(data.errorCode || 'API_ERROR', errorMessage);
    }

    return data.transcript;
  } catch (err: any) {
    if (err instanceof TranscriptionClientError) {
      throw err;
    }

    // Network or server connection failure
    throw new TranscriptionClientError(
      'NETWORK_ERROR',
      'सर्वर या नेटवर्क से जुड़ने में समस्या हुई। कृपया जांचें कि सर्वर चल रहा है।'
    );
  }
}
