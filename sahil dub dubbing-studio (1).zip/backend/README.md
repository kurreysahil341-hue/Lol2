# AI Video Dubbing Backend — Phase 1 (Video Upload + Validation + Audio Extraction)

Production-ready modular backend for AI Video Dubbing Studio (English to Hindi).

## Phase 1 Capabilities
- **Video Upload**: Multi-format video intake (MP4, MOV, WebM).
- **Security & Validation**: Sanitized filenames, cryptographic `jobId`, MIME/container checks, and strict 10-minute (600s) maximum duration constraint via FFprobe.
- **Temporary Storage**: Isolated temporary storage with path traversal protection and job-based file cleanup.
- **Audio Extraction**: Safe FFmpeg extraction to uncompressed 16kHz mono WAV suitable for subsequent Speech-to-Text (STT) processing.
- **Clean Architecture**: Modular structure designed for seamless plug-in of subsequent phases (STT, Hindi Translation, TTS, Audio Sync, Audio Mixing, and Final MP4 Rendering).

---

## Project Structure
```
backend/
  app/
    main.py              # FastAPI application entry point & CORS configuration
    config.py            # Environment configuration & limits
    routes/
      health.py          # GET /api/health
      video.py           # POST /api/video/upload & POST /api/video/{jobId}/extract-audio
    services/
      video_service.py   # Video saving, validation, and FFprobe inspection
      audio_service.py   # FFmpeg safe audio extraction service
    models/
      video_models.py    # Pydantic schemas for requests & responses
    utils/
      file_utils.py      # Sanitization, job IDs, path safety, and cleanup
      ffmpeg_utils.py    # Subprocess execution for ffprobe & ffmpeg
  temp/                  # Ephemeral job storage
  outputs/               # Final rendered artifacts
  requirements.txt
  .env.example
  .gitignore
  README.md
```

---

## API Endpoints

### 1. Health Check
`GET /api/health`
```json
{
  "status": "ok",
  "service": "AI Video Dubbing Backend",
  "phase": 1
}
```

### 2. Video Upload & Validation
`POST /api/video/upload`
- Accepts `multipart/form-data` with field `video`.
- Supported formats: MP4, MOV, WebM.
- Enforces `<= 600s` duration constraint.

Response:
```json
{
  "success": true,
  "jobId": "job_a1b2c3d4e5f60718",
  "video": {
    "duration": 120.5,
    "width": 1920,
    "height": 1080,
    "fileSize": 12345678,
    "hasAudio": true,
    "videoCodec": "h264",
    "audioCodec": "aac",
    "frameRate": "30/1"
  }
}
```

### 3. Audio Extraction
`POST /api/video/{jobId}/extract-audio`
- Extracts audio to 16kHz mono 16-bit PCM WAV.
- Preserves original video file.

Response:
```json
{
  "success": true,
  "jobId": "job_a1b2c3d4e5f60718",
  "audioPath": "/api/media/audio/job_a1b2c3d4e5f60718.wav",
  "duration": 120.5
}
```
