import os
from typing import Dict, Any
from fastapi import HTTPException
from backend.app.services.video_service import video_service
from backend.app.utils.file_utils import get_job_audio_path
from backend.app.utils.ffmpeg_utils import (
    extract_audio_from_video,
    inspect_media_file,
    AudioExtractionError,
    MediaInspectionError
)

class AudioService:
    @staticmethod
    def extract_audio(job_id: str) -> Dict[str, Any]:
        """
        Extracts audio from uploaded video corresponding to job_id into a temporary WAV file.
        Returns internal API reference and verified duration.
        """
        video_path = video_service.get_video_path_for_job(job_id)
        audio_path = get_job_audio_path(job_id)

        try:
            extract_audio_from_video(video_path, audio_path)
        except AudioExtractionError as e:
            raise HTTPException(status_code=500, detail=f"Failed to extract audio: {str(e)}")

        if not os.path.exists(audio_path):
            raise HTTPException(status_code=500, detail="Audio file was not generated.")

        try:
            info = inspect_media_file(audio_path)
            duration = info.get("duration", 0.0)
        except MediaInspectionError:
            duration = 0.0

        # Safe internal reference URL (not raw filesystem structure)
        internal_audio_ref = f"/api/media/audio/{job_id}.wav"

        return {
            "jobId": job_id,
            "audioPath": internal_audio_ref,
            "duration": duration,
        }

audio_service = AudioService()
