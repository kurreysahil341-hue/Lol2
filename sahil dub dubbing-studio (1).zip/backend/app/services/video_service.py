import os
from typing import Dict, Any, Tuple
from fastapi import UploadFile, HTTPException
from backend.app.config import settings
from backend.app.utils.file_utils import (
    generate_job_id,
    sanitize_extension,
    is_allowed_extension,
    get_job_video_path,
    find_uploaded_video_by_job_id,
)
from backend.app.utils.ffmpeg_utils import inspect_media_file, MediaInspectionError

class VideoService:
    @staticmethod
    async def save_and_validate_video(file: UploadFile) -> Tuple[str, Dict[str, Any]]:
        """
        Receives uploaded video file, saves it to temp storage under a unique job ID,
        and runs ffprobe inspection to validate container and <= 600s duration.
        """
        if not file.filename:
            raise HTTPException(status_code=400, detail="No video file provided.")

        ext = sanitize_extension(file.filename)
        if not is_allowed_extension(file.filename):
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported format '.{ext}'. Supported formats: MP4, MOV, WebM."
            )

        job_id = generate_job_id()
        dest_path = get_job_video_path(job_id, ext)

        total_bytes = 0
        try:
            with open(dest_path, "wb") as out_file:
                while chunk := await file.read(1024 * 1024): # 1MB chunks
                    total_bytes += len(chunk)
                    if total_bytes > settings.MAX_UPLOAD_SIZE_BYTES:
                        raise HTTPException(
                            status_code=400,
                            detail=f"Video file exceeds maximum allowed size of {settings.MAX_UPLOAD_SIZE_MB}MB."
                        )
                    out_file.write(chunk)
        except HTTPException:
            if os.path.exists(dest_path):
                os.remove(dest_path)
            raise
        except Exception as e:
            if os.path.exists(dest_path):
                os.remove(dest_path)
            raise HTTPException(status_code=500, detail=f"Failed to save video: {str(e)}")

        # Validate with ffprobe
        try:
            info = inspect_media_file(dest_path)
        except MediaInspectionError as e:
            if os.path.exists(dest_path):
                os.remove(dest_path)
            raise HTTPException(
                status_code=400,
                detail=f"Invalid or corrupted video file: {str(e)}"
            )

        duration = info.get("duration", 0.0)

        # Enforce maximum 10-minute constraint (600 seconds)
        if duration > settings.MAX_VIDEO_DURATION_SECONDS:
            if os.path.exists(dest_path):
                os.remove(dest_path)
            raise HTTPException(
                status_code=400,
                detail="Video duration cannot exceed 10 minutes."
            )

        info["fileSize"] = total_bytes
        return job_id, info

    @staticmethod
    def get_video_path_for_job(job_id: str) -> str:
        path = find_uploaded_video_by_job_id(job_id)
        if not path or not os.path.exists(path):
            raise HTTPException(status_code=404, detail="Video file for this job was not found.")
        return path

video_service = VideoService()
