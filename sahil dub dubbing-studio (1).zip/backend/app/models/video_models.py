from typing import Optional
from pydantic import BaseModel, Field

class HealthResponse(BaseModel):
    status: str = "ok"
    service: str = "AI Video Dubbing Backend"
    phase: int = 1

class VideoMeta(BaseModel):
    duration: float = Field(..., description="Duration in seconds")
    width: Optional[int] = Field(None, description="Video width in pixels")
    height: Optional[int] = Field(None, description="Video height in pixels")
    fileSize: int = Field(..., description="File size in bytes")
    hasAudio: bool = Field(..., description="Whether video contains audio stream")
    videoCodec: Optional[str] = None
    audioCodec: Optional[str] = None
    frameRate: Optional[str] = None

class VideoUploadResponse(BaseModel):
    success: bool = True
    jobId: str
    video: VideoMeta

class AudioExtractionResponse(BaseModel):
    success: bool = True
    jobId: str
    audioPath: str
    duration: float

class ErrorResponse(BaseModel):
    success: bool = False
    error: str
