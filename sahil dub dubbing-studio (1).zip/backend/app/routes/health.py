from fastapi import APIRouter
from backend.app.models.video_models import HealthResponse
from backend.app.config import settings

router = APIRouter(prefix="/api", tags=["health"])

@router.get("/health", response_model=HealthResponse)
async def get_health():
    """
    Health check endpoint for Phase 1.
    Never exposes API secrets or internal keys.
    """
    return HealthResponse(
        status="ok",
        service=settings.SERVICE_NAME,
        phase=settings.PHASE
    )
