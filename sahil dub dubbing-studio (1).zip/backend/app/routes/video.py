import os
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from backend.app.models.video_models import (
    VideoUploadResponse,
    VideoMeta,
    AudioExtractionResponse,
    ErrorResponse
)
from backend.app.services.video_service import video_service
from backend.app.services.audio_service import audio_service
from backend.app.utils.file_utils import get_job_audio_path

router = APIRouter(prefix="/api/video", tags=["video"])

@router.post(
    "/upload",
    response_model=VideoUploadResponse,
    responses={400: {"model": ErrorResponse}, 500: {"model": ErrorResponse}}
)
async def upload_video(video: UploadFile = File(...)):
    """
    Accepts multipart/form-data with field 'video'.
    Validates format, size, media integrity, and strict duration <= 600s.
    """
    try:
        job_id, info = await video_service.save_and_validate_video(video)
        return VideoUploadResponse(
            success=True,
            jobId=job_id,
            video=VideoMeta(
                duration=info["duration"],
                width=info.get("width"),
                height=info.get("height"),
                fileSize=info.get("fileSize", 0),
                hasAudio=info.get("hasAudio", False),
                videoCodec=info.get("videoCodec"),
                audioCodec=info.get("audioCodec"),
                frameRate=info.get("frameRate")
            )
        )
    except HTTPException as e:
        return JSONResponse(
            status_code=e.status_code,
            content={"success": False, "error": e.detail}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"success": False, "error": f"Upload processing error: {str(e)}"}
        )

@router.post(
    "/{job_id}/extract-audio",
    response_model=AudioExtractionResponse,
    responses={400: {"model": ErrorResponse}, 404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}}
)
async def extract_audio(job_id: str):
    """
    Safely extracts audio from the uploaded video into a temporary 16kHz mono WAV file.
    Preserves original uploaded video untouched.
    """
    try:
        result = audio_service.extract_audio(job_id)
        return AudioExtractionResponse(
            success=True,
            jobId=result["jobId"],
            audioPath=result["audioPath"],
            duration=result["duration"]
        )
    except HTTPException as e:
        return JSONResponse(
            status_code=e.status_code,
            content={"success": False, "error": e.detail}
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"success": False, "error": f"Audio extraction error: {str(e)}"}
        )

@router.get("/media/audio/{job_id}.wav")
async def get_extracted_audio(job_id: str):
    """
    Safely streams the extracted WAV file by job_id without exposing internal directory structures.
    """
    audio_path = get_job_audio_path(job_id)
    if not os.path.exists(audio_path):
        raise HTTPException(status_code=404, detail="Extracted audio file not found.")

    return FileResponse(
        path=audio_path,
        media_type="audio/wav",
        filename=f"{job_id}.wav"
    )
