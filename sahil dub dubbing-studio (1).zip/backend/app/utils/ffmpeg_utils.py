import json
import subprocess
from typing import Dict, Any, Optional

class MediaInspectionError(Exception):
    pass

class AudioExtractionError(Exception):
    pass

def inspect_media_file(file_path: str) -> Dict[str, Any]:
    """
    Safely inspects a media file using ffprobe.
    Executes directly with arguments list (shell=False).
    Returns duration, dimensions, codecs, and stream availability.
    """
    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        file_path
    ]

    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=15,
            check=True
        )
    except subprocess.TimeoutExpired:
        raise MediaInspectionError("Media inspection timed out.")
    except subprocess.CalledProcessError as e:
        raise MediaInspectionError(f"ffprobe failed to inspect media: {e.stderr}")
    except Exception as e:
        raise MediaInspectionError(f"Unexpected error running ffprobe: {str(e)}")

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        raise MediaInspectionError("Invalid JSON returned by ffprobe.")

    fmt = data.get("format", {})
    streams = data.get("streams", [])

    duration_str = fmt.get("duration")
    duration = float(duration_str) if duration_str is not None else 0.0

    video_stream: Optional[Dict[str, Any]] = None
    audio_stream: Optional[Dict[str, Any]] = None

    for s in streams:
        codec_type = s.get("codec_type")
        if codec_type == "video" and not video_stream:
            video_stream = s
        elif codec_type == "audio" and not audio_stream:
            audio_stream = s

    width = video_stream.get("width") if video_stream else None
    height = video_stream.get("height") if video_stream else None
    video_codec = video_stream.get("codec_name") if video_stream else None
    audio_codec = audio_stream.get("codec_name") if audio_stream else None
    frame_rate = video_stream.get("r_frame_rate") if video_stream else None
    has_audio = audio_stream is not None

    # Fallback to stream duration if format duration was 0
    if duration <= 0.0:
        if video_stream and video_stream.get("duration"):
            duration = float(video_stream["duration"])
        elif audio_stream and audio_stream.get("duration"):
            duration = float(audio_stream["duration"])

    return {
        "duration": round(duration, 2),
        "width": width,
        "height": height,
        "videoCodec": video_codec,
        "audioCodec": audio_codec,
        "frameRate": frame_rate,
        "hasAudio": has_audio,
        "formatName": fmt.get("format_name", "")
    }

def extract_audio_from_video(input_video_path: str, output_audio_path: str) -> None:
    """
    Safely extracts audio track from video to standard 16kHz mono 16-bit PCM WAV.
    Keeps the original video file unmodified.
    Executes directly with arguments list (shell=False).
    """
    cmd = [
        "ffmpeg",
        "-y",                   # Overwrite output without asking
        "-i", input_video_path, # Input video
        "-vn",                  # Disable video stream
        "-acodec", "pcm_s16le", # 16-bit uncompressed PCM
        "-ar", "16000",         # 16kHz speech recognition standard
        "-ac", "1",             # Mono audio
        output_audio_path
    ]

    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60,
            check=True
        )
    except subprocess.TimeoutExpired:
        raise AudioExtractionError("Audio extraction timed out.")
    except subprocess.CalledProcessError as e:
        raise AudioExtractionError(f"ffmpeg audio extraction failed: {e.stderr}")
    except Exception as e:
        raise AudioExtractionError(f"Unexpected error running ffmpeg: {str(e)}")
