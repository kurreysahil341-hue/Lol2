import os
import re
import uuid
from typing import Optional
from backend.app.config import settings

def generate_job_id() -> str:
    """Generates an alphanumeric cryptographically random unique job ID."""
    return f"job_{uuid.uuid4().hex[:16]}"

def sanitize_extension(filename: str) -> str:
    """Extracts and sanitizes the file extension."""
    parts = filename.rsplit(".", 1)
    if len(parts) > 1:
        ext = re.sub(r"[^a-zA-Z0-9]", "", parts[1]).lower()
        return ext
    return ""

def is_allowed_extension(filename: str) -> bool:
    """Checks whether the file has an allowed video extension."""
    ext = sanitize_extension(filename)
    return ext in settings.ALLOWED_EXTENSIONS

def get_job_video_path(job_id: str, ext: str) -> str:
    """Safe absolute path for the uploaded video based on job_id."""
    # Ensure job_id contains only alphanumeric characters and underscore to prevent traversal
    safe_job_id = re.sub(r"[^a-zA-Z0-9_]", "", job_id)
    safe_ext = re.sub(r"[^a-zA-Z0-9]", "", ext)
    filename = f"{safe_job_id}_input.{safe_ext}"
    return os.path.join(settings.TEMP_DIR, filename)

def get_job_audio_path(job_id: str) -> str:
    """Safe absolute path for the extracted audio based on job_id."""
    safe_job_id = re.sub(r"[^a-zA-Z0-9_]", "", job_id)
    return os.path.join(settings.TEMP_DIR, f"{safe_job_id}_audio.wav")

def find_uploaded_video_by_job_id(job_id: str) -> Optional[str]:
    """Finds an existing uploaded video for a job ID."""
    safe_job_id = re.sub(r"[^a-zA-Z0-9_]", "", job_id)
    for ext in settings.ALLOWED_EXTENSIONS:
        candidate = os.path.join(settings.TEMP_DIR, f"{safe_job_id}_input.{ext}")
        if os.path.exists(candidate):
            return candidate
    return None

def cleanup_job_files(job_id: str) -> None:
    """Safely cleans up temporary files associated with a job ID."""
    safe_job_id = re.sub(r"[^a-zA-Z0-9_]", "", job_id)
    for f in os.listdir(settings.TEMP_DIR):
        if f.startswith(safe_job_id):
            full_path = os.path.join(settings.TEMP_DIR, f)
            try:
                if os.path.isfile(full_path):
                    os.remove(full_path)
            except Exception:
                pass
