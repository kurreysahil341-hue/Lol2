import os
from typing import List

class Settings:
    SERVICE_NAME: str = "AI Video Dubbing Backend"
    PHASE: int = 1
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))
    
    # 10 Minutes Maximum Duration (600 seconds)
    MAX_VIDEO_DURATION_SECONDS: float = float(os.getenv("MAX_VIDEO_DURATION_SECONDS", "600"))
    
    # Max file upload size: 500 MB
    MAX_UPLOAD_SIZE_MB: int = int(os.getenv("MAX_UPLOAD_SIZE_MB", "500"))
    MAX_UPLOAD_SIZE_BYTES: int = MAX_UPLOAD_SIZE_MB * 1024 * 1024
    
    # Directories
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    TEMP_DIR: str = os.path.join(BASE_DIR, "temp")
    OUTPUT_DIR: str = os.path.join(BASE_DIR, "outputs")
    
    # Supported Formats
    ALLOWED_EXTENSIONS: set = {"mp4", "mov", "webm"}
    
    # CORS
    ALLOWED_ORIGINS: List[str] = [
        origin.strip()
        for origin in os.getenv(
            "ALLOWED_ORIGINS",
            "http://localhost:3000,http://127.0.0.1:3000,http://localhost:8080,http://10.0.2.2:3000"
        ).split(",")
        if origin.strip()
    ]

settings = Settings()

os.makedirs(settings.TEMP_DIR, exist_ok=True)
os.makedirs(settings.OUTPUT_DIR, exist_ok=True)
