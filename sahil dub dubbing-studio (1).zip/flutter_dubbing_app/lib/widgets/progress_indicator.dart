import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/transcript_model.dart';
import 'processing_step_card.dart';

class UnifiedPipelineProgress extends StatelessWidget {
  final List<PipelineStepModel> steps;
  final String currentMessage;
  final bool isProcessing;
  final String? errorMessage;
  final int currentSegment;
  final int totalSegments;

  const UnifiedPipelineProgress({
    super.key,
    required this.steps,
    required this.currentMessage,
    required this.isProcessing,
    this.errorMessage,
    this.currentSegment = 0,
    this.totalSegments = 0,
  });

  int get overallProgressPercentage {
    if (steps.isEmpty) return 0;
    int total = 0;
    for (var step in steps) {
      total += step.progress;
    }
    return (total / steps.length).round();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0D101E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with overall percentage
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'डबिंग प्रगति (9-चरण प्रोसेसिंग पाइपलाइन)',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'English Video → Speech → Transcript → Translation → Voice → Sync → Mixing → Video → Gallery',
                    style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.4)),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Colors.indigoAccent, Colors.purpleAccent]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$overallProgressPercentage%',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Overall Progress Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: overallProgressPercentage / 100.0,
              backgroundColor: Colors.white.withOpacity(0.05),
              color: Colors.indigoAccent,
              minHeight: 6,
            ),
          ),

          if (isProcessing && currentMessage.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.indigoAccent),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    currentMessage,
                    style: const TextStyle(fontSize: 12, color: Colors.indigoAccent, fontWeight: FontWeight.w600),
                  ),
                ),
                if (totalSegments > 0)
                  Text(
                    'संवाद $currentSegment / $totalSegments',
                    style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.5), fontFamily: 'monospace'),
                  ),
              ],
            ),
          ],

          if (errorMessage != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(LucideIcons.alertCircle, color: Colors.redAccent, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      errorMessage!,
                      style: const TextStyle(fontSize: 12, color: Colors.redAccent, fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 14),

          // 9 Step Cards Grid
          ...steps.map((step) => Padding(
                padding: const EdgeInsets.only(bottom: 6.0),
                child: ProcessingStepCard(step: step),
              )),
        ],
      ),
    );
  }
}
