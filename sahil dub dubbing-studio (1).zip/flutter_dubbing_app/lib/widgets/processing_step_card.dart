import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/transcript_model.dart';

class ProcessingStepCard extends StatelessWidget {
  final PipelineStepModel step;

  const ProcessingStepCard({
    super.key,
    required this.step,
  });

  IconData _getIcon(String id) {
    switch (id) {
      case 'video':
        return LucideIcons.fileVideo;
      case 'audio_extract':
        return LucideIcons.headphones;
      case 'speech_recognition':
        return LucideIcons.fileText;
      case 'translation':
        return LucideIcons.languages;
      case 'tts_synthesis':
        return LucideIcons.mic;
      case 'sync_audio':
        return LucideIcons.gitMerge;
      case 'audio_mixing':
        return LucideIcons.sliders;
      case 'video_rendering':
        return LucideIcons.film;
      case 'gallery_save':
        return LucideIcons.downloadCloud;
      default:
        return LucideIcons.checkCircle;
    }
  }

  @override
  Widget build(BuildContext context) {
    Color badgeColor = Colors.white24;
    String badgeText = 'प्रतीक्षारत';

    if (step.status == StepStateStatus.completed) {
      badgeColor = Colors.greenAccent;
      badgeText = 'संपन्न';
    } else if (step.status == StepStateStatus.inProgress) {
      badgeColor = Colors.indigoAccent;
      badgeText = '${step.progress}%';
    } else if (step.status == StepStateStatus.error) {
      badgeColor = Colors.redAccent;
      badgeText = 'त्रुटि';
    }

    final isCurrent = step.status == StepStateStatus.inProgress;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: isCurrent
            ? Colors.indigoAccent.withOpacity(0.08)
            : Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isCurrent
              ? Colors.indigoAccent.withOpacity(0.3)
              : Colors.white.withOpacity(0.04),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: isCurrent
                  ? Colors.indigoAccent.withOpacity(0.2)
                  : Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              _getIcon(step.id),
              size: 16,
              color: step.status == StepStateStatus.completed
                  ? Colors.greenAccent
                  : isCurrent
                      ? Colors.indigoAccent
                      : Colors.white38,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  step.hindiTitle,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: isCurrent ? Colors.white : Colors.white70,
                  ),
                ),
                Text(
                  step.subtitle,
                  style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.4)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: badgeColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: badgeColor.withOpacity(0.3)),
            ),
            child: Text(
              badgeText,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: badgeColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
