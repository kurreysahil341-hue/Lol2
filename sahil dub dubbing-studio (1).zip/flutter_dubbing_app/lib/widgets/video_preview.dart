import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:video_player/video_player.dart';
import '../models/video_file.dart';

class VideoPreviewWidget extends StatelessWidget {
  final VideoFile? videoFile;
  final VideoPlayerController? controller;
  final VoidCallback onPickVideo;
  final VoidCallback onStartDubbing;
  final bool isProcessing;

  const VideoPreviewWidget({
    super.key,
    required this.videoFile,
    required this.controller,
    required this.onPickVideo,
    required this.onStartDubbing,
    this.isProcessing = false,
  });

  @override
  Widget build(BuildContext context) {
    if (videoFile == null) {
      return Container(
        height: 340,
        decoration: BoxDecoration(
          color: const Color(0xFF0B0D18),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.indigoAccent.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(LucideIcons.uploadCloud, size: 44, color: Colors.indigoAccent),
              ),
              const SizedBox(height: 16),
              const Text(
                'अपनी 10 मिनट तक की वीडियो चुनें',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 6),
              Text(
                'फ़ोन स्क्रीन रिकॉर्डिंग या डाउनलोड की गई MP4, WebM, MOV वीडियो',
                style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.5)),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: onPickVideo,
                icon: const Icon(LucideIcons.fileVideo, size: 18),
                label: const Text('वीडियो चुनें'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigoAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: [
        // Video Player Box
        Container(
          height: 360,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: controller != null && controller!.value.isInitialized
                ? Stack(
                    alignment: Alignment.center,
                    children: [
                      AspectRatio(
                        aspectRatio: controller!.value.aspectRatio,
                        child: VideoPlayer(controller!),
                      ),
                      Positioned(
                        bottom: 12,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            controller!.value.isPlaying ? controller!.pause() : controller!.play();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black87,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          ),
                          icon: Icon(
                            controller!.value.isPlaying ? LucideIcons.pause : LucideIcons.play,
                            color: Colors.white,
                            size: 16,
                          ),
                          label: Text(
                            controller!.value.isPlaying ? 'रोकें' : 'चलाएं',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  )
                : const Center(child: CircularProgressIndicator(color: Colors.indigoAccent)),
          ),
        ),

        const SizedBox(height: 12),

        // Video Info Card (Section 4)
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0D101E),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _infoCol('फ़ाइल नाम', videoFile!.name),
              _infoCol('अवधि', '${videoFile!.durationFormatted} / 10:00'),
              _infoCol('फ़ाइल साइज़', videoFile!.fileSizeFormatted),
              _infoCol('प्रारूप', videoFile!.format.toUpperCase()),
            ],
          ),
        ),

        const SizedBox(height: 12),

        // Change Video & Start Dubbing Buttons
        Row(
          children: [
            Expanded(
              flex: 2,
              child: SizedBox(
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: isProcessing ? null : onPickVideo,
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.white.withOpacity(0.2)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(LucideIcons.refreshCw, size: 16, color: Colors.white70),
                  label: const Text('वीडियो बदलें', style: TextStyle(color: Colors.white, fontSize: 13)),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 3,
              child: SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: isProcessing ? null : onStartDubbing,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.indigoAccent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(LucideIcons.sparkles, size: 18),
                  label: const Text(
                    'डबिंग शुरू करें',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _infoCol(String title, String val) {
    return Column(
      children: [
        Text(title, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.5))),
        const SizedBox(height: 3),
        Text(val, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
      ],
    );
  }
}
