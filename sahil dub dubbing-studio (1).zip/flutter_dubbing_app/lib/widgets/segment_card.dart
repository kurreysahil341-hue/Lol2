import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/dub_segment.dart';

class SegmentCardWidget extends StatelessWidget {
  final DubSegment segment;
  final VoidCallback? onPlay;
  final bool isPlaying;

  const SegmentCardWidget({
    super.key,
    required this.segment,
    this.onPlay,
    this.isPlaying = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isPlaying ? Colors.indigoAccent.withOpacity(0.12) : Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isPlaying ? Colors.indigoAccent.withOpacity(0.5) : Colors.white.withOpacity(0.05),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.indigoAccent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  segment.timecodeString,
                  style: const TextStyle(
                    color: Colors.indigoAccent,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
              if (onPlay != null)
                IconButton(
                  onPressed: onPlay,
                  icon: Icon(isPlaying ? LucideIcons.square : LucideIcons.volume2, size: 16),
                  color: Colors.white70,
                  visualDensity: VisualDensity.compact,
                ),
            ],
          ),
          const SizedBox(height: 6),
          if (segment.englishText.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 4.0),
              child: Text(
                'EN: ${segment.englishText}',
                style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.5), fontStyle: FontStyle.italic),
              ),
            ),
          Text(
            'HI: ${segment.hindiText}',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
