import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/hindi_audio_segment.dart';

class AudioSegmentCard extends StatelessWidget {
  final HindiAudioSegment segment;
  final bool isPlaying;
  final VoidCallback onPlayToggle;
  final VoidCallback? onSeekVideo;

  const AudioSegmentCard({
    super.key,
    required this.segment,
    required this.isPlaying,
    required this.onPlayToggle,
    this.onSeekVideo,
  });

  @override
  Widget build(BuildContext context) {
    final origDur = segment.originalDuration.toStringAsFixed(1);
    final genDur = segment.generatedDuration.toStringAsFixed(1);
    final diff = segment.durationDifference;
    final diffSign = diff > 0 ? '+${diff.toStringAsFixed(1)}s' : '${diff.toStringAsFixed(1)}s';

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isPlaying ? Colors.indigoAccent.withOpacity(0.12) : Colors.white.withOpacity(0.025),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isPlaying ? Colors.indigoAccent.withOpacity(0.6) : Colors.white.withOpacity(0.06),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row 1: Time, duration comparison, and Play button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Timecode & ID
              Row(
                children: [
                  Text(
                    'समय: ',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: Colors.white.withOpacity(0.5),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.indigoAccent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: Colors.indigoAccent.withOpacity(0.3)),
                    ),
                    child: Text(
                      segment.timecodeString,
                      style: const TextStyle(
                        color: Colors.indigoAccent,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Duration Comparison Badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.purple.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      'मूल: ${origDur}s | आवाज़: ${genDur}s ($diffSign)',
                      style: const TextStyle(
                        color: Colors.purpleAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),

              // Button: "आवाज़ सुनें"
              ElevatedButton.icon(
                onPressed: onPlayToggle,
                icon: Icon(
                  isPlaying ? LucideIcons.square : LucideIcons.volume2,
                  size: 14,
                  color: Colors.white,
                ),
                label: Text(
                  isPlaying ? 'रोकें' : 'आवाज़ सुनें',
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: isPlaying ? Colors.redAccent.shade700 : Colors.indigoAccent,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          // English reference text
          if (segment.englishText.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: Text(
                'English: ${segment.englishText}',
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.white.withOpacity(0.5),
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),

          // Hindi text
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 2, right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text('HI', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.purpleAccent)),
              ),
              Expanded(
                child: Text(
                  segment.hindiText,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
