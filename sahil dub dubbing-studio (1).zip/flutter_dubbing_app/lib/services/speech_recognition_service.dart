import 'dart:typed_data';
import '../models/transcript_model.dart';
import 'dubbing_service.dart';

/// Clean interface for Speech Recognition (English STT)
abstract class SpeechRecognitionService {
  Future<StructuredTranscript> transcribeAudio({
    required Uint8List audioBytes,
    required double durationSeconds,
    required String videoName,
    String? jobId,
    Function(int percent, String message)? onProgress,
  });
}

/// Backend-connected implementation of Speech Recognition
class BackendSpeechRecognitionService implements SpeechRecognitionService {
  final String apiBaseUrl;

  BackendSpeechRecognitionService({this.apiBaseUrl = 'http://localhost:3000'});

  @override
  Future<StructuredTranscript> transcribeAudio({
    required Uint8List audioBytes,
    required double durationSeconds,
    required String videoName,
    String? jobId,
    Function(int percent, String message)? onProgress,
  }) async {
    onProgress?.call(25, 'अंग्रेज़ी Speech पहचानना...');
    final result = await DubbingService.transcribeAudio(
      audioBytes: audioBytes,
      durationSeconds: durationSeconds,
      videoName: videoName,
      jobId: jobId,
      apiBaseUrl: apiBaseUrl,
    );
    final count = result.segments.length;
    onProgress?.call(100, 'अंग्रेज़ी Transcript तैयार ($count अंग्रेज़ी speech segments मिले)');
    return result;
  }
}
