import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/dub_segment.dart';
import '../models/hindi_audio_segment.dart';

class TtsService {
  /// Calls the secure backend TTS endpoint to synthesize natural Hindi voice
  /// for timestamped Hindi segments without exposing secret keys in Flutter code.
  static Future<HindiTtsResult> generateHindiSpeech({
    required List<DubSegment> segments,
    VoiceSettings voiceSettings = const VoiceSettings(),
    String apiBaseUrl = 'http://localhost:3000',
    Function(int percent, String message)? onProgress,
  }) async {
    if (segments.isEmpty) {
      throw Exception('हिंदी आवाज़ बनाने के लिए कोई संवाद उपलब्ध नहीं है।');
    }

    onProgress?.call(10, 'हिंदी आवाज़ तैयार की जा रही है... 10%');

    final payload = {
      'voiceSettings': voiceSettings.toJson(),
      'provider': 'google-hindi',
      'segments': segments.map((s) => {
        'id': s.id,
        'startTime': s.startTime,
        'endTime': s.endTime,
        'englishText': s.englishText,
        'hindiText': s.hindiText,
      }).toList(),
    };

    onProgress?.call(35, 'हिंदी आवाज़ तैयार की जा रही है... 35%');

    try {
      final response = await http
          .post(
            Uri.parse('$apiBaseUrl/api/tts'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 60));

      onProgress?.call(75, 'हिंदी आवाज़ तैयार की जा रही है... 75%');

      final data = jsonDecode(utf8.decode(response.bodyBytes));

      if (response.statusCode == 200 && data['success'] == true) {
        if (data['result'] == null) {
          throw Exception('सर्वर से अमान्य आवाज़ डेटा प्राप्त हुआ।');
        }

        onProgress?.call(100, 'हिंदी आवाज़ तैयार है');
        return HindiTtsResult.fromJson(data['result']);
      } else if (response.statusCode == 429) {
        throw Exception('सर्वर व्यस्त है (दर सीमा)। कृपया कुछ क्षण बाद पुनः प्रयास करें।');
      } else {
        final errorMsg = data['error'] ?? 'हिंदी आवाज़ बनाने में समस्या हुई। कृपया दोबारा प्रयास करें।';
        throw Exception(errorMsg);
      }
    } on SocketException {
      throw Exception('नेटवर्क या सर्वर से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।');
    } on TimeoutException {
      throw Exception('सर्वर प्रतिक्रिया में अधिक समय लगा (टाइमआउट)। कृपया दोबारा प्रयास करें।');
    } on FormatException {
      throw Exception('सर्वर से अमान्य प्रतिक्रिया प्राप्त हुई।');
    } catch (e) {
      if (e.toString().contains('Exception:')) {
        rethrow;
      }
      throw Exception('हिंदी आवाज़ सेवा त्रुटि: $e');
    }
  }
}
