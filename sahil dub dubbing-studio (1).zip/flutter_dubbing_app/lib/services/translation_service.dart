import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/dub_segment.dart';
import '../models/transcript_model.dart';

class TranslationService {
  /// Translates real English speech segments into natural spoken Hindi
  /// using protected backend AI API endpoints (safe from exposing client API keys).
  static Future<DubbedTranscript> translateToHindi({
    required List<TranscriptSegment> englishSegments,
    required double duration,
    required String videoName,
    String? jobId,
    String apiBaseUrl = 'http://localhost:3000',
    Function(int percent, String message)? onProgress,
  }) async {
    // 1. Validate empty transcript
    if (englishSegments.isEmpty) {
      throw Exception('अनुवाद के लिए कोई ट्रांसक्रिप्ट उपलब्ध नहीं है।');
    }

    onProgress?.call(25, 'हिंदी में अनुवाद किया जा रहा है... 25%');

    try {
      http.Response response;

      if (jobId != null && jobId.isNotEmpty) {
        response = await http
            .post(
              Uri.parse('$apiBaseUrl/api/video/$jobId/translate'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'duration': duration,
                'videoName': videoName,
              }),
            )
            .timeout(const Duration(seconds: 45));
      } else {
        final payload = {
          'duration': duration,
          'videoName': videoName,
          'segments': englishSegments.map((s) => {
            'id': s.id,
            'startTime': s.startTime,
            'endTime': s.endTime,
            'englishText': s.text,
          }).toList(),
        };

        response = await http
            .post(
              Uri.parse('$apiBaseUrl/api/translate'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode(payload),
            )
            .timeout(const Duration(seconds: 45));
      }

      final data = jsonDecode(utf8.decode(response.bodyBytes));

      if (response.statusCode == 200 && data['success'] == true) {
        onProgress?.call(100, 'हिंदी अनुवाद तैयार');
        return DubbedTranscript.fromJson(data);
      } else if (response.statusCode == 429) {
        throw Exception('सर्वर पर अधिक अनुरोध आ रहे हैं (दर सीमा)। कृपया कुछ क्षण बाद पुनः प्रयास करें।');
      } else {
        final errorMsg = data['error'] ?? 'हिंदी अनुवाद करने में समस्या हुई। कृपया दोबारा प्रयास करें।';
        throw Exception(errorMsg);
      }
    } on SocketException {
      throw Exception('नेटवर्क या सर्वर से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।');
    } on TimeoutException {
      throw Exception('सर्वर प्रतिक्रिया में अधिक समय लगा (टाइमआउट)। कृपया दोबारा प्रयास करें।');
    } on FormatException {
      throw Exception('सर्वर से अमान्य प्रतिक्रिया प्राप्त हुई।');
    } catch (e) {
      if (e.toString().contains('Exception:')) {
        rethrow;
      }
      throw Exception('हिंदी अनुवाद सेवा त्रुटि: $e');
    }
  }
}
