import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/hindi_audio_segment.dart';
import '../models/synced_audio_segment.dart';

class AudioSyncService {
  /// Synchronizes generated Hindi audio segments with original speech timeline
  /// via protected backend audio-processing service using pitch-preserving time-stretching.
  static Future<SyncResult> synchronizeSpeech({
    required List<HindiAudioSegment> segments,
    String apiBaseUrl = 'http://localhost:3000',
    Function(int percent, String message)? onProgress,
  }) async {
    if (segments.isEmpty) {
      throw Exception('सिंक्रोनाइज़ेशन के लिए कोई ऑडियो सेगमेंट उपलब्ध नहीं है।');
    }

    onProgress?.call(15, 'Hindi आवाज़ Sync की जा रही है... 15%');

    final payload = {
      'segments': segments.map((s) => {
        'id': s.id,
        'startTime': s.startTime,
        'endTime': s.endTime,
        'englishText': s.englishText,
        'hindiText': s.hindiText,
        'audioPath': s.audioPath,
        'audioBase64': s.audioBase64,
        'generatedDuration': s.generatedDuration,
        'originalDuration': s.originalDuration,
      }).toList(),
    };

    onProgress?.call(45, 'Hindi आवाज़ Sync की जा रही है... 45%');

    try {
      final response = await http
          .post(
            Uri.parse('$apiBaseUrl/api/sync'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 60));

      onProgress?.call(85, 'Hindi आवाज़ Sync की जा रही है... 85%');

      final data = jsonDecode(utf8.decode(response.bodyBytes));

      if (response.statusCode == 200 && data['success'] == true) {
        if (data['result'] == null) {
          throw Exception('सर्वर से अमान्य सिंक्रोनाइज़ेशन डेटा प्राप्त हुआ।');
        }

        onProgress?.call(100, 'Hindi आवाज़ Sync हो गई');
        return SyncResult.fromJson(data['result']);
      } else if (response.statusCode == 429) {
        throw Exception('सर्वर व्यस्त है (दर सीमा)। कृपया कुछ क्षण बाद पुनः प्रयास करें।');
      } else {
        final errorMsg = data['error'] ?? 'हिंदी आवाज़ सिंक्रोनाइज़ करने में समस्या हुई। कृपया दोबारा प्रयास करें।';
        throw Exception(errorMsg);
      }
    } on SocketException {
      throw Exception('नेटवर्क या सर्वर से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।');
    } on TimeoutException {
      throw Exception('ऑडियो प्रोसेसिंग में अधिक समय लगा (टाइमआउट)। कृपया दोबारा प्रयास करें।');
    } on FormatException {
      throw Exception('सर्वर से अमान्य प्रतिक्रिया प्राप्त हुई।');
    } catch (e) {
      if (e.toString().contains('Exception:')) {
        rethrow;
      }
      throw Exception('ऑडियो सिंक सेवा त्रुटि: $e');
    }
  }
}
