import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models/transcript_model.dart';
import '../models/video_file.dart';

class DubbingService {
  static const int maxVideoDurationSeconds = 600; // 10 minutes maximum

  /// Validate video duration (under 10 minutes)
  static String? validateDuration(Duration duration) {
    if (duration.inSeconds > maxVideoDurationSeconds) {
      return 'अभी अधिकतम 10 मिनट की वीडियो ही समर्थित है।';
    }
    return null;
  }

  /// Uploads local video file to backend /api/video/upload and retrieves jobId
  static Future<Map<String, dynamic>> uploadVideo({
    required VideoFile videoFile,
    String apiBaseUrl = 'http://localhost:3000',
    Function(int percent, String message)? onProgress,
  }) async {
    try {
      onProgress?.call(10, 'वीडियो अपलोड शुरू किया जा रहा है...');
      final uri = Uri.parse('$apiBaseUrl/api/video/upload');
      final request = http.MultipartRequest('POST', uri);

      if (videoFile.bytes != null && videoFile.bytes!.isNotEmpty) {
        request.files.add(
          http.MultipartFile.fromBytes(
            'video',
            videoFile.bytes!,
            filename: videoFile.name,
          ),
        );
      } else if (videoFile.path.isNotEmpty) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'video',
            videoFile.path,
            filename: videoFile.name,
          ),
        );
      } else {
        throw Exception('वीडियो फ़ाइल डेटा उपलब्ध नहीं है।');
      }

      onProgress?.call(40, 'सर्वर पर वीडियो भेजा जा रहा है...');
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      if (response.statusCode == 200 && data['success'] == true) {
        onProgress?.call(100, 'वीडियो सफलतापूर्वक अपलोड हुआ');
        return data as Map<String, dynamic>;
      } else {
        throw Exception(data['error'] ?? 'वीडियो अपलोड विफल रहा।');
      }
    } catch (e) {
      throw Exception('वीडियो अपलोड करने में समस्या: $e');
    }
  }

  /// Calls backend to extract 16kHz WAV audio from uploaded video
  static Future<Map<String, dynamic>> extractAudio({
    required String jobId,
    String apiBaseUrl = 'http://localhost:3000',
    Function(int percent, String message)? onProgress,
  }) async {
    try {
      onProgress?.call(25, 'ऑडियो निष्कर्षण किया जा रहा है...');
      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/video/$jobId/extract-audio'),
        headers: {'Content-Type': 'application/json'},
      );

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      if (response.statusCode == 200 && data['success'] == true) {
        onProgress?.call(100, 'ऑडियो सफलतापूर्वक निकाला गया');
        return data as Map<String, dynamic>;
      } else {
        throw Exception(data['error'] ?? 'ऑडियो निष्कर्षण विफल रहा।');
      }
    } catch (e) {
      throw Exception('ऑडियो निष्कर्षण में त्रुटि: $e');
    }
  }

  /// Sends extracted audio or jobId to Speech-to-Text backend API
  static Future<StructuredTranscript> transcribeAudio({
    required Uint8List audioBytes,
    required double durationSeconds,
    required String videoName,
    String? jobId,
    String apiBaseUrl = 'http://localhost:3000',
  }) async {
    try {
      http.Response response;

      if (jobId != null && jobId.isNotEmpty) {
        response = await http.post(
          Uri.parse('$apiBaseUrl/api/video/$jobId/transcribe'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'durationSeconds': durationSeconds,
            'videoName': videoName,
          }),
        );
      } else {
        final base64Audio = base64Encode(audioBytes);
        response = await http.post(
          Uri.parse('$apiBaseUrl/api/transcribe'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'audioBase64': base64Audio,
            'mimeType': 'audio/wav',
            'durationSeconds': durationSeconds,
            'videoName': videoName,
          }),
        );
      }

      final data = jsonDecode(utf8.decode(response.bodyBytes));

      if (response.statusCode == 200 && data['success'] == true) {
        return StructuredTranscript.fromJson(data);
      } else {
        throw Exception(data['error'] ?? 'English आवाज़ को पहचानने में समस्या हुई। कृपया दोबारा प्रयास करें।');
      }
    } catch (e) {
      if (e.toString().contains('अधिकतम 10 मिनट')) {
        rethrow;
      }
      throw Exception('English आवाज़ को पहचानने में समस्या हुई। कृपया दोबारा प्रयास करें। ($e)');
    }
  }
}
