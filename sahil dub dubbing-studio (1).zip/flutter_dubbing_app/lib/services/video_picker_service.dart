import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:file_picker/file_picker.dart';
import 'package:video_player/video_player.dart';
import '../models/video_file.dart';

class VideoPickerValidationException implements Exception {
  final String message;
  VideoPickerValidationException(this.message);

  @override
  String toString() => message;
}

/// Service for picking and validating local videos from phone storage / gallery
class VideoPickerService {
  static const int maxVideoDurationSeconds = 600; // 10 minutes max

  /// Picks a video file from local Android storage or gallery
  static Future<VideoFile?> pickVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: false,
      withData: kIsWeb,
    );

    if (result == null || result.files.isEmpty) {
      return null;
    }

    final platformFile = result.files.first;
    return await validateAndLoadVideo(platformFile);
  }

  /// Validates format, readability, and the strict 10-minute maximum duration constraint
  static Future<VideoFile> validateAndLoadVideo(PlatformFile file) async {
    final extension = (file.extension ?? '').toLowerCase();
    final allowedFormats = ['mp4', 'mov', 'webm', 'mkv'];

    if (extension.isNotEmpty && !allowedFormats.contains(extension)) {
      throw VideoPickerValidationException(
        'असमर्थित वीडियो प्रारूप। केवल MP4, MOV या WebM वीडियो समर्थित हैं।',
      );
    }

    VideoPlayerController controller;
    if (kIsWeb) {
      if (file.bytes != null) {
        controller = VideoPlayerController.networkUrl(Uri.parse(file.path ?? ''));
      } else {
        throw VideoPickerValidationException('वीडियो फ़ाइल डेटा पढ़ने में असमर्थ।');
      }
    } else {
      if (file.path == null) {
        throw VideoPickerValidationException('फ़ाइल पथ अमान्य है।');
      }
      controller = VideoPlayerController.file(File(file.path!));
    }

    try {
      await controller.initialize();
      final duration = controller.value.duration;

      // 10-minute constraint validation
      if (duration.inSeconds > maxVideoDurationSeconds) {
        throw VideoPickerValidationException(
          'वीडियो की अधिकतम अवधि 10 मिनट है। (चयनित: ${duration.inMinutes}:${(duration.inSeconds % 60).toString().padLeft(2, '0')})',
        );
      }

      if (duration.inSeconds <= 0) {
        throw VideoPickerValidationException('वीडियो की अवधि शून्य है या फ़ाइल दूषित है।');
      }

      return VideoFile(
        name: file.name,
        path: file.path ?? '',
        bytes: file.bytes,
        duration: duration,
        fileSizeBytes: file.size,
        format: extension.isEmpty ? 'mp4' : extension,
      );
    } catch (e) {
      if (e is VideoPickerValidationException) rethrow;
      throw VideoPickerValidationException('वीडियो लोड या सत्यापित करने में समस्या: $e');
    } finally {
      controller.dispose();
    }
  }
}
