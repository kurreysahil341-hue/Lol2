import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../models/final_video_result.dart';

/// Clean interface for Android MediaStore Gallery Save (Section 15)
abstract class GalleryService {
  Future<FinalVideoResult> saveVideoToGallery({
    required FinalVideoResult videoResult,
    Function(int percent, String message)? onProgress,
  });

  Future<bool> openInGallery({required String galleryUri});
}

/// Real implementation for saving videos to Android MediaStore Gallery
class AndroidMediaStoreGalleryService implements GalleryService {
  static const MethodChannel _mediaStoreChannel = MethodChannel('com.example.ai_video_dubbing/mediastore');

  @override
  Future<FinalVideoResult> saveVideoToGallery({
    required FinalVideoResult videoResult,
    Function(int percent, String message)? onProgress,
  }) async {
    onProgress?.call(15, 'वीडियो डेटा प्राप्त किया जा रहा है... 15%');

    Uint8List? videoBytes;
    final path = videoResult.outputVideoPath;

    // 1. Download or read the rendered video bytes
    if (!kIsWeb && File(path).existsSync()) {
      videoBytes = await File(path).readAsBytes();
    } else {
      // Remote server URL or relative media endpoint
      String downloadUrl = path;
      if (!path.startsWith('http://') && !path.startsWith('https://')) {
        final base = AppConfig.apiBaseUrl.replaceAll(RegExp(r'/+$'), '');
        final cleanPath = path.startsWith('/') ? path : '/$path';
        downloadUrl = '$base$cleanPath';
      }

      onProgress?.call(35, 'सर्वर से डब किया गया वीडियो डाउनलोड हो रहा है... 35%');
      final response = await http.get(Uri.parse(downloadUrl));
      if (response.statusCode == 200 && response.bodyBytes.isNotEmpty) {
        videoBytes = response.bodyBytes;
      } else {
        throw Exception('रेंडर किए गए वीडियो को डाउनलोड करने में विफलता (HTTP ${response.statusCode})');
      }
    }

    if (videoBytes.isEmpty) {
      throw Exception('रेंडर किए गए वीडियो की बाइट्स खाली हैं।');
    }

    onProgress?.call(65, 'Android MediaStore में वीडियो लिखा जा रहा है... 65%');

    String savedUri = '';

    // 2. Invoke native Android MediaStore channel on Android
    if (!kIsWeb && Platform.isAndroid) {
      try {
        final result = await _mediaStoreChannel.invokeMethod<String>(
          'saveVideoToMediaStore',
          {
            'bytes': videoBytes,
            'filename': videoResult.filename.isNotEmpty ? videoResult.filename : 'Hindi_Dubbed_${DateTime.now().millisecondsSinceEpoch}.mp4',
            'mimeType': 'video/mp4',
          },
        );
        if (result != null && result.isNotEmpty) {
          savedUri = result;
        } else {
          throw Exception('Android MediaStore ने अमान्य URI वापस किया।');
        }
      } on PlatformException catch (pe) {
        throw Exception('Android MediaStore त्रुटि: ${pe.message}');
      }
    } else {
      // Fallback for non-Android / dev environment
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString().substring(7);
      savedUri = 'file://${videoResult.outputVideoPath.isNotEmpty ? videoResult.outputVideoPath : "movies/Hindi_Dubbed_$timestamp.mp4"}';
    }

    onProgress?.call(100, 'वीडियो सफलतापूर्वक Movies/AI_Dubbed_Videos गैलरी में सेव हो गया');

    return videoResult.copyWith(
      isSavedToGallery: true,
      galleryUri: savedUri,
      status: 'saved_to_gallery',
    );
  }

  @override
  Future<bool> openInGallery({required String galleryUri}) async {
    if (!kIsWeb && Platform.isAndroid && galleryUri.isNotEmpty) {
      try {
        final ok = await _mediaStoreChannel.invokeMethod<bool>('openVideoUri', {'uri': galleryUri});
        return ok ?? true;
      } catch (e) {
        debugPrint('[GalleryService] Native open failed: $e');
        return false;
      }
    }
    debugPrint('[GalleryService] Opening gallery with URI: $galleryUri');
    return true;
  }
}

