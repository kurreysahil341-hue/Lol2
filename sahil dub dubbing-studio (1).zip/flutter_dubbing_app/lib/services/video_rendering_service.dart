import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/final_video_result.dart';
import '../models/video_file.dart';
import '../models/mixed_audio_segment.dart';

/// Clean interface for Video Rendering (Section 13)
abstract class VideoRenderingService {
  Future<FinalVideoResult> renderFinalVideo({
    required VideoFile originalVideo,
    required MixedAudioResult mixedAudio,
    String? jobId,
    Function(int percent, String message)? onProgress,
  });
}

/// Modular implementation of Video Rendering
/// Takes original video visuals + mixed Hindi audio track and produces the final MP4
class BackendVideoRenderingService implements VideoRenderingService {
  final String apiBaseUrl;

  BackendVideoRenderingService({this.apiBaseUrl = 'http://localhost:3000'});

  @override
  Future<FinalVideoResult> renderFinalVideo({
    required VideoFile originalVideo,
    required MixedAudioResult mixedAudio,
    String? jobId,
    Function(int percent, String message)? onProgress,
  }) async {
    onProgress?.call(20, 'वीडियो फ़्रेम और टाइमलाइन तैयार की जा रही है... 20%');

    final payload = {
      if (jobId != null && jobId.isNotEmpty) 'jobId': jobId,
      'videoName': originalVideo.name,
      'videoPath': originalVideo.path,
      'originalVideoPath': originalVideo.path,
      'duration': originalVideo.duration.inSeconds,
      'mixedAudioPath': mixedAudio.mixedAudioPath,
    };

    try {
      final response = await http
          .post(
            Uri.parse('$apiBaseUrl/api/render-video'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 90));

      onProgress?.call(75, 'अंतिम MP4 वीडियो एन्कोड किया जा रहा है... 75%');

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      if (response.statusCode == 200 && data['success'] == true && data['result'] != null) {
        onProgress?.call(100, 'फाइनल डब वीडियो तैयार है');
        return FinalVideoResult.fromJson(data['result']);
      } else {
        final errorMsg = data['error'] ?? 'वीडियो रेंडरिंग विफल रही। कृपया पुनः प्रयास करें।';
        throw Exception(errorMsg);
      }
    } on SocketException {
      throw Exception('सर्वर से जुड़ने में समस्या हुई। कृपया इंटरनेट कनेक्शन जांचें।');
    } on TimeoutException {
      throw Exception('वीडियो रेंडरिंग में अधिक समय लगा (टाइमआउट)। कृपया पुनः प्रयास करें।');
    } on FormatException {
      throw Exception('सर्वर से अमान्य प्रतिक्रिया प्राप्त हुई।');
    } catch (e) {
      if (e.toString().contains('Exception:')) {
        rethrow;
      }
      throw Exception('वीडियो रेंडरिंग सेवा त्रुटि: $e');
    }
  }
}
