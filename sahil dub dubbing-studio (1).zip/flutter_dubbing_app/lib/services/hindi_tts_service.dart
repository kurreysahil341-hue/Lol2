import '../models/dub_segment.dart';
import '../models/hindi_audio_segment.dart';
import 'tts_service.dart';

/// Clean Provider Interface for Hindi Text-to-Speech (Section 9)
abstract class HindiTtsProvider {
  Future<HindiTtsResult> synthesize({
    required List<DubSegment> segments,
    VoiceSettings voiceSettings,
    Function(int percent, String message)? onProgress,
  });
}

/// Backend-connected Hindi TTS Provider calling secure server proxy
class BackendHindiTtsProvider implements HindiTtsProvider {
  final String apiBaseUrl;

  BackendHindiTtsProvider({this.apiBaseUrl = 'http://localhost:3000'});

  @override
  Future<HindiTtsResult> synthesize({
    required List<DubSegment> segments,
    VoiceSettings voiceSettings = const VoiceSettings(),
    Function(int percent, String message)? onProgress,
  }) async {
    return await TtsService.generateHindiSpeech(
      segments: segments,
      voiceSettings: voiceSettings,
      apiBaseUrl: apiBaseUrl,
      onProgress: onProgress,
    );
  }
}
