import 'package:flutter/foundation.dart';

/// Centralized Application Configuration
class AppConfig {
  static String? _customUrl;

  static const String _envUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

  /// Base API URL for backend dubbing services.
  /// Defaults to empty for Web (same origin), 10.0.2.2 for Android Emulator,
  /// or whatever the user configures in-app at runtime.
  static String get apiBaseUrl {
    if (_customUrl != null && _customUrl!.trim().isNotEmpty) {
      return _customUrl!.trim().replaceAll(RegExp(r'/+$'), '');
    }
    if (_envUrl.isNotEmpty) {
      return _envUrl.trim().replaceAll(RegExp(r'/+$'), '');
    }
    if (kIsWeb) {
      return '';
    }
    return 'http://10.0.2.2:3000';
  }

  static set apiBaseUrl(String newUrl) {
    _customUrl = newUrl.trim().replaceAll(RegExp(r'/+$'), '');
  }

  static bool get hasCustomUrl => _customUrl != null && _customUrl!.isNotEmpty;
}
