import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:video_player/video_player.dart';
import '../models/mixed_audio_segment.dart';

class AudioMixingScreen extends StatefulWidget {
  final MixedAudioResult mixedResult;
  final Function(double seconds)? onSeekVideo;

  const AudioMixingScreen({
    super.key,
    required this.mixedResult,
    this.onSeekVideo,
  });

  @override
  State<AudioMixingScreen> createState() => _AudioMixingScreenState();
}

class _AudioMixingScreenState extends State<AudioMixingScreen> {
  int? _playingSegmentId;
  VideoPlayerController? _audioPlayer;

  @override
  void dispose() {
    _audioPlayer?.dispose();
    super.dispose();
  }

  Future<void> _playSegment(MixedAudioSegment segment) async {
    if (_playingSegmentId == segment.id) {
      await _audioPlayer?.pause();
      setState(() => _playingSegmentId = null);
      return;
    }

    _audioPlayer?.dispose();
    setState(() => _playingSegmentId = segment.id);

    try {
      final uri = Uri.parse(
        segment.hindiAudioPath.startsWith('http')
            ? segment.hindiAudioPath
            : 'http://localhost:3000${segment.hindiAudioPath}',
      );

      _audioPlayer = VideoPlayerController.networkUrl(uri);
      await _audioPlayer!.initialize();
      await _audioPlayer!.play();

      _audioPlayer!.addListener(() {
        if (_audioPlayer != null &&
            _audioPlayer!.value.position >= _audioPlayer!.value.duration) {
          if (mounted) setState(() => _playingSegmentId = null);
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() => _playingSegmentId = null);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ऑडियो चलाने में त्रुटि: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mix = widget.mixedResult;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0D101E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.cyanAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(LucideIcons.sliders, color: Colors.cyanAccent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'ऑडियो मिक्सिंग व डकिंग (Audio Mixing & Ducking)',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        'बैकग्राउंड म्यूज़िक व SFX सुरक्षित · हिंदी आवाज़ स्पष्ट',
                        style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.6)),
                      ),
                    ],
                  ),
                ],
              ),

              // Status Badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.greenAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent.withOpacity(0.3)),
                ),
                child: Row(
                  children: const [
                    Icon(LucideIcons.checkCircle2, color: Colors.greenAccent, size: 14),
                    SizedBox(width: 4),
                    Text(
                      'ऑडियो मिक्सिंग पूरी हुई',
                      style: TextStyle(color: Colors.greenAccent, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),
          const Divider(color: Colors.white12, height: 1),
          const SizedBox(height: 14),

          // Mixing Configuration Stats
          Row(
            children: [
              Expanded(
                child: _statBox(
                  title: 'मूल ऑडियो डकिंग',
                  value: '${(mix.originalDuckingLevel * 100).toInt()}% (संवाद पर)',
                  icon: LucideIcons.volume1,
                  color: Colors.cyanAccent,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _statBox(
                  title: 'हिंदी आवाज़ स्तर',
                  value: '${(mix.hindiVoiceLevel * 100).toInt()}% (स्पष्ट)',
                  icon: LucideIcons.mic,
                  color: Colors.purpleAccent,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _statBox(
                  title: 'बैकग्राउंड म्यूज़िक/SFX',
                  value: 'सुरक्षित (Smooth Fades)',
                  icon: LucideIcons.music,
                  color: Colors.greenAccent,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Ducking Info Banner
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.025),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: Row(
              children: [
                const Icon(LucideIcons.waves, size: 16, color: Colors.cyanAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'स्मूथ वॉल्यूम डकिंग (0.2s fade-in / 0.3s fade-out): जब हिंदी संवाद बोला जाता है, तो मूल अंग्रेजी आवाज़ 25% तक कम हो जाती है, जबकि बैकग्राउंड म्यूज़िक और इफ़ेक्ट्स स्वाभाविक रूप से सुनाई देते रहते हैं।',
                    style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.85), height: 1.4),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Segment List
          Text(
            'मिक्स किए गए संवाद व डकिंग टाइमलाइन (${mix.segments.length} संवाद):',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white.withOpacity(0.7)),
          ),
          const SizedBox(height: 8),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: mix.segments.length,
            itemBuilder: (context, index) {
              final segment = mix.segments[index];
              final isPlaying = _playingSegmentId == segment.id;

              return Container(
                margin: const EdgeInsets.symmetric(vertical: 4),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isPlaying ? Colors.cyanAccent.withOpacity(0.1) : Colors.white.withOpacity(0.02),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isPlaying ? Colors.cyanAccent.withOpacity(0.4) : Colors.white.withOpacity(0.05),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                segment.timecodeString,
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'monospace',
                                  color: Colors.cyanAccent,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                decoration: BoxDecoration(
                                  color: Colors.greenAccent.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: const Text(
                                  'Ducking Active (25%)',
                                  style: TextStyle(fontSize: 9, color: Colors.greenAccent, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            segment.hindiText,
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: () => _playSegment(segment),
                      icon: Icon(isPlaying ? LucideIcons.square : LucideIcons.volume2, size: 14),
                      label: Text(isPlaying ? 'रोकें' : 'सुनें'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isPlaying ? Colors.redAccent : Colors.cyanAccent.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _statBox({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.04)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 12, color: color),
              const SizedBox(width: 4),
              Text(title, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.5))),
            ],
          ),
          const SizedBox(height: 4),
          Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }
}
