import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:video_player/video_player.dart';
import '../models/synced_audio_segment.dart';
import '../widgets/sync_segment_card.dart';

class AudioSyncScreen extends StatefulWidget {
  final SyncResult syncResult;
  final Function(double seconds)? onSeekVideo;

  const AudioSyncScreen({
    super.key,
    required this.syncResult,
    this.onSeekVideo,
  });

  @override
  State<AudioSyncScreen> createState() => _AudioSyncScreenState();
}

class _AudioSyncScreenState extends State<AudioSyncScreen> {
  int? _playingSegmentId;
  VideoPlayerController? _audioPlayer;

  @override
  void dispose() {
    _audioPlayer?.dispose();
    super.dispose();
  }

  Future<void> _playSegmentAudio(SyncedAudioSegment segment) async {
    if (_playingSegmentId == segment.id) {
      await _audioPlayer?.pause();
      setState(() => _playingSegmentId = null);
      return;
    }

    _audioPlayer?.dispose();
    setState(() => _playingSegmentId = segment.id);

    try {
      final audioUri = segment.audioBase64 != null
          ? Uri.parse('data:audio/mp3;base64,${segment.audioBase64}')
          : Uri.parse('http://localhost:3000${segment.audioPath}');

      _audioPlayer = VideoPlayerController.networkUrl(audioUri);
      await _audioPlayer!.initialize();
      await _audioPlayer!.play();

      _audioPlayer!.addListener(() {
        if (_audioPlayer != null &&
            _audioPlayer!.value.position >= _audioPlayer!.value.duration) {
          if (mounted) setState(() => _playingSegmentId = null);
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() => _playingSegmentId = null);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ऑडियो चलाने में त्रुटि: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final sync = widget.syncResult;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0D101E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.purpleAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(LucideIcons.gitMerge, color: Colors.purpleAccent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Hindi आवाज़ Timing & Synchronization',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        'मूल स्पीच टाइमलाइन के साथ समयबद्ध मिलान (${sync.segments.length} संवाद)',
                        style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.6)),
                      ),
                    ],
                  ),
                ],
              ),

              // Status Badge: "Hindi आवाज़ Sync हो गई"
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.greenAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent.withOpacity(0.3)),
                ),
                child: Row(
                  children: const [
                    Icon(LucideIcons.checkCircle2, color: Colors.greenAccent, size: 14),
                    SizedBox(width: 4),
                    Text(
                      'Hindi आवाज़ Sync हो गई',
                      style: TextStyle(color: Colors.greenAccent, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),
          const Divider(color: Colors.white12, height: 1),
          const SizedBox(height: 14),

          // Overview Stats
          Row(
            children: [
              Expanded(
                child: _statBox(
                  title: 'लक्षित स्पीच समय',
                  value: '${sync.totalTargetDuration.toStringAsFixed(1)}s',
                  icon: LucideIcons.clock,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _statBox(
                  title: 'सिंक ऑडियो समय',
                  value: '${sync.totalAdjustedDuration.toStringAsFixed(1)}s',
                  icon: LucideIcons.check,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _statBox(
                  title: 'औसत गति परिवर्तन',
                  value: '${sync.averageSpeedAdjustment.toStringAsFixed(2)}x',
                  icon: LucideIcons.gauge,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Silence & Gap Preservation Banner (Requirement 6)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.025),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: Row(
              children: [
                const Icon(LucideIcons.volumeX, size: 16, color: Colors.indigoAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'संवादों के बीच का प्राकृतिक मौन (Silence / Gaps) सुरक्षित रखा गया है। प्रत्येक संवाद अपने मूल समय (startTime) पर ही शुरू होगा।',
                    style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.8)),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Scrollable list of SyncSegmentCard
          Text(
            'सिंक्रोनाइज़ किए गए हिंदी संवाद (Sync की गई आवाज़ सुनें):',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white.withOpacity(0.7)),
          ),
          const SizedBox(height: 8),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: sync.segments.length,
            itemBuilder: (context, index) {
              final segment = sync.segments[index];
              return SyncSegmentCard(
                segment: segment,
                isPlaying: _playingSegmentId == segment.id,
                onPlayToggle: () => _playSegmentAudio(segment),
                onSeekVideo: () => widget.onSeekVideo?.call(segment.startTime),
              );
            },
          ),

          const SizedBox(height: 16),

          // Next Step Notice (Prompt 6: Audio Mixing)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.indigoAccent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.indigoAccent.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(LucideIcons.sparkles, color: Colors.indigoAccent, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Prompt 6 में हम मूल वीडियो का background music और sound effects बचाते हुए इस Synchronized Hindi Voice को final audio track में mix करेंगे।',
                    style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.85)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statBox({required String title, required String value, required IconData icon}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.04)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 12, color: Colors.white.withOpacity(0.4)),
              const SizedBox(width: 4),
              Text(title, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.4))),
            ],
          ),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
        ],
      ),
    );
  }
}
