import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/dub_segment.dart';

class TranslationScreen extends StatefulWidget {
  final DubbedTranscript dubbedTranscript;
  final Function(double seconds)? onSeekToTime;

  const TranslationScreen({
    super.key,
    required this.dubbedTranscript,
    this.onSeekToTime,
  });

  @override
  State<TranslationScreen> createState() => _TranslationScreenState();
}

class _TranslationScreenState extends State<TranslationScreen> {
  int? _activeSegmentId;
  bool _copied = false;

  void _copyAllHindi() {
    final buffer = StringBuffer();
    for (var seg in widget.dubbedTranscript.segments) {
      buffer.writeln('[${seg.timecodeString}] ${seg.hindiText}');
    }
    Clipboard.setData(ClipboardData(text: buffer.toString()));
    setState(() => _copied = true);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('हिंदी अनुवाद क्लिपबोर्ड में कॉपी हो गया!'),
        duration: Duration(seconds: 2),
      ),
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final transcript = widget.dubbedTranscript;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0D101E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.purpleAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(LucideIcons.languages, color: Colors.purpleAccent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'English → Hindi Dubbing Script',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        'प्राकृतिक हिंदी अनुवाद (${transcript.segments.length} संवाद खंड)',
                        style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.6)),
                      ),
                    ],
                  ),
                ],
              ),
              IconButton(
                onPressed: _copyAllHindi,
                tooltip: 'हिंदी संवाद कॉपी करें',
                icon: Icon(
                  _copied ? LucideIcons.check : LucideIcons.copy,
                  color: _copied ? Colors.greenAccent : Colors.indigoAccent,
                  size: 18,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),
          const Divider(color: Colors.white12, height: 1),
          const SizedBox(height: 14),

          // Scrollable List of Dual-Language Segments
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: transcript.segments.length,
            separatorBuilder: (context, _) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final segment = transcript.segments[index];
              final isSelected = _activeSegmentId == segment.id;

              return InkWell(
                onTap: () {
                  setState(() => _activeSegmentId = segment.id);
                  widget.onSeekToTime?.call(segment.startTime);
                },
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? Colors.indigoAccent.withOpacity(0.12)
                        : Colors.white.withOpacity(0.025),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isSelected
                          ? Colors.indigoAccent.withOpacity(0.5)
                          : Colors.white.withOpacity(0.05),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // समय line
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text(
                                'समय: ',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white.withOpacity(0.5),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.indigoAccent.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(color: Colors.indigoAccent.withOpacity(0.3)),
                                ),
                                child: Text(
                                  segment.timecodeString,
                                  style: const TextStyle(
                                    color: Colors.indigoAccent,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'monospace',
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Text(
                            '#${segment.id}',
                            style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.3)),
                          ),
                        ],
                      ),

                      const SizedBox(height: 8),

                      // English Sentence
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(top: 2, right: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: Colors.blueGrey.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text('EN', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
                          ),
                          Expanded(
                            child: Text(
                              segment.englishText,
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.white.withOpacity(0.7),
                                height: 1.35,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 6),

                      // Hindi Dubbing Translation
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(top: 2, right: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: Colors.purple.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text('HI', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.purpleAccent)),
                          ),
                          Expanded(
                            child: Text(
                              segment.hindiText,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                                height: 1.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 14),

          // Next Step Notice (TTS Readiness)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.indigoAccent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.indigoAccent.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(LucideIcons.sparkles, color: Colors.indigoAccent, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'हिंदी अनुवाद तैयार है। अगले चरण 4 (Hindi Voice Synthesis / TTS) में इस पाठ से ऑडियो उत्पन्न किया जाएगा।',
                    style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.8)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
