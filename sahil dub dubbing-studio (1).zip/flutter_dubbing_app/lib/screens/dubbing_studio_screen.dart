import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:http/http.dart' as http;

import '../models/video_file.dart';
import '../models/transcript_model.dart';
import '../models/dub_segment.dart';
import '../models/hindi_audio_segment.dart';
import '../models/synced_audio_segment.dart';
import '../models/mixed_audio_segment.dart';
import '../models/final_video_result.dart';

import '../services/video_picker_service.dart';
import '../services/speech_recognition_service.dart';
import '../services/translation_service.dart';
import '../services/hindi_tts_service.dart';
import '../services/audio_sync_service.dart';
import '../services/audio_mixing_service.dart';
import '../services/video_rendering_service.dart';
import '../services/gallery_service.dart';
import '../services/dubbing_service.dart';
import '../config/app_config.dart';

import '../widgets/video_preview.dart';
import '../widgets/progress_indicator.dart';

import 'translation_screen.dart';
import 'hindi_voice_screen.dart';
import 'audio_sync_screen.dart';
import 'audio_mixing_screen.dart';
import 'final_video_screen.dart';

class DubbingStudioScreen extends StatefulWidget {
  const DubbingStudioScreen({super.key});

  @override
  State<DubbingStudioScreen> createState() => _DubbingStudioScreenState();
}

class _DubbingStudioScreenState extends State<DubbingStudioScreen> {
  VideoFile? _videoFile;
  VideoPlayerController? _videoController;
  bool _isProcessing = false;
  String? _errorMessage;
  String _currentProgressMessage = '';
  String? _currentJobId;

  // Pipeline step results
  StructuredTranscript? _englishTranscript;
  DubbedTranscript? _dubbedTranscript;
  HindiTtsResult? _hindiTtsResult;
  SyncResult? _syncResult;
  MixedAudioResult? _mixedAudioResult;
  FinalVideoResult? _finalVideoResult;

  // Active view tab
  int _activeViewIndex = 0; // 0: overview, 1: translation, 2: voice, 3: sync, 4: mix, 5: final

  // Services (modular interfaces)
  final SpeechRecognitionService _speechService = BackendSpeechRecognitionService(apiBaseUrl: AppConfig.apiBaseUrl);
  final HindiTtsProvider _ttsProvider = BackendHindiTtsProvider(apiBaseUrl: AppConfig.apiBaseUrl);
  final AudioMixingService _mixingService = BackendAudioMixingService(apiBaseUrl: AppConfig.apiBaseUrl);
  final VideoRenderingService _renderingService = BackendVideoRenderingService(apiBaseUrl: AppConfig.apiBaseUrl);
  final GalleryService _galleryService = AndroidMediaStoreGalleryService();

  // Complete 9-Stage Pipeline (Section 5)
  final List<PipelineStepModel> _pipelineSteps = [
    PipelineStepModel(id: 'video', hindiTitle: '1. वीडियो तैयार करना', subtitle: 'वीडियो लोड, प्रारूप व 10 मिनट सत्यापन'),
    PipelineStepModel(id: 'audio_extract', hindiTitle: '2. English Speech निकालना', subtitle: 'मूल वीडियो से ऑडियो ट्रैक एक्सट्रैक्शन'),
    PipelineStepModel(id: 'speech_recognition', hindiTitle: '3. English Transcript बनाना', subtitle: 'अंग्रेजी आवाज का समयबद्ध प्रतिलेखन'),
    PipelineStepModel(id: 'translation', hindiTitle: '4. Hindi Translation करना', subtitle: 'प्राकृतिक बोलचाल हिंदी में संवाद अनुवाद'),
    PipelineStepModel(id: 'tts_synthesis', hindiTitle: '5. Hindi Voice बनाना', subtitle: 'प्राकृतिक हिंदी AI आवाज़ जनरेशन'),
    PipelineStepModel(id: 'sync_audio', hindiTitle: '6. Hindi Voice Synchronize करना', subtitle: 'मूल टाइमलाइन के साथ समयबद्ध मिलान'),
    PipelineStepModel(id: 'audio_mixing', hindiTitle: '7. Original Audio/Music/SFX Mix करना', subtitle: 'मूल संगीत/SFX सुरक्षित व स्मूथ ऑडियो डकिंग'),
    PipelineStepModel(id: 'video_rendering', hindiTitle: '8. Final Video बनाना', subtitle: 'फाइनल MP4 वीडियो रेंडरिंग व एन्कोडिंग'),
    PipelineStepModel(id: 'gallery_save', hindiTitle: '9. Gallery में Save करना', subtitle: 'Android MediaStore गैलरी में सुरक्षित सहेजना'),
  ];

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  // 1. Pick and validate local video
  Future<void> _pickVideo() async {
    setState(() {
      _errorMessage = null;
    });

    try {
      final picked = await VideoPickerService.pickVideo();
      if (picked != null) {
        _videoController?.dispose();

        VideoPlayerController controller;
        if (kIsWeb) {
          controller = VideoPlayerController.networkUrl(Uri.parse(picked.path));
        } else {
          controller = VideoPlayerController.file(File(picked.path));
        }

        await controller.initialize();

        setState(() {
          _videoFile = picked;
          _videoController = controller;
          _resetPipelineResults();
          _pipelineSteps[0].status = StepStateStatus.completed;
          _pipelineSteps[0].progress = 100;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString().replaceAll('Exception: ', '');
      });
    }
  }

  void _resetPipelineResults() {
    _englishTranscript = null;
    _dubbedTranscript = null;
    _hindiTtsResult = null;
    _syncResult = null;
    _mixedAudioResult = null;
    _finalVideoResult = null;
    _currentJobId = null;
    _activeViewIndex = 0;

    for (int i = 0; i < _pipelineSteps.length; i++) {
      _pipelineSteps[i].status = StepStateStatus.waiting;
      _pipelineSteps[i].progress = 0;
    }
  }

  // 2. Start Full 9-Stage Processing Pipeline
  Future<void> _startFullDubbingPipeline() async {
    if (_videoFile == null || _isProcessing) return;

    setState(() {
      _isProcessing = true;
      _errorMessage = null;
      _pipelineSteps[0].status = StepStateStatus.completed;
      _pipelineSteps[0].progress = 100;
      _pipelineSteps[1].status = StepStateStatus.inProgress;
      _currentProgressMessage = 'वीडियो सर्वर पर अपलोड किया जा रहा है... 15%';
    });

    try {
      final durationSec = _videoFile!.duration.inSeconds.toDouble();

      // Stage 2: Video Upload & Audio extraction with real Job ID
      String? activeJobId;
      try {
        final uploadResult = await DubbingService.uploadVideo(
          videoFile: _videoFile!,
          apiBaseUrl: AppConfig.apiBaseUrl,
          onProgress: (p, msg) {
            setState(() {
              _pipelineSteps[1].progress = (p * 0.5).toInt();
              _currentProgressMessage = msg;
            });
          },
        );
        activeJobId = uploadResult['jobId'] as String?;
        _currentJobId = activeJobId;
      } catch (uploadError) {
        debugPrint('[DubbingStudio] Video upload warning: $uploadError. Continuing with direct audio processing.');
      }

      if (activeJobId != null && activeJobId.isNotEmpty) {
        setState(() {
          _pipelineSteps[1].progress = 60;
          _currentProgressMessage = 'सर्वर से ऑडियो ट्रैक निकाला जा रहा है... 60%';
        });
        try {
          await DubbingService.extractAudio(
            jobId: activeJobId,
            apiBaseUrl: AppConfig.apiBaseUrl,
            onProgress: (p, msg) {
              setState(() {
                _pipelineSteps[1].progress = 50 + (p * 0.5).toInt();
                _currentProgressMessage = msg;
              });
            },
          );
        } catch (extractError) {
          debugPrint('[DubbingStudio] Audio extraction warning: $extractError');
        }
      }

      setState(() {
        _pipelineSteps[1].progress = 100;
        _pipelineSteps[1].status = StepStateStatus.completed;
        _pipelineSteps[2].status = StepStateStatus.inProgress;
        _pipelineSteps[2].progress = 25;
        _currentProgressMessage = 'अंग्रेज़ी Speech पहचानना...';
      });

      // Stage 3: Speech to Text (English Transcript)
      final transcript = await _speechService.transcribeAudio(
        audioBytes: _videoFile!.bytes ?? Uint8List(0),
        durationSeconds: durationSec,
        videoName: _videoFile!.name,
        jobId: activeJobId,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[2].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      final segCount = transcript.segments.length;
      final effectiveJobId = activeJobId ?? transcript.jobId;
      setState(() {
        _englishTranscript = transcript;
        _pipelineSteps[2].progress = 100;
        _pipelineSteps[2].status = StepStateStatus.completed;
        _pipelineSteps[2].subtitle = '$segCount अंग्रेज़ी speech segments मिले';
        _currentProgressMessage = 'अंग्रेज़ी Transcript तैयार ($segCount अंग्रेज़ी speech segments मिले)';
        _pipelineSteps[3].status = StepStateStatus.inProgress;
        _pipelineSteps[3].progress = 30;
      });

      // Stage 4: Natural Hindi Translation
      setState(() {
        _currentProgressMessage = 'हिंदी में अनुवाद किया जा रहा है...';
        _pipelineSteps[3].progress = 30;
      });

      final dubbed = await TranslationService.translateToHindi(
        englishSegments: transcript.segments,
        duration: transcript.duration,
        videoName: _videoFile!.name,
        jobId: effectiveJobId,
        apiBaseUrl: AppConfig.apiBaseUrl,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[3].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      final transSegCount = dubbed.segments.length;
      setState(() {
        _dubbedTranscript = dubbed;
        _pipelineSteps[3].progress = 100;
        _pipelineSteps[3].status = StepStateStatus.completed;
        _pipelineSteps[3].subtitle = '$transSegCount संवाद हिंदी में अनुवादित';
        _currentProgressMessage = 'हिंदी अनुवाद तैयार ($transSegCount संवाद अनुवादित)';
        _pipelineSteps[4].status = StepStateStatus.inProgress;
        _pipelineSteps[4].progress = 25;
      });

      // Stage 5: Hindi TTS Voice Generation
      final tts = await _ttsProvider.synthesize(
        segments: dubbed.segments,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[4].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      setState(() {
        _hindiTtsResult = tts;
        _pipelineSteps[4].progress = 100;
        _pipelineSteps[4].status = StepStateStatus.completed;
        _pipelineSteps[5].status = StepStateStatus.inProgress;
        _pipelineSteps[5].progress = 25;
        _currentProgressMessage = 'Hindi आवाज़ Sync की जा रही है... 25%';
      });

      // Stage 6: Hindi Voice Timing Synchronization
      final sync = await AudioSyncService.synchronizeSpeech(
        segments: tts.segments,
        apiBaseUrl: AppConfig.apiBaseUrl,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[5].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      setState(() {
        _syncResult = sync;
        _pipelineSteps[5].progress = 100;
        _pipelineSteps[5].status = StepStateStatus.completed;
        _pipelineSteps[6].status = StepStateStatus.inProgress;
        _pipelineSteps[6].progress = 30;
        _currentProgressMessage = 'मूल ऑडियो डकिंग व म्यूज़िक मिक्स किया जा रहा है... 30%';
      });

      // Stage 7: Original Music/SFX + Hindi Voice Mixing (Audio Ducking)
      final mixed = await _mixingService.mixAudioWithDucking(
        segments: sync.segments,
        totalVideoDuration: durationSec,
        jobId: effectiveJobId ?? dubbed.jobId,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[6].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      setState(() {
        _mixedAudioResult = mixed;
        _pipelineSteps[6].progress = 100;
        _pipelineSteps[6].status = StepStateStatus.completed;
        _pipelineSteps[7].status = StepStateStatus.inProgress;
        _pipelineSteps[7].progress = 20;
        _currentProgressMessage = 'फाइनल MP4 वीडियो बनाया जा रहा है... 20%';
      });

      // Stage 8: Final Video Rendering
      final rendered = await _renderingService.renderFinalVideo(
        originalVideo: _videoFile!,
        mixedAudio: mixed,
        jobId: effectiveJobId ?? dubbed.jobId,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[7].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      setState(() {
        _finalVideoResult = rendered;
        _pipelineSteps[7].progress = 100;
        _pipelineSteps[7].status = StepStateStatus.completed;
        _pipelineSteps[8].status = StepStateStatus.inProgress;
        _pipelineSteps[8].progress = 40;
        _currentProgressMessage = 'Android MediaStore में सेव किया जा रहा है... 40%';
      });

      // Stage 9: Android MediaStore Gallery Save
      final saved = await _galleryService.saveVideoToGallery(
        videoResult: rendered,
        onProgress: (p, msg) {
          setState(() {
            _pipelineSteps[8].progress = p;
            _currentProgressMessage = msg;
          });
        },
      );

      setState(() {
        _finalVideoResult = saved;
        _pipelineSteps[8].progress = 100;
        _pipelineSteps[8].status = StepStateStatus.completed;
        _currentProgressMessage = 'डबिंग प्रक्रिया पूर्ण · वीडियो तैयार है!';
        _activeViewIndex = 5; // Open final video screen
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString().replaceAll('Exception: ', '');
        for (var step in _pipelineSteps) {
          if (step.status == StepStateStatus.inProgress) {
            step.status = StepStateStatus.error;
          }
        }
      });
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }

  void _seekVideo(double seconds) {
    _videoController?.seekTo(Duration(milliseconds: (seconds * 1000).toInt()));
    _videoController?.play();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF08090E),
      appBar: _buildHeader(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 880),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Error Alert Banner
                if (_errorMessage != null) _buildErrorBanner(),

                // Video Preview Area
                VideoPreviewWidget(
                  videoFile: _videoFile,
                  controller: _videoController,
                  onPickVideo: _pickVideo,
                  onStartDubbing: _startFullDubbingPipeline,
                  isProcessing: _isProcessing,
                ),
                const SizedBox(height: 20),

                // 9-Stage Progress Pipeline
                UnifiedPipelineProgress(
                  steps: _pipelineSteps,
                  currentMessage: _currentProgressMessage,
                  isProcessing: _isProcessing,
                  errorMessage: _errorMessage,
                  totalSegments: _dubbedTranscript?.segments.length ?? 0,
                ),
                const SizedBox(height: 20),

                // Sub-screens Navigation Bar (when results are available)
                if (_hasAnyResults) _buildViewSwitchTabs(),
                const SizedBox(height: 12),

                // Active Sub-Screen View
                _buildActiveSubScreen(),
                const SizedBox(height: 24),

                // Bottom Footer
                _buildFooter(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool get _hasAnyResults =>
      _dubbedTranscript != null ||
      _hindiTtsResult != null ||
      _syncResult != null ||
      _mixedAudioResult != null ||
      _finalVideoResult != null;

  PreferredSizeWidget _buildHeader() {
    return AppBar(
      backgroundColor: const Color(0xFF0A0C14).withOpacity(0.95),
      elevation: 0,
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Colors.indigoAccent, Colors.purpleAccent]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(LucideIcons.film, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'AI Video Dubbing Studio',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              Text(
                'English से Hindi संपूर्ण डबिंग (Flutter + Dart)',
                style: TextStyle(fontSize: 11, color: Colors.indigoAccent),
              ),
            ],
          ),
        ],
      ),
      actions: [
        IconButton(
          tooltip: 'सर्वर सेटिंग्स (Server Settings)',
          icon: const Icon(LucideIcons.server, color: Colors.indigoAccent),
          onPressed: _showServerSettingsDialog,
        ),
      ],
    );
  }

  void _showServerSettingsDialog() {
    final controller = TextEditingController(text: AppConfig.apiBaseUrl);
    String? statusMessage;
    bool isTesting = false;
    bool? isSuccess;

    showDialog(
      context: context,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF131722),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: Colors.white.withOpacity(0.1)),
              ),
              title: Row(
                children: const [
                  Icon(LucideIcons.server, color: Colors.indigoAccent, size: 22),
                  SizedBox(width: 10),
                  Text(
                    'सर्वर सेटिंग्स',
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'मोबाइल डिवाइस टेस्टिंग के लिए बैकएंड URL:',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: controller,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'उदा: http://192.168.1.5:3000',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                        filled: true,
                        fillColor: const Color(0xFF1E2230),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        prefixIcon: const Icon(LucideIcons.globe, color: Colors.indigoAccent, size: 18),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      children: [
                        ActionChip(
                          label: const Text('10.0.2.2 (Emulator)', style: TextStyle(fontSize: 11, color: Colors.white70)),
                          backgroundColor: const Color(0xFF1E2230),
                          onPressed: () {
                            setDialogState(() {
                              controller.text = 'http://10.0.2.2:3000';
                            });
                          },
                        ),
                        ActionChip(
                          label: const Text('localhost:3000', style: TextStyle(fontSize: 11, color: Colors.white70)),
                          backgroundColor: const Color(0xFF1E2230),
                          onPressed: () {
                            setDialogState(() {
                              controller.text = 'http://localhost:3000';
                            });
                          },
                        ),
                      ],
                    ),
                    if (statusMessage != null) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        decoration: BoxDecoration(
                          color: (isSuccess == true) ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: (isSuccess == true) ? Colors.green : Colors.red, width: 0.8),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              (isSuccess == true) ? LucideIcons.checkCircle : LucideIcons.alertCircle,
                              color: (isSuccess == true) ? Colors.greenAccent : Colors.redAccent,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                statusMessage!,
                                style: TextStyle(
                                  color: (isSuccess == true) ? Colors.greenAccent : Colors.redAccent,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: isTesting
                      ? null
                      : () async {
                          setDialogState(() {
                            isTesting = true;
                            statusMessage = 'कनेक्शन जाँचा जा रहा है...';
                            isSuccess = null;
                          });
                          try {
                            final targetUrl = controller.text.trim().replaceAll(RegExp(r'/+$'), '');
                            final pingUrl = targetUrl.isEmpty ? '/api/health' : '$targetUrl/api/health';
                            final res = await http.get(Uri.parse(pingUrl)).timeout(const Duration(seconds: 4));
                            if (res.statusCode == 200) {
                              setDialogState(() {
                                isTesting = false;
                                isSuccess = true;
                                statusMessage = 'कनेक्शन सफल: बैकएंड सक्रिय है!';
                              });
                            } else {
                              setDialogState(() {
                                isTesting = false;
                                isSuccess = false;
                                statusMessage = 'सर्वर एरर (${res.statusCode})';
                              });
                            }
                          } catch (err) {
                            setDialogState(() {
                              isTesting = false;
                              isSuccess = false;
                              statusMessage = 'कनेक्ट नहीं हो सका: $err';
                            });
                          }
                        },
                  child: isTesting
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('जाँचें (Test)', style: TextStyle(color: Colors.indigoAccent)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.indigoAccent),
                  onPressed: () {
                    final newUrl = controller.text.trim();
                    if (newUrl.isNotEmpty) {
                      AppConfig.apiBaseUrl = newUrl;
                      setState(() {});
                    }
                    Navigator.of(dialogCtx).pop();
                  },
                  child: const Text('सेव करें', style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildErrorBanner() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF4C0519).withOpacity(0.4),
        border: Border.all(color: Colors.redAccent.withOpacity(0.4)),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          const Icon(LucideIcons.alertCircle, color: Colors.redAccent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: const TextStyle(color: Colors.redAccent, fontSize: 13, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildViewSwitchTabs() {
    final tabs = [
      if (_dubbedTranscript != null) {'idx': 1, 'label': 'अनुवाद (Translation)'},
      if (_hindiTtsResult != null) {'idx': 2, 'label': 'हिंदी आवाज़ (TTS)'},
      if (_syncResult != null) {'idx': 3, 'label': 'ऑडियो सिंक (Sync)'},
      if (_mixedAudioResult != null) {'idx': 4, 'label': 'मिक्सिंग (Ducking)'},
      if (_finalVideoResult != null) {'idx': 5, 'label': 'फाइनल वीडियो (MP4)'},
    ];

    if (tabs.isEmpty) return const SizedBox.shrink();

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: tabs.map((t) {
          final isSelected = _activeViewIndex == t['idx'];
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: ChoiceChip(
              label: Text(t['label'] as String),
              selected: isSelected,
              onSelected: (val) {
                if (val) setState(() => _activeViewIndex = t['idx'] as int);
              },
              selectedColor: Colors.indigoAccent,
              backgroundColor: Colors.white.withOpacity(0.04),
              labelStyle: TextStyle(
                color: isSelected ? Colors.white : Colors.white70,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildActiveSubScreen() {
    if (_activeViewIndex == 5 && _finalVideoResult != null) {
      return FinalVideoScreen(
        videoResult: _finalVideoResult!,
        onReset: _resetPipelineResults,
      );
    }
    if (_activeViewIndex == 4 && _mixedAudioResult != null) {
      return AudioMixingScreen(
        mixedResult: _mixedAudioResult!,
        onSeekVideo: _seekVideo,
      );
    }
    if (_activeViewIndex == 3 && _syncResult != null) {
      return AudioSyncScreen(
        syncResult: _syncResult!,
        onSeekVideo: _seekVideo,
      );
    }
    if (_activeViewIndex == 2 && _hindiTtsResult != null) {
      return HindiVoiceScreen(
        ttsResult: _hindiTtsResult!,
        onSeekVideo: _seekVideo,
      );
    }
    if (_activeViewIndex == 1 && _dubbedTranscript != null) {
      return TranslationScreen(
        dubbedTranscript: _dubbedTranscript!,
        onSeekToTime: _seekVideo,
      );
    }

    // Default to most advanced completed result
    if (_finalVideoResult != null) {
      return FinalVideoScreen(videoResult: _finalVideoResult!, onReset: _resetPipelineResults);
    }
    if (_mixedAudioResult != null) {
      return AudioMixingScreen(mixedResult: _mixedAudioResult!, onSeekVideo: _seekVideo);
    }
    if (_syncResult != null) {
      return AudioSyncScreen(syncResult: _syncResult!, onSeekVideo: _seekVideo);
    }
    if (_hindiTtsResult != null) {
      return HindiVoiceScreen(ttsResult: _hindiTtsResult!, onSeekVideo: _seekVideo);
    }
    if (_dubbedTranscript != null) {
      return TranslationScreen(dubbedTranscript: _dubbedTranscript!, onSeekToTime: _seekVideo);
    }

    return const SizedBox.shrink();
  }

  Widget _buildFooter() {
    return Center(
      child: Text(
        'अधिकतम वीडियो अवधि: 10 मिनट · Flutter + Dart AI Video Dubbing Architecture',
        style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.4)),
      ),
    );
  }
}
