import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:video_player/video_player.dart';
import '../models/final_video_result.dart';
import '../services/gallery_service.dart';

class FinalVideoScreen extends StatefulWidget {
  final FinalVideoResult videoResult;
  final VoidCallback onReset;

  const FinalVideoScreen({
    super.key,
    required this.videoResult,
    required this.onReset,
  });

  @override
  State<FinalVideoScreen> createState() => _FinalVideoScreenState();
}

class _FinalVideoScreenState extends State<FinalVideoScreen> {
  late FinalVideoResult _result;
  VideoPlayerController? _videoController;
  bool _isSaving = false;
  String? _saveMessage;
  final GalleryService _galleryService = AndroidMediaStoreGalleryService();

  @override
  void initState() {
    super.initState();
    _result = widget.videoResult;
    _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    final path = _result.outputVideoPath;
    if (kIsWeb) {
      _videoController = VideoPlayerController.networkUrl(Uri.parse(path));
    } else if (path.startsWith('http')) {
      _videoController = VideoPlayerController.networkUrl(Uri.parse(path));
    } else {
      _videoController = VideoPlayerController.file(File(path));
    }

    try {
      await _videoController!.initialize();
      setState(() {});
    } catch (e) {
      debugPrint('[FinalVideoScreen] Video initialize notice: $e');
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _saveToGallery() async {
    if (_isSaving || _result.isSavedToGallery) return;

    setState(() {
      _isSaving = true;
      _saveMessage = 'Android MediaStore में सेव किया जा रहा है...';
    });

    try {
      final updated = await _galleryService.saveVideoToGallery(
        videoResult: _result,
        onProgress: (percent, msg) {
          setState(() => _saveMessage = msg);
        },
      );

      setState(() {
        _result = updated;
        _saveMessage = 'वीडियो सफलतापूर्वक गैलरी में सेव हो गया';
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('वीडियो सफलतापूर्वक Phone Gallery में सेव हो गया!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      setState(() {
        _saveMessage = 'गैलरी में सेव करने में त्रुटि: $e';
      });
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0D101E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Top Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Colors.greenAccent, Colors.tealAccent]),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(LucideIcons.checkCheck, color: Colors.black87, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'डब किया गया फाइनल वीडियो (Final Hindi Dubbed)',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        'Original Visuals + Synchronized Hindi Voice + Background Music',
                        style: TextStyle(fontSize: 11, color: Colors.greenAccent),
                      ),
                    ],
                  ),
                ],
              ),

              // Status Badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.greenAccent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent.withOpacity(0.4)),
                ),
                child: Row(
                  children: const [
                    Icon(LucideIcons.sparkles, color: Colors.greenAccent, size: 14),
                    SizedBox(width: 4),
                    Text(
                      'डबिंग संपन्न (MP4)',
                      style: TextStyle(color: Colors.greenAccent, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Video Preview Area
          Container(
            height: 320,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white12),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: _videoController != null && _videoController!.value.isInitialized
                  ? Stack(
                      alignment: Alignment.center,
                      children: [
                        AspectRatio(
                          aspectRatio: _videoController!.value.aspectRatio,
                          child: VideoPlayer(_videoController!),
                        ),
                        Positioned(
                          bottom: 12,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              setState(() {
                                _videoController!.value.isPlaying
                                    ? _videoController!.pause()
                                    : _videoController!.play();
                              });
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black87,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            ),
                            icon: Icon(
                              _videoController!.value.isPlaying ? LucideIcons.pause : LucideIcons.play,
                              color: Colors.white,
                              size: 16,
                            ),
                            label: Text(
                              _videoController!.value.isPlaying ? 'रोकें' : 'वीडियो देखें (चलाएं)',
                              style: const TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                        ),
                      ],
                    )
                  : Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(LucideIcons.film, color: Colors.greenAccent, size: 40),
                          SizedBox(height: 8),
                          Text('फाइनल डब वीडियो तैयार है', style: TextStyle(color: Colors.white70)),
                        ],
                      ),
                    ),
            ),
          ),

          const SizedBox(height: 16),

          // Details Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _detailItem('फ़ाइल नाम', _result.filename),
              _detailItem('अवधि', _result.durationFormatted),
              _detailItem('फ़ाइल साइज़', _result.fileSizeFormatted),
              _detailItem('प्रारूप', 'MP4 (H.264 / AAC)'),
            ],
          ),

          const SizedBox(height: 16),

          // Save to Gallery Status Alert
          if (_saveMessage != null)
            Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _result.isSavedToGallery
                    ? Colors.greenAccent.withOpacity(0.12)
                    : Colors.indigoAccent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _result.isSavedToGallery
                      ? Colors.greenAccent.withOpacity(0.3)
                      : Colors.indigoAccent.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _result.isSavedToGallery ? LucideIcons.checkCircle : LucideIcons.loader,
                    color: _result.isSavedToGallery ? Colors.greenAccent : Colors.indigoAccent,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _saveMessage!,
                      style: TextStyle(
                        fontSize: 12,
                        color: _result.isSavedToGallery ? Colors.greenAccent : Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // Primary Actions
          Row(
            children: [
              // Save to Gallery Button
              Expanded(
                flex: 3,
                child: SizedBox(
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: _isSaving || _result.isSavedToGallery ? null : _saveToGallery,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _result.isSavedToGallery ? Colors.green.shade800 : Colors.greenAccent.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: _isSaving
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : Icon(_result.isSavedToGallery ? LucideIcons.checkCheck : LucideIcons.downloadCloud, size: 18),
                    label: Text(
                      _result.isSavedToGallery
                          ? 'Gallery में सेव हो गया'
                          : 'वीडियो Gallery में सेव करें',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),

              // Re-dub Button
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 52,
                  child: OutlinedButton.icon(
                    onPressed: widget.onReset,
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.white.withOpacity(0.2)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(LucideIcons.rotateCcw, size: 16, color: Colors.white70),
                    label: const Text('दोबारा डब करें', style: TextStyle(color: Colors.white, fontSize: 13)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _detailItem(String label, String value) {
    return Column(
      children: [
        Text(label, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.5))),
        const SizedBox(height: 3),
        Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
      ],
    );
  }
}
