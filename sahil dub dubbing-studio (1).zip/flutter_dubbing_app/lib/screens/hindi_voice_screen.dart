import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:video_player/video_player.dart';
import '../models/hindi_audio_segment.dart';
import '../widgets/audio_segment_card.dart';

class HindiVoiceScreen extends StatefulWidget {
  final HindiTtsResult ttsResult;
  final Function(double seconds)? onSeekVideo;
  final Function(VoiceSettings newSettings)? onRegenerateWithSettings;

  const HindiVoiceScreen({
    super.key,
    required this.ttsResult,
    this.onSeekVideo,
    this.onRegenerateWithSettings,
  });

  @override
  State<HindiVoiceScreen> createState() => _HindiVoiceScreenState();
}

class _HindiVoiceScreenState extends State<HindiVoiceScreen> {
  int? _playingSegmentId;
  VideoPlayerController? _audioPlayer;
  late VoiceSettings _currentSettings;

  @override
  void initState() {
    super.initState();
    _currentSettings = widget.ttsResult.voiceSettings;
  }

  @override
  void dispose() {
    _audioPlayer?.dispose();
    super.dispose();
  }

  Future<void> _playSegmentAudio(HindiAudioSegment segment) async {
    if (_playingSegmentId == segment.id) {
      await _audioPlayer?.pause();
      setState(() => _playingSegmentId = null);
      return;
    }

    _audioPlayer?.dispose();
    setState(() => _playingSegmentId = segment.id);

    try {
      // Use base64 data URI or network URL
      final audioUri = segment.audioBase64 != null
          ? Uri.parse('data:audio/mp3;base64,${segment.audioBase64}')
          : Uri.parse('http://localhost:3000${segment.audioPath}');

      _audioPlayer = VideoPlayerController.networkUrl(audioUri);
      await _audioPlayer!.initialize();
      _audioPlayer!.setVolume(_currentSettings.volume);
      _audioPlayer!.setPlaybackSpeed(_currentSettings.speed);
      await _audioPlayer!.play();

      _audioPlayer!.addListener(() {
        if (_audioPlayer != null &&
            _audioPlayer!.value.position >= _audioPlayer!.value.duration) {
          if (mounted) setState(() => _playingSegmentId = null);
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() => _playingSegmentId = null);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ऑडियो चलाने में त्रुटि: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final tts = widget.ttsResult;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0D101E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.indigoAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(LucideIcons.mic, color: Colors.indigoAccent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'हिंदी आवाज़ पूर्वावलोकन (Hindi Voice Preview)',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        'प्राकृतिक हिंदी AI आवाज़ (${tts.segments.length} ऑडियो सेगमेंट्स)',
                        style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.6)),
                      ),
                    ],
                  ),
                ],
              ),

              // Status Badge: "हिंदी आवाज़ तैयार है"
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.greenAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent.withOpacity(0.3)),
                ),
                child: Row(
                  children: const [
                    Icon(LucideIcons.checkCircle2, color: Colors.greenAccent, size: 14),
                    SizedBox(width: 4),
                    Text(
                      'हिंदी आवाज़ तैयार है',
                      style: TextStyle(color: Colors.greenAccent, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),
          const Divider(color: Colors.white12, height: 1),
          const SizedBox(height: 14),

          // Overview Stats
          Row(
            children: [
              Expanded(
                child: _statBox(
                  title: 'मूल वीडियो अवधि',
                  value: '${tts.totalOriginalDuration.toStringAsFixed(1)}s',
                  icon: LucideIcons.clock,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _statBox(
                  title: 'उत्पन्न आवाज़ अवधि',
                  value: '${tts.totalGeneratedDuration.toStringAsFixed(1)}s',
                  icon: LucideIcons.volume2,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _statBox(
                  title: 'समय अंतर (Δt)',
                  value: '${(tts.totalGeneratedDuration - tts.totalOriginalDuration).toStringAsFixed(1)}s',
                  icon: LucideIcons.activity,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Scrollable list of AudioSegmentCard
          Text(
            'समयबद्ध हिंदी संवाद ऑडियो:',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white.withOpacity(0.7)),
          ),
          const SizedBox(height: 8),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: tts.segments.length,
            itemBuilder: (context, index) {
              final segment = tts.segments[index];
              return AudioSegmentCard(
                segment: segment,
                isPlaying: _playingSegmentId == segment.id,
                onPlayToggle: () => _playSegmentAudio(segment),
                onSeekVideo: () => widget.onSeekVideo?.call(segment.startTime),
              );
            },
          ),

          const SizedBox(height: 16),

          // Notice for Step 5
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.indigoAccent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.indigoAccent.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(LucideIcons.sparkles, color: Colors.indigoAccent, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'प्रत्येक संवाद की हिंदी आवाज़ तैयार और मापी जा चुकी है। अगले चरण (चरण 5: Audio-Video Synchronization & Export) में इसे मूल वीडियो के साथ सिंक और मर्च किया जाएगा।',
                    style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.8)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statBox({required String title, required String value, required IconData icon}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.04)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 12, color: Colors.white.withOpacity(0.4)),
              const SizedBox(width: 4),
              Text(title, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.4))),
            ],
          ),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
        ],
      ),
    );
  }
}
