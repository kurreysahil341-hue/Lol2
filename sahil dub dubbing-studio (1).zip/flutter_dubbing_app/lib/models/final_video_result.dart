/// Final Video Result Model for Steps 8 & 9 (Final Video Rendering & MediaStore Gallery Save)
library;

class FinalVideoResult {
  final String id;
  final String videoName;
  final String originalVideoPath;
  final String mixedAudioPath;
  final String outputVideoPath;
  final String filename;
  final double duration;
  final String durationFormatted;
  final int fileSizeBytes;
  final String fileSizeFormatted;
  final bool isSavedToGallery;
  final String? galleryUri;
  final String status;
  final String createdAt;

  FinalVideoResult({
    required this.id,
    required this.videoName,
    required this.originalVideoPath,
    required this.mixedAudioPath,
    required this.outputVideoPath,
    required this.filename,
    required this.duration,
    required this.durationFormatted,
    required this.fileSizeBytes,
    required this.fileSizeFormatted,
    this.isSavedToGallery = false,
    this.galleryUri,
    this.status = 'completed',
    required this.createdAt,
  });

  factory FinalVideoResult.fromJson(Map<String, dynamic> json) {
    return FinalVideoResult(
      id: json['id'] as String? ?? 'vid_${DateTime.now().millisecondsSinceEpoch}',
      videoName: json['videoName'] as String? ?? 'video.mp4',
      originalVideoPath: json['originalVideoPath'] as String? ?? '',
      mixedAudioPath: json['mixedAudioPath'] as String? ?? '',
      outputVideoPath: json['outputVideoPath'] as String? ?? '',
      filename: json['filename'] as String? ?? 'Hindi_Dubbed_001.mp4',
      duration: (json['duration'] as num?)?.toDouble() ?? 0.0,
      durationFormatted: json['durationFormatted'] as String? ?? '00:00',
      fileSizeBytes: json['fileSizeBytes'] as int? ?? 0,
      fileSizeFormatted: json['fileSizeFormatted'] as String? ?? '0 MB',
      isSavedToGallery: json['isSavedToGallery'] as bool? ?? false,
      galleryUri: json['galleryUri'] as String?,
      status: json['status'] as String? ?? 'completed',
      createdAt: json['createdAt'] as String? ?? DateTime.now().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'videoName': videoName,
      'originalVideoPath': originalVideoPath,
      'mixedAudioPath': mixedAudioPath,
      'outputVideoPath': outputVideoPath,
      'filename': filename,
      'duration': duration,
      'durationFormatted': durationFormatted,
      'fileSizeBytes': fileSizeBytes,
      'fileSizeFormatted': fileSizeFormatted,
      'isSavedToGallery': isSavedToGallery,
      'galleryUri': galleryUri,
      'status': status,
      'createdAt': createdAt,
    };
  }

  FinalVideoResult copyWith({
    bool? isSavedToGallery,
    String? galleryUri,
    String? status,
  }) {
    return FinalVideoResult(
      id: id,
      videoName: videoName,
      originalVideoPath: originalVideoPath,
      mixedAudioPath: mixedAudioPath,
      outputVideoPath: outputVideoPath,
      filename: filename,
      duration: duration,
      durationFormatted: durationFormatted,
      fileSizeBytes: fileSizeBytes,
      fileSizeFormatted: fileSizeFormatted,
      isSavedToGallery: isSavedToGallery ?? this.isSavedToGallery,
      galleryUri: galleryUri ?? this.galleryUri,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }
}
