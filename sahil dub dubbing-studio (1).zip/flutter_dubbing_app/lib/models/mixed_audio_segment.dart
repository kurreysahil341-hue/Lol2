/// Mixed Audio Segment & Result Model for Step 7: Audio Ducking & Mixing
library;

class MixedAudioSegment {
  final int id;
  final double startTime;
  final double endTime;
  final String hindiAudioPath;
  final double originalAudioLevel; // e.g. 0.25 during Hindi speech (ducked)
  final double hindiVoiceLevel; // e.g. 1.00
  final bool duckingApplied;
  final double fadeInDuration; // e.g. 0.2s
  final double fadeOutDuration; // e.g. 0.3s
  final String status;
  final String englishText;
  final String hindiText;

  MixedAudioSegment({
    required this.id,
    required this.startTime,
    required this.endTime,
    required this.hindiAudioPath,
    this.originalAudioLevel = 0.25,
    this.hindiVoiceLevel = 1.0,
    this.duckingApplied = true,
    this.fadeInDuration = 0.2,
    this.fadeOutDuration = 0.3,
    this.status = 'mixed',
    this.englishText = '',
    this.hindiText = '',
  });

  factory MixedAudioSegment.fromJson(Map<String, dynamic> json) {
    return MixedAudioSegment(
      id: json['id'] as int? ?? 1,
      startTime: (json['startTime'] as num?)?.toDouble() ?? 0.0,
      endTime: (json['endTime'] as num?)?.toDouble() ?? 0.0,
      hindiAudioPath: json['hindiAudioPath'] as String? ?? json['audioPath'] as String? ?? '',
      originalAudioLevel: (json['originalAudioLevel'] as num?)?.toDouble() ?? 0.25,
      hindiVoiceLevel: (json['hindiVoiceLevel'] as num?)?.toDouble() ?? 1.0,
      duckingApplied: json['duckingApplied'] as bool? ?? true,
      fadeInDuration: (json['fadeInDuration'] as num?)?.toDouble() ?? 0.2,
      fadeOutDuration: (json['fadeOutDuration'] as num?)?.toDouble() ?? 0.3,
      status: json['status'] as String? ?? 'mixed',
      englishText: json['englishText'] as String? ?? '',
      hindiText: json['hindiText'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startTime': startTime,
      'endTime': endTime,
      'hindiAudioPath': hindiAudioPath,
      'originalAudioLevel': originalAudioLevel,
      'hindiVoiceLevel': hindiVoiceLevel,
      'duckingApplied': duckingApplied,
      'fadeInDuration': fadeInDuration,
      'fadeOutDuration': fadeOutDuration,
      'status': status,
      'englishText': englishText,
      'hindiText': hindiText,
    };
  }

  String formatTime(double seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds.toInt() % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get timecodeString => '${formatTime(startTime)} - ${formatTime(endTime)}';
}

class MixedAudioResult {
  final String mixedAudioPath;
  final List<MixedAudioSegment> segments;
  final double totalDuration;
  final double originalDuckingLevel;
  final double hindiVoiceLevel;
  final bool backgroundMusicPreserved;
  final String status;
  final String createdAt;

  MixedAudioResult({
    required this.mixedAudioPath,
    required this.segments,
    required this.totalDuration,
    this.originalDuckingLevel = 0.25,
    this.hindiVoiceLevel = 1.0,
    this.backgroundMusicPreserved = true,
    this.status = 'completed',
    required this.createdAt,
  });

  factory MixedAudioResult.fromJson(Map<String, dynamic> json) {
    final rawList = json['segments'] as List? ?? [];
    final parsed = rawList
        .map((e) => MixedAudioSegment.fromJson(e as Map<String, dynamic>))
        .toList();

    return MixedAudioResult(
      mixedAudioPath: json['mixedAudioPath'] as String? ?? '',
      segments: parsed,
      totalDuration: (json['totalDuration'] as num?)?.toDouble() ?? 0.0,
      originalDuckingLevel: (json['originalDuckingLevel'] as num?)?.toDouble() ?? 0.25,
      hindiVoiceLevel: (json['hindiVoiceLevel'] as num?)?.toDouble() ?? 1.0,
      backgroundMusicPreserved: json['backgroundMusicPreserved'] as bool? ?? true,
      status: json['status'] as String? ?? 'completed',
      createdAt: json['createdAt'] as String? ?? DateTime.now().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'mixedAudioPath': mixedAudioPath,
      'segments': segments.map((s) => s.toJson()).toList(),
      'totalDuration': totalDuration,
      'originalDuckingLevel': originalDuckingLevel,
      'hindiVoiceLevel': hindiVoiceLevel,
      'backgroundMusicPreserved': backgroundMusicPreserved,
      'status': status,
      'createdAt': createdAt,
    };
  }
}
