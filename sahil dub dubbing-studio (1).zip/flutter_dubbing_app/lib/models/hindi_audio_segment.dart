/// Hindi Audio Segment and Voice Models for Step 4
library;

class VoiceSettings {
  final String language;
  final String voiceName;
  final double speed;
  final double pitch;
  final double volume;

  const VoiceSettings({
    this.language = 'hi',
    this.voiceName = 'hi-IN-Neural-1',
    this.speed = 1.0,
    this.pitch = 1.0,
    this.volume = 1.0,
  });

  factory VoiceSettings.fromJson(Map<String, dynamic> json) {
    return VoiceSettings(
      language: json['language'] as String? ?? 'hi',
      voiceName: json['voiceName'] as String? ?? 'hi-IN-Neural-1',
      speed: (json['speed'] as num?)?.toDouble() ?? 1.0,
      pitch: (json['pitch'] as num?)?.toDouble() ?? 1.0,
      volume: (json['volume'] as num?)?.toDouble() ?? 1.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'language': language,
      'voiceName': voiceName,
      'speed': speed,
      'pitch': pitch,
      'volume': volume,
    };
  }

  VoiceSettings copyWith({
    String? language,
    String? voiceName,
    double? speed,
    double? pitch,
    double? volume,
  }) {
    return VoiceSettings(
      language: language ?? this.language,
      voiceName: voiceName ?? this.voiceName,
      speed: speed ?? this.speed,
      pitch: pitch ?? this.pitch,
      volume: volume ?? this.volume,
    );
  }
}

class HindiAudioSegment {
  final int id;
  final double startTime;
  final double endTime;
  final String englishText;
  final String hindiText;
  final String audioPath;
  final String? audioBase64;
  final double generatedDuration;
  final double originalDuration;
  final double durationDifference;

  HindiAudioSegment({
    required this.id,
    required this.startTime,
    required this.endTime,
    required this.englishText,
    required this.hindiText,
    required this.audioPath,
    this.audioBase64,
    required this.generatedDuration,
    required this.originalDuration,
    required this.durationDifference,
  });

  factory HindiAudioSegment.fromJson(Map<String, dynamic> json) {
    final start = (json['startTime'] as num?)?.toDouble() ?? 0.0;
    final end = (json['endTime'] as num?)?.toDouble() ?? 0.0;
    final genDur = (json['generatedDuration'] as num?)?.toDouble() ?? (json['duration'] as num?)?.toDouble() ?? 0.0;
    final origDur = (json['originalDuration'] as num?)?.toDouble() ?? (end - start);
    final diff = (json['durationDifference'] as num?)?.toDouble() ?? (genDur - origDur);

    return HindiAudioSegment(
      id: json['id'] as int? ?? 1,
      startTime: start,
      endTime: end,
      englishText: json['englishText'] as String? ?? '',
      hindiText: json['hindiText'] as String? ?? '',
      audioPath: json['audioPath'] as String? ?? '',
      audioBase64: json['audioBase64'] as String?,
      generatedDuration: genDur,
      originalDuration: origDur,
      durationDifference: diff,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startTime': startTime,
      'endTime': endTime,
      'englishText': englishText,
      'hindiText': hindiText,
      'audioPath': audioPath,
      'audioBase64': audioBase64,
      'generatedDuration': generatedDuration,
      'originalDuration': originalDuration,
      'durationDifference': durationDifference,
    };
  }

  String formatTime(double seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds.toInt() % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get timecodeString => '${formatTime(startTime)} - ${formatTime(endTime)}';
}

class HindiTtsResult {
  final List<HindiAudioSegment> segments;
  final double totalOriginalDuration;
  final double totalGeneratedDuration;
  final VoiceSettings voiceSettings;
  final String createdAt;

  HindiTtsResult({
    required this.segments,
    required this.totalOriginalDuration,
    required this.totalGeneratedDuration,
    required this.voiceSettings,
    required this.createdAt,
  });

  factory HindiTtsResult.fromJson(Map<String, dynamic> json) {
    var rawList = json['segments'] as List? ?? [];
    List<HindiAudioSegment> parsed = rawList
        .map((e) => HindiAudioSegment.fromJson(e as Map<String, dynamic>))
        .toList();

    return HindiTtsResult(
      segments: parsed,
      totalOriginalDuration: (json['totalOriginalDuration'] as num?)?.toDouble() ?? 0.0,
      totalGeneratedDuration: (json['totalGeneratedDuration'] as num?)?.toDouble() ?? 0.0,
      voiceSettings: json['voiceSettings'] != null
          ? VoiceSettings.fromJson(json['voiceSettings'] as Map<String, dynamic>)
          : const VoiceSettings(),
      createdAt: json['createdAt'] as String? ?? DateTime.now().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'segments': segments.map((s) => s.toJson()).toList(),
      'totalOriginalDuration': totalOriginalDuration,
      'totalGeneratedDuration': totalGeneratedDuration,
      'voiceSettings': voiceSettings.toJson(),
      'createdAt': createdAt,
    };
  }
}
