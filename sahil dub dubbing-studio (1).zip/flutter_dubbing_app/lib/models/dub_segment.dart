/// Dubbing Segment & Transcript Models for English -> Hindi Translation
library;

class DubSegment {
  final int id;
  final String formattedId;
  final double startTime;
  final double endTime;
  final String englishText;
  final String hindiText;

  DubSegment({
    required this.id,
    String? formattedId,
    required this.startTime,
    required this.endTime,
    required this.englishText,
    required this.hindiText,
  }) : formattedId = formattedId ?? 'seg_${id.toString().padLeft(3, '0')}';

  factory DubSegment.fromJson(Map<String, dynamic> json) {
    int parsedId = 1;
    String fId = 'seg_001';
    if (json['id'] is int) {
      parsedId = json['id'] as int;
      fId = 'seg_${parsedId.toString().padLeft(3, '0')}';
    } else if (json['id'] != null) {
      fId = json['id'].toString();
      final digits = fId.replaceAll(RegExp(r'[^0-9]'), '');
      parsedId = int.tryParse(digits) ?? 1;
    }

    return DubSegment(
      id: parsedId,
      formattedId: fId,
      startTime: (json['startTime'] as num?)?.toDouble() ?? 0.0,
      endTime: (json['endTime'] as num?)?.toDouble() ?? 0.0,
      englishText: (json['englishText'] as String?) ?? (json['text'] as String?) ?? '',
      hindiText: (json['hindiText'] as String?) ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': formattedId,
      'numericId': id,
      'startTime': startTime,
      'endTime': endTime,
      'englishText': englishText,
      'hindiText': hindiText,
      'text': hindiText,
    };
  }

  String formatTime(double seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds.toInt() % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get timecodeString => '${formatTime(startTime)} - ${formatTime(endTime)}';
}

class DubbedTranscript {
  final String sourceLanguage;
  final String targetLanguage;
  final double duration;
  final String? videoName;
  final String? jobId;
  final List<DubSegment> segments;

  DubbedTranscript({
    required this.sourceLanguage,
    required this.targetLanguage,
    required this.duration,
    this.videoName,
    this.jobId,
    required this.segments,
  });

  factory DubbedTranscript.fromJson(Map<String, dynamic> json) {
    var rawList = json['segments'] as List? ??
        (json['translation'] is Map ? json['translation']['segments'] as List? : null) ??
        [];
    List<DubSegment> parsed = rawList
        .map((e) => DubSegment.fromJson(e as Map<String, dynamic>))
        .toList();

    return DubbedTranscript(
      sourceLanguage: json['sourceLanguage'] as String? ?? 'en',
      targetLanguage: json['targetLanguage'] as String? ?? 'hi',
      duration: (json['duration'] as num?)?.toDouble() ?? 0.0,
      videoName: json['videoName'] as String?,
      jobId: json['jobId'] as String?,
      segments: parsed,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'jobId': jobId,
      'sourceLanguage': sourceLanguage,
      'targetLanguage': targetLanguage,
      'duration': duration,
      'videoName': videoName,
      'segments': segments.map((s) => s.toJson()).toList(),
    };
  }
}
