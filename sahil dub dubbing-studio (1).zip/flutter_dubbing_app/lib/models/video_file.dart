import 'dart:typed_data';

/// Structured Local Video File Model for Input Validation & Details
class VideoFile {
  final String name;
  final String path;
  final Uint8List? bytes;
  final Duration duration;
  final int fileSizeBytes;
  final String format;

  VideoFile({
    required this.name,
    required this.path,
    this.bytes,
    required this.duration,
    required this.fileSizeBytes,
    required this.format,
  });

  String get durationFormatted {
    final mins = duration.inMinutes.toString().padLeft(2, '0');
    final secs = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get fileSizeFormatted {
    if (fileSizeBytes <= 0) return '0 MB';
    final mb = fileSizeBytes / (1024 * 1024);
    return '${mb.toStringAsFixed(1)} MB';
  }

  bool get isValidDuration => duration.inSeconds <= 600; // <= 10 mins
}
