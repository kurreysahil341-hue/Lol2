/// Synced Audio Segment & Result Model for Step 5: Hindi Voice Synchronization
library;

class SyncedAudioSegment {
  final int id;
  final double startTime;
  final double endTime;
  final double targetDuration;
  final double originalAudioDuration;
  final double hindiAudioDuration;
  final double adjustedDuration;
  final String audioPath;
  final String? audioBase64;
  final double speedAdjustment;
  final String status;
  final String timingClassification;
  final String timingClassificationHindi;
  final double remainingDifference;
  final String englishText;
  final String hindiText;

  SyncedAudioSegment({
    required this.id,
    required this.startTime,
    required this.endTime,
    required this.targetDuration,
    required this.originalAudioDuration,
    required this.hindiAudioDuration,
    required this.adjustedDuration,
    required this.audioPath,
    this.audioBase64,
    required this.speedAdjustment,
    required this.status,
    required this.timingClassification,
    required this.timingClassificationHindi,
    required this.remainingDifference,
    required this.englishText,
    required this.hindiText,
  });

  factory SyncedAudioSegment.fromJson(Map<String, dynamic> json) {
    final start = (json['startTime'] as num?)?.toDouble() ?? 0.0;
    final end = (json['endTime'] as num?)?.toDouble() ?? 0.0;
    final target = (json['targetDuration'] as num?)?.toDouble() ?? (end - start);
    final hindiDur = (json['hindiAudioDuration'] as num?)?.toDouble() ?? (json['generatedDuration'] as num?)?.toDouble() ?? target;
    final adjusted = (json['adjustedDuration'] as num?)?.toDouble() ?? hindiDur;
    final speed = (json['speedAdjustment'] as num?)?.toDouble() ?? 1.0;
    final remaining = (json['remainingDifference'] as num?)?.toDouble() ?? (adjusted - target);

    return SyncedAudioSegment(
      id: json['id'] as int? ?? 1,
      startTime: start,
      endTime: end,
      targetDuration: target,
      originalAudioDuration: (json['originalAudioDuration'] as num?)?.toDouble() ?? target,
      hindiAudioDuration: hindiDur,
      adjustedDuration: adjusted,
      audioPath: json['audioPath'] as String? ?? '',
      audioBase64: json['audioBase64'] as String?,
      speedAdjustment: speed,
      status: json['status'] as String? ?? 'synchronized',
      timingClassification: json['timingClassification'] as String? ?? 'fits_naturally',
      timingClassificationHindi: json['timingClassificationHindi'] as String? ?? 'स्वाभाविक रूप से सही',
      remainingDifference: remaining,
      englishText: json['englishText'] as String? ?? '',
      hindiText: json['hindiText'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startTime': startTime,
      'endTime': endTime,
      'targetDuration': targetDuration,
      'originalAudioDuration': originalAudioDuration,
      'hindiAudioDuration': hindiAudioDuration,
      'adjustedDuration': adjustedDuration,
      'audioPath': audioPath,
      'audioBase64': audioBase64,
      'speedAdjustment': speedAdjustment,
      'status': status,
      'timingClassification': timingClassification,
      'timingClassificationHindi': timingClassificationHindi,
      'remainingDifference': remainingDifference,
      'englishText': englishText,
      'hindiText': hindiText,
    };
  }

  String formatTime(double seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds.toInt() % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get timecodeString => '${formatTime(startTime)} - ${formatTime(endTime)}';
}

class SyncResult {
  final List<SyncedAudioSegment> segments;
  final double totalTargetDuration;
  final double totalAdjustedDuration;
  final double averageSpeedAdjustment;
  final int naturallyFitCount;
  final int speedAdjustedCount;
  final int clampedCount;
  final String createdAt;

  SyncResult({
    required this.segments,
    required this.totalTargetDuration,
    required this.totalAdjustedDuration,
    required this.averageSpeedAdjustment,
    required this.naturallyFitCount,
    required this.speedAdjustedCount,
    required this.clampedCount,
    required this.createdAt,
  });

  factory SyncResult.fromJson(Map<String, dynamic> json) {
    final rawList = json['segments'] as List? ?? [];
    final parsed = rawList
        .map((e) => SyncedAudioSegment.fromJson(e as Map<String, dynamic>))
        .toList();

    return SyncResult(
      segments: parsed,
      totalTargetDuration: (json['totalTargetDuration'] as num?)?.toDouble() ?? 0.0,
      totalAdjustedDuration: (json['totalAdjustedDuration'] as num?)?.toDouble() ?? 0.0,
      averageSpeedAdjustment: (json['averageSpeedAdjustment'] as num?)?.toDouble() ?? 1.0,
      naturallyFitCount: json['naturallyFitCount'] as int? ?? 0,
      speedAdjustedCount: json['speedAdjustedCount'] as int? ?? 0,
      clampedCount: json['clampedCount'] as int? ?? 0,
      createdAt: json['createdAt'] as String? ?? DateTime.now().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'segments': segments.map((s) => s.toJson()).toList(),
      'totalTargetDuration': totalTargetDuration,
      'totalAdjustedDuration': totalAdjustedDuration,
      'averageSpeedAdjustment': averageSpeedAdjustment,
      'naturallyFitCount': naturallyFitCount,
      'speedAdjustedCount': speedAdjustedCount,
      'clampedCount': clampedCount,
      'createdAt': createdAt,
    };
  }
}
