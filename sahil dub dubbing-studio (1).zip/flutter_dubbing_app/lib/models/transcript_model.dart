/// Models for AI Video Dubbing Studio in Flutter/Dart
library;

class TranscriptSegment {
  final int id;
  final double startTime;
  final double endTime;
  final String text;

  TranscriptSegment({
    required this.id,
    required this.startTime,
    required this.endTime,
    required this.text,
  });

  factory TranscriptSegment.fromJson(Map<String, dynamic> json) {
    int parsedId = 1;
    if (json['id'] is int) {
      parsedId = json['id'] as int;
    } else if (json['id'] != null) {
      final digits = json['id'].toString().replaceAll(RegExp(r'[^0-9]'), '');
      parsedId = int.tryParse(digits) ?? 1;
    }

    return TranscriptSegment(
      id: parsedId,
      startTime: (json['startTime'] as num?)?.toDouble() ?? 0.0,
      endTime: (json['endTime'] as num?)?.toDouble() ?? 0.0,
      text: (json['englishText'] as String?) ?? (json['text'] as String?) ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    final formattedId = 'seg_${id.toString().padLeft(3, '0')}';
    return {
      'id': formattedId,
      'englishText': text,
      'text': text,
      'startTime': startTime,
      'endTime': endTime,
    };
  }

  String formatTime(double seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds.toInt() % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get timecodeString => '${formatTime(startTime)} - ${formatTime(endTime)}';
}

class StructuredTranscript {
  final String sourceLanguage;
  final String targetLanguage;
  final double duration;
  final List<TranscriptSegment> segments;
  final String? videoName;

  StructuredTranscript({
    required this.sourceLanguage,
    required this.targetLanguage,
    required this.duration,
    required this.segments,
    this.videoName,
  });

  factory StructuredTranscript.fromJson(Map<String, dynamic> json) {
    var rawList = json['segments'] as List? ??
        (json['transcript'] is Map ? json['transcript']['segments'] as List? : null) ??
        [];
    List<TranscriptSegment> parsedSegments =
        rawList.map((e) => TranscriptSegment.fromJson(e as Map<String, dynamic>)).toList();

    return StructuredTranscript(
      sourceLanguage: json['sourceLanguage'] as String? ?? 'en',
      targetLanguage: json['targetLanguage'] as String? ?? 'hi',
      duration: (json['duration'] as num?)?.toDouble() ?? 0.0,
      segments: parsedSegments,
      videoName: json['videoName'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sourceLanguage': sourceLanguage,
      'targetLanguage': targetLanguage,
      'duration': duration,
      'segments': segments.map((s) => s.toJson()).toList(),
      'videoName': videoName,
    };
  }
}

enum StepStateStatus { waiting, inProgress, completed, error }

class PipelineStepModel {
  final String id;
  final String hindiTitle;
  final String subtitle;
  StepStateStatus status;
  int progress;

  PipelineStepModel({
    required this.id,
    required this.hindiTitle,
    required this.subtitle,
    this.status = StepStateStatus.waiting,
    this.progress = 0,
  });
}
