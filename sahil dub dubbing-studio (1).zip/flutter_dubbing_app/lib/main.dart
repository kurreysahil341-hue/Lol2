import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/dubbing_studio_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AiVideoDubbingApp());
}

class AiVideoDubbingApp extends StatelessWidget {
  const AiVideoDubbingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Video Dubbing',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF08090E),
        primaryColor: Colors.indigoAccent,
        textTheme: GoogleFonts.notoSansDevanagariTextTheme(
          ThemeData.dark().textTheme,
        ),
        colorScheme: const ColorScheme.dark(
          primary: Colors.indigoAccent,
          secondary: Colors.purpleAccent,
          surface: Color(0xFF0D101E),
        ),
      ),
      home: const DubbingStudioScreen(),
    );
  }
}
